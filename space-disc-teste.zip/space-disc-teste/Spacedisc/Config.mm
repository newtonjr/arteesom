//
//  Config.m
//  Plataforma
//
//  Created by Farlei Heinen on 27/03/12.
//  Copyright (c) 2012 Unisinos. All rights reserved.
//

#import "Step.h"
#import "Config.h"

@implementation Config

@synthesize steps;

- (Config*) init
{
    self = [super init];
    if(self)
    {
        Step * step1 = [Step new];
        Step * step2 = [Step new];
        Step * step3 = [Step new];
        Step * step4 = [Step new];
        Step * step5 = [Step new];
        Step * step6 = [Step new];
        Step * step7 = [Step new];
        Step * step8 = [Step new];
        Step * step9 = [Step new];
        Step * step10 = [Step new];
        
        self.steps = [NSArray arrayWithObjects:step1, step2, step3, step4, step5, step6, step7, step8, step9, step10, nil];
    }
    return self;
}


- (Config*) initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        self.steps = [aDecoder decodeObjectForKey:@"STEPS"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:steps forKey:@"STEPS"];
}

@end