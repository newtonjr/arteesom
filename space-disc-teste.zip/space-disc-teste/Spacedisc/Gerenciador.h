//  Baseado na
//
//  Singleton.h
//  BaseCocos2D
//  
//  Created by Farlei Jose Heinen on 04/04/11.
//  Copyright 2011 Ficta. All rights reserved.
//

#import "Step.h"
#import "Config.h"

@interface Gerenciador : NSObject
{
    Config* conf;
}

@property(nonatomic, retain) Config* conf;

+ (Gerenciador*) sharedInstance;

- (NSString*) configFile;
- (void) salvar;
- (void) carregar;

@end