//
//  ScoreLayer.h
//  Spacedisc
//
//  Created by iMac on 24/06/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "Box2D.h"

@interface ScoreLayer : CCLayer {
    int step;
}

@property int step;

+(CCScene *) scene:(int)s andScore:(int) p andStar:(int) i;

- (void) config:(int)p andStar:(int) i;
- (void) back:(id)sender; 
- (void) go2step:(id)sender;


@end
