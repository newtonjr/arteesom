//
//  Disk.h
//  Spacedisc
//
//  Created by Unisinos Universidade on 24/05/12.
//  Copyright 2012 Universidade do Vale do Rio dos Sinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Disk : CCSprite {
    int energy;
    bool dead;
    CCSprite * nivel01;
    CCSprite * nivel02;
    CCSprite * nivel03;
    CCSprite * nivel04;
    CCSprite * nivel05;
    CCSprite * nivel06;
    CCSprite * nivel07;
    CCSprite * nivel08;
}

@property int energy;
@property bool dead;

- (void) setup;

- (void) nivel;

@end
