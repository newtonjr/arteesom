//
//  MenuLayer.h
//  Spacedisc
//
//  Created by iMac on 17/04/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "Box2D.h"

@interface MenuLayer : CCLayer {}

+(CCScene *) scene;

- (void) exit:(id)sender; 
- (void) go2step:(id)sender;

@end
