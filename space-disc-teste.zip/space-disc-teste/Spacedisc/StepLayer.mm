//
//  StepLayer.m
//  Spacedisc
//
//  Created by iMac on 17/04/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Asteroide.h"
#import "StepLayer.h"
#import "MenuLayer.h"
#import "EngineLayer.h"
#import "Gerenciador.h"


@implementation StepLayer

+(CCScene *) scene
{
    // Cria uma Cena e um Layer
	CCScene *scene = [CCScene node];
	StepLayer *layer = [StepLayer node];
	
    // Adiciona o layer na cena...
	[scene addChild: layer];
	
    // ... e retorna para quem chamou o método
	return scene;
}

-(id) init // Construtor da Classe
{
	if( (self=[super init])) 
    {
        CGSize size = [[CCDirector sharedDirector] winSize];
        
        CCSprite* fundo  = [CCSprite spriteWithFile:@"spacedisc-bkground.jpg"];
        fundo.position = ccp(size.width/2, size.height/2);
        [self addChild:fundo z:0];
        
        
        // botao de back
        CCSprite* bt_back_bg = [CCSprite spriteWithFile:@"spacedisc-button.png"];
        CCSprite* txt_back = [CCSprite spriteWithFile:@"spacedisc-back.png"];
        txt_back.position = ccp(54,54);
        [bt_back_bg addChild:txt_back z:10];
        
        CCSprite* bt_back_bg_hover = [CCSprite spriteWithFile:@"spacedisc-button-hover.png"];
        CCSprite* txt_back_hover = [CCSprite spriteWithFile:@"spacedisc-back.png"];
        txt_back_hover.position = ccp(54,54);
        [bt_back_bg_hover addChild:txt_back_hover z:10];
        CCMenuItemSprite* trans_back = [CCMenuItemSprite itemFromNormalSprite:bt_back_bg 
                                                               selectedSprite:bt_back_bg_hover 
                                                                       target:self 
                                                                     selector:@selector(back:)];
        
        // inseri o botao back no menu
        CCMenu* menu = [CCMenu menuWithItems:trans_back, nil];
        menu.position = ccp(size.width/2,90);
        [menu alignItemsVerticallyWithPadding:20];
        
        // Adiciona o menu como filho
        [self addChild:menu z:20];
        
        //
        // Cria o menu com o itens
        //
        CCMenu* step_menu = [CCMenu menuWithItems:nil];
        
        Gerenciador * manager = [Gerenciador sharedInstance];
        NSArray * steps = manager.conf.steps;
        
        //
        // Menu de etapas
        //
        for (int i=0; i<5; i++)
        {
            CCSprite* bt_normal = [CCSprite spriteWithFile:@"spacedisc-button.png"];
            CCSprite* bt_hover = [CCSprite spriteWithFile:@"spacedisc-button-hover.png"];
            
            Step * step = [steps objectAtIndex:i];
            if (i == 0) {
                [step setOpen:true];
            }
            
            if (step.open)
            {
                CCSprite* txt_normal = [CCSprite spriteWithFile:[NSString stringWithFormat:@"spacedisc-number%i.png",(i+1)]];
                txt_normal.position = ccp(54,54);
                [bt_normal addChild:txt_normal z:10];
                
                //
                // STAR
                //
                for (int s=0; s < 6; s++) {
                    
                    CCSprite* star;
                    if(s < step.star){
                        star = [CCSprite spriteWithFile:@"spacedisc-star-on.png"];
                    }else{
                        star = [CCSprite spriteWithFile:@"spacedisc-star-off.png"];
                    }
                    switch (s) {
                        case 0:
                            star.position = ccp(53,94);
                            break;
                        case 1:
                            star.position = ccp(95,80);
                            break;
                        case 2:
                            star.position = ccp(95,26);
                            break;
                        case 3:
                            star.position = ccp(53,10);
                            break;
                        case 4:
                            star.position = ccp(14,26);
                            break;
                        case 5:
                            star.position = ccp(14,80);
                            break;
                    }
                    if(s < step.star){
                        [bt_normal addChild:star z:15];
                    }else{
                        [bt_normal addChild:star z:-5];
                    }
                }
     
                CCSprite* txt_hover = [CCSprite spriteWithFile:[NSString stringWithFormat:@"spacedisc-number%i.png",(i+1)]];
                txt_hover.position = ccp(54,54);
                [bt_hover addChild:txt_hover z:10];
                
                //
                // STAR
                //
                for (int s=0; s < 6; s++) {
                    
                    CCSprite* star;
                    if(s < step.star){
                        star = [CCSprite spriteWithFile:@"spacedisc-star-on.png"];
                    }else{
                        star = [CCSprite spriteWithFile:@"spacedisc-star-off.png"];
                    }
                    switch (s) {
                        case 0:
                            star.position = ccp(53,94);
                            break;
                        case 1:
                            star.position = ccp(95,80);
                            break;
                        case 2:
                            star.position = ccp(95,26);
                            break;
                        case 3:
                            star.position = ccp(53,10);
                            break;
                        case 4:
                            star.position = ccp(14,26);
                            break;
                        case 5:
                            star.position = ccp(14,80);
                            break;
                    }
                    if(s < step.star){
                        [bt_hover addChild:star z:15];
                    }else{
                        [bt_hover addChild:star z:-5];
                    }
                }
            }
            else
            {
                CCSprite* txt_normal = [CCSprite spriteWithFile:@"spacedisc-lock.png"];
                txt_normal.position = ccp(54,54);
                [bt_normal addChild:txt_normal z:10];
                
                CCSprite* txt_hover = [CCSprite spriteWithFile:@"spacedisc-lock.png"];
                txt_hover.position = ccp(54,54);
                [bt_hover addChild:txt_hover z:10];
            }
        
            CCMenuItemSprite* step_trans_item = [CCMenuItemSprite itemFromNormalSprite:bt_normal 
                                                                        selectedSprite:bt_hover 
                                                                                target:self 
                                                                              selector:@selector(getStep:)];
            step_trans_item.tag = (i+1);
            step_trans_item.userData = step;
            
            [step_menu addChild:step_trans_item];
        }
        
        step_menu.position = ccp(size.width/2, (size.height/2)+50);
        [step_menu alignItemsInColumns:[NSNumber numberWithInt:5], nil];
        
        // Adiciona o menu como filho
        [self addChild:step_menu z:30];
        
    }
    return self;
}

- (void) back:(id)sender
{    
    [[CCDirector sharedDirector] pushScene:[CCTransitionSlideInL transitionWithDuration:0.3 scene:[MenuLayer scene]]];
}

- (void) getStep:(CCMenuItemSprite*)sender
{
    int number = sender.tag;
    Step * step = (Step *)sender.userData;
    if (step.open) {
        [[CCDirector sharedDirector] pushScene:[CCTransitionSplitCols transitionWithDuration:0.3 scene:[EngineLayer scene:number]]];
    }else{
        //som bleble
    }
}

@end
