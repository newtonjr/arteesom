//
//  MenuLayer.m
//  Spacedisc
//
//  Created by iMac on 17/04/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//
#import "CCTMXMapInfo+TMXParserExt.h"

#import "Asteroide.h"
#import "MenuLayer.h"
#import "StepLayer.h"


@implementation MenuLayer

static bool registrando_pol = true;

+(CCScene *) scene
{
    // Cria uma Cena e um Layer
	CCScene *scene = [CCScene node];
	MenuLayer *layer = [MenuLayer node];
	
    // Adiciona o layer na cena...
	[scene addChild: layer];
    
    // ... e retorna para quem chamou o método
	return scene;
}

-(id) init // Construtor da Classe
{
	if( (self=[super init])) 
    {
        CGSize size = [[CCDirector sharedDirector] winSize];
        
        CCSprite* fundo  = [CCSprite spriteWithFile:@"spacedisc-bkground.jpg"];
        fundo.position = ccp(size.width/2, size.height/2);
        [self addChild:fundo z:0];
        
        CCSprite* title  = [CCSprite spriteWithFile:@"spacedisc-title.png"];
        title.position = ccp(size.width/2, (size.height/2)+180);
        [self addChild:title z:10];

        
        // botao de play
        CCSprite* bt_play_bg = [CCSprite spriteWithFile:@"spacedisc-button.png"];
        CCSprite* txt_play = [CCSprite spriteWithFile:@"spacedisc-play.png"];
        txt_play.position = ccp(54,54);
        [bt_play_bg addChild:txt_play z:10];
        
        CCSprite* bt_play_bg_hover = [CCSprite spriteWithFile:@"spacedisc-button-hover.png"];
        CCSprite* txt_play_hover = [CCSprite spriteWithFile:@"spacedisc-play.png"];
        txt_play_hover.position = ccp(54,54);
        [bt_play_bg_hover addChild:txt_play_hover z:10];
        CCMenuItemSprite* trans_play = [CCMenuItemSprite itemFromNormalSprite:bt_play_bg 
                                                              selectedSprite:bt_play_bg_hover 
                                                                      target:self 
                                                                    selector:@selector(go2step:)];
        
        // botao de exit
        CCSprite* bt_exit_bg = [CCSprite spriteWithFile:@"spacedisc-button.png"];
        CCSprite* txt_exit = [CCSprite spriteWithFile:@"spacedisc-exit.png"];
        txt_exit.position = ccp(54,54);
        [bt_exit_bg addChild:txt_exit z:10];
        
        CCSprite* bt_exit_bg_hover = [CCSprite spriteWithFile:@"spacedisc-button-hover.png"];
        CCSprite* txt_exit_hover = [CCSprite spriteWithFile:@"spacedisc-exit.png"];
        txt_exit_hover.position = ccp(54,54);
        [bt_exit_bg_hover addChild:txt_exit_hover z:10];
        CCMenuItemSprite* trans_exit = [CCMenuItemSprite itemFromNormalSprite:bt_exit_bg 
                                                              selectedSprite:bt_exit_bg_hover 
                                                                      target:self 
                                                                     selector:@selector(exit:)];
        
        // Cria o menu com o itens
        CCMenu* menu = [CCMenu menuWithItems:trans_play, trans_exit, nil];
        menu.position = ccp(size.width/2,(size.height/2)-50);
        [menu alignItemsVerticallyWithPadding:20];
        
        // Adiciona o menu como filho
        [self addChild:menu z:20];
        
        
        if(registrando_pol)
        {
            [CCTMXMapInfo applyParserExtension];
            registrando_pol = false;
        }
    }
    return self;
}

- (void) exit:(id)sender
{
    //fechar
}

- (void) go2step:(id)sender
{
    /*
    CCDirector* diretor = [CCDirector sharedDirector];
    CCScene* novaCena = [StepLayer scene];
    CCTransitionTurnOffTiles* transic = [CCTransitionTurnOffTiles transitionWithDuration:1.0 scene:novaCena];
    [diretor pushScene:transic];
     */
    [[CCDirector sharedDirector] pushScene:[CCTransitionSlideInR transitionWithDuration:0.3 scene:[StepLayer scene]]];
}
- (void) dealloc
{
	[super dealloc];
}

@end
