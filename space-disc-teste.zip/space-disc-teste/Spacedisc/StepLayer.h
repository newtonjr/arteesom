//
//  StepLayer.h
//  Spacedisc
//
//  Created by iMac on 17/04/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface StepLayer : CCLayer {
    
}

+(CCScene *) scene;

- (void) back:(id)sender;
- (void) getStep:(id)sender;

@end
