//
//  ScoreLayer.m
//  Spacedisc
//
//  Created by iMac on 24/06/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "ScoreLayer.h"
#import "StepLayer.h"
#import "EngineLayer.h"

@implementation ScoreLayer

@synthesize step;

+(CCScene *) scene:(int) s andScore:(int)p andStar:(int)i
{
    // Cria uma Cena e um Layer
	CCScene *scene = [CCScene node];
	ScoreLayer *layer = [ScoreLayer node];
    
    [layer setStep:s];
    [layer config:p andStar:i];
	
    // Adiciona o layer na cena...
	[scene addChild: layer];
    
    // ... e retorna para quem chamou o método
	return scene;
}

-(id) init // Construtor da Classe
{
	if( (self=[super init])) 
    {
    }
    return self;
}
- (void) config:(int)p andStar:(int)i
{
    CGSize size = [[CCDirector sharedDirector] winSize];
    
    CCSprite* fundo  = [CCSprite spriteWithFile:@"spacedisc-bkground-score.jpg"];
    fundo.position = ccp(size.width/2, size.height/2);
    [self addChild:fundo z:0];
    
    bool enable_next = true;
    
    if (p > 0) {
    
        CCSprite* title  = [CCSprite spriteWithFile:@"spacedisc-score.png"];
        title.position = ccp(540, 640);
        [self addChild:title z:10];
        
        
        [CCMenuItemFont setFontName:@"Helvetica"];
        [CCMenuItemFont setFontSize:32];
        
        
        CCMenuItemFont * label = [CCMenuItemFont itemFromString:[NSString stringWithFormat:@"Level %i",step]];
        label.position = ccp(540,530);
        [self addChild:label z:20];
        
        int number = p;
        
        [CCMenuItemFont setFontSize:50];
        CCMenuItemFont * score = [CCMenuItemFont itemFromString:[NSString stringWithFormat:@"%i",number]];
        score.position = ccp(540,420);
        [self addChild:score z:20];
        
        int number_star = i;
        
        if(i < 3) enable_next = false;
        
        for (int s=0; s < 6; s++) {
            
            CCSprite* star;
            if(s < number_star){
                star = [CCSprite spriteWithFile:@"spacedisc-star-on.png"];
            }else{
                star = [CCSprite spriteWithFile:@"spacedisc-star-off.png"];
            }
            switch (s) {
                case 0:
                    star.position = ccp(412,332);
                    break;
                case 1:
                    star.position = ccp(464,332);
                    break;
                case 2:
                    star.position = ccp(516,332);
                    break;
                case 3:
                    star.position = ccp(567,332);
                    break;
                case 4:
                    star.position = ccp(619,332);
                    break;
                case 5:
                    star.position = ccp(670,332);
                    break;
            }
            [self addChild:star z:15];
        }
    }else{
        CCSprite* title  = [CCSprite spriteWithFile:@"spacedisc-levelfailed.fw.png"];
        title.position = ccp(540, 640);
        [self addChild:title z:10];
        
        CCSprite* sad  = [CCSprite spriteWithFile:@"spacedisc-sad.png"];
        sad.position = ccp(540, 430);
        [self addChild:sad z:10];
        
        enable_next = false;
    }
    
    
    // botao de back
    CCSprite* bt_back_bg = [CCSprite spriteWithFile:@"spacedisc-button.png"];
    CCSprite* txt_back = [CCSprite spriteWithFile:@"spacedisc-back.png"];
    txt_back.position = ccp(54,54);
    [bt_back_bg addChild:txt_back z:10];
    
    CCSprite* bt_back_bg_hover = [CCSprite spriteWithFile:@"spacedisc-button-hover.png"];
    CCSprite* txt_back_hover = [CCSprite spriteWithFile:@"spacedisc-back.png"];
    txt_back_hover.position = ccp(54,54);
    [bt_back_bg_hover addChild:txt_back_hover z:10];
    CCMenuItemSprite* trans_back = [CCMenuItemSprite itemFromNormalSprite:bt_back_bg 
                                                           selectedSprite:bt_back_bg_hover 
                                                                   target:self 
                                                                 selector:@selector(back:)];
    
    // botao de replay
    CCSprite* bt_replay_bg = [CCSprite spriteWithFile:@"spacedisc-button.png"];
    CCSprite* txt_replay = [CCSprite spriteWithFile:@"spacedisc-replay.png"];
    txt_replay.position = ccp(54,54);
    [bt_replay_bg addChild:txt_replay z:10];
    
    CCSprite* bt_replay_bg_hover = [CCSprite spriteWithFile:@"spacedisc-button-hover.png"];
    CCSprite* txt_replay_hover = [CCSprite spriteWithFile:@"spacedisc-replay.png"];
    txt_replay_hover.position = ccp(54,54);
    [bt_replay_bg_hover addChild:txt_replay_hover z:10];
    CCMenuItemSprite* trans_replay = [CCMenuItemSprite itemFromNormalSprite:bt_replay_bg 
                                                             selectedSprite:bt_replay_bg_hover 
                                                                     target:self 
                                                                   selector:@selector(go2step:)];
    
    trans_replay.tag = 1;
    
    if (self.step < 5 and enable_next) {
        
        // botao de next
        CCSprite* bt_next_bg = [CCSprite spriteWithFile:@"spacedisc-button.png"];
        CCSprite* txt_next = [CCSprite spriteWithFile:@"spacedisc-next.png"];
        txt_next.position = ccp(54,54);
        [bt_next_bg addChild:txt_next z:10];
        
        CCSprite* bt_next_bg_hover = [CCSprite spriteWithFile:@"spacedisc-button-hover.png"];
        CCSprite* txt_next_hover = [CCSprite spriteWithFile:@"spacedisc-next.png"];
        txt_next_hover.position = ccp(54,54);
        [bt_next_bg_hover addChild:txt_next_hover z:10];
        CCMenuItemSprite* trans_next = [CCMenuItemSprite itemFromNormalSprite:bt_next_bg 
                                                               selectedSprite:bt_next_bg_hover 
                                                                       target:self 
                                                                     selector:@selector(go2step:)];
        trans_next.tag = 2;
        
        // Cria o menu com o itens
        CCMenu* menu = [CCMenu menuWithItems:trans_back, trans_replay, trans_next, nil];
        menu.position = ccp((size.width/2)+30,(size.height/2)-180);
        [menu alignItemsHorizontally];
        // Adiciona o menu como filho
        [self addChild:menu z:20];
    }else{
        // Cria o menu com o itens
        CCMenu* menu = [CCMenu menuWithItems:trans_back, trans_replay, nil];
        menu.position = ccp((size.width/2)+30,(size.height/2)-180);
        [menu alignItemsHorizontally];
        // Adiciona o menu como filho
        [self addChild:menu z:20];
    }
}

- (void) back:(id)sender
{    
    [[CCDirector sharedDirector] pushScene:[CCTransitionSlideInL transitionWithDuration:0.3 scene:[StepLayer scene]]];
}

- (void) go2step:(CCMenuItemSprite *)sender
{
    int number = sender.tag;
    if (number == 1) {
        //replay
        number = step;
    } else {
        //next
        number = step+1;
    }
    [[CCDirector sharedDirector] pushScene:[CCTransitionSlideInR transitionWithDuration:0.3 scene:[EngineLayer scene:number]]];
}
- (void) dealloc
{
	[super dealloc];
}

@end
