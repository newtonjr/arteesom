//
//  GameLayer.m
//  Spacedisc
//
//  Created by iMac on 17/04/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//
#import "CCTMXMapInfo+TMXParserExt.h"

#import "Disk.h"
#import "Asteroide.h"
#import "EngineLayer.h"
#import "StepLayer.h"
#import "Asteroide.h"
#import "ScoreLayer.h"
#import "Gerenciador.h"

#define PTM_RATIO 32.0 // Pixels To Meters


@implementation EngineLayer

@synthesize step;

+(CCScene *) scene:(int) s
{
    // Cria uma Cena e um Layer
	CCScene *scene = [CCScene node];
	EngineLayer *layer = [EngineLayer node];
	
    [layer setStep:s];
    
    //configura o cenario e fisica
    [layer config];
    
    // Adiciona o layer na cena...
	[scene addChild: layer];

    // ... e retorna para quem chamou o método
	return scene;
}

- (float) distancia : (float) x1 : (float) y1 : (float) x2 : (float) y2
{
    return sqrt(pow(x1-x2,2.0) + pow(y1-y2,2.0));
}

-(void)update:(ccTime)dt
{
    totalTime += dt;
    currentTime = (int)totalTime;
	if (myTime < currentTime)
	{
		myTime = currentTime;
		[timeLabel setString:[NSString stringWithFormat:@"%i", myTime]];
	}
}

- (float) areaPoligono: (b2PolygonShape) shape // retorna negativo se for CCW
{
    float area = 0.0;
    int n = shape.m_vertexCount;
    for (int i = 0; i < n; ++i)
    {
        int k = (i + 1) % n;
        area += (shape.m_vertices[k].x * shape.m_vertices[i].y) - (shape.m_vertices[i].x * shape.m_vertices[k].y);
    }
    return area;
}

- (b2PolygonShape) invertePoligono: (b2PolygonShape) shape
{
    b2PolygonShape reverseShape;
    reverseShape.m_vertexCount = shape.m_vertexCount;
    int n = shape.m_vertexCount;
    int i,k;
    for (i = n - 1, k = 0; i > -1; --i, ++k)
    {
        reverseShape.m_vertices[i].Set(shape.m_vertices[k].x, shape.m_vertices[k].y);
    }
    return reverseShape;
}

- (void) adicionaPoligonoBox2D: (NSArray*) polyArray noPonto:(CGPoint) posicao
{
    if([polyArray count] > b2_maxPolygonVertices) return;
    
    b2PolygonShape polygon;
    polygon.m_vertexCount = [polyArray count];
    
    int i = 0;
    for(NSValue* pt in polyArray)
    {
        CGPoint point = [pt CGPointValue];
        polygon.m_vertices[i].Set(point.x/PTM_RATIO, point.y/PTM_RATIO);
        i++;
    }
    if([self areaPoligono:polygon] > 0)
    {
        NSLog(@"CW: invertendo para CCW");
        polygon = [self invertePoligono:polygon];
    }
    
    polygon.Set(polygon.m_vertices, polygon.m_vertexCount);
    
    b2BodyDef polyBodyDef;
    polyBodyDef.position.Set(posicao.x/PTM_RATIO,posicao.y/PTM_RATIO);
    b2Body *polyBody = world->CreateBody(&polyBodyDef);
    
    b2FixtureDef polyShapeDef;
    polyShapeDef.shape = &polygon;
    polyBody->CreateFixture(&polyShapeDef);
}

- (void) processaObjetosBox2D
{
    CCTMXObjectGroup* grupo = [mapa objectGroupNamed:@"box2d"];
    NSMutableArray* poligonos = [grupo objects];
    for(NSDictionary* obj in poligonos)
    {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        NSString* pontos = [obj objectForKey:@"polygonPoints"];
        
        NSArray* comVirgula = [pontos componentsSeparatedByString:@" "];
        NSMutableArray* polyArray = [[NSMutableArray new] autorelease];
        for(NSString* pt in comVirgula)
        {
            NSArray* xy = [pt componentsSeparatedByString:@","];
            
            CGPoint xyPT;
            xyPT.x = [[xy objectAtIndex:0] floatValue];
            xyPT.y = -[[xy objectAtIndex:1] floatValue];
            NSValue* valuePT = [NSValue valueWithCGPoint:xyPT];
            [polyArray addObject:valuePT];
        }
        NSLog(@"Processando: %f , %f",px,py);
        [self adicionaPoligonoBox2D:polyArray noPonto:CGPointMake(px,py)];
    }
}

-(id) init // Construtor da Classe
{
	if( (self=[super init])) 
    {
        CGSize size = [[CCDirector sharedDirector] winSize];
        
        CCSprite* fundo  = [CCSprite spriteWithFile:@"spacedisc-bkground-game.jpg"];
        fundo.position = ccp(size.width/2, size.height/2);
        [self addChild:fundo z:0];
        
        
        // BOTAO VOLTAR
        /*
        CCSprite* normal = [CCSprite spriteWithFile:@"spacedisc-button.png"];
        CCSprite* selecionado = [CCSprite spriteWithFile:@"spacedisc-button.png"];
        selecionado.color = ccGRAY;
        CCMenuItemSprite* trans_item = [CCMenuItemSprite itemFromNormalSprite:normal 
                                                               selectedSprite:selecionado 
                                                                       target:self 
                                                                     selector:@selector(voltar:)];
        // Cria o menu com o itens
        CCMenu* menu = [CCMenu menuWithItems:trans_item, nil];
        menu.position = ccp(80,80);
        [menu alignItemsVerticallyWithPadding:20];
        
        // Adiciona o menu como filho
        [self addChild:menu z:20];
         */

        //set time to zero
		myTime = 0;
        
		timeLabel = [CCLabelTTF labelWithString:@"0" fontName:@"Arial" fontSize:48];
		timeLabel.position = CGPointMake(size.width / 2, size.height);
		// Adjust the label's anchorPoint's y position to make it align with the top.
		timeLabel.anchorPoint = CGPointMake(0.5f, 1.0f);
		// Add the time label
		[self addChild:timeLabel];
        
        
        [self schedule:@selector(update:)];
    }
    return self;
}

- (void) config
{
    self.isTouchEnabled = YES;
    //self.isAccelerometerEnabled = YES;
    
    destroy = 0;
    impulse = 0;
    max_points = 0;
    
    //
    // Posição inicial
    //
    CGSize winSize = [CCDirector sharedDirector].winSize;
    float px = winSize.width-30;
    float py = winSize.height-30;
    
    //
    // Criar o Mundo
    //
    b2Vec2 gravity = b2Vec2(0.0f, 0.0f);
    bool doSleep = true; // se o body não estiver se movendo, ele não é simulado
    world = new b2World(gravity, doSleep);
    
    //
    // Configura o gerenciador de contatos
    //
    gerCont = new GerenciadorContatos();
    world->SetContactListener(gerCont);
    
    //
    // Definir as bordas da tela
    //
    b2BodyDef groundBodyDef;
    groundBodyDef.position.Set(0,0);
    b2Body *groundBody = world->CreateBody(&groundBodyDef); // por padrão um body é estático
    
    b2PolygonShape groundBox;
    b2FixtureDef boxShapeDef;
    boxShapeDef.shape = &groundBox;
    
    groundBox.SetAsEdge(b2Vec2(0,0), b2Vec2(winSize.width/PTM_RATIO, 0));
    groundBody->CreateFixture(&boxShapeDef);
    groundBox.SetAsEdge(b2Vec2(0,0), b2Vec2(0, winSize.height/PTM_RATIO));
    groundBody->CreateFixture(&boxShapeDef);
    groundBox.SetAsEdge(b2Vec2(0, winSize.height/PTM_RATIO), 
    b2Vec2(winSize.width/PTM_RATIO, winSize.height/PTM_RATIO));
    groundBody->CreateFixture(&boxShapeDef);
    groundBox.SetAsEdge(b2Vec2(winSize.width/PTM_RATIO, 
    winSize.height/PTM_RATIO), b2Vec2(winSize.width/PTM_RATIO, 0));
    groundBody->CreateFixture(&boxShapeDef);
    
    
    //
    // Cria o disc
    //
    [self setupDisc:px andY:py];
    
    
    //
    // Cria o portal
    //
    portal = [CCSprite spriteWithFile:@"stargate.png"];
    portal.tag = 999;
    
    
    //
    // Cria o ast
    //
    nextAsteroid = 0;
    
    switch (step) {
        case 2:
            mapa = [CCTMXTiledMap tiledMapWithTMXFile:@"cenario-02.tmx"];
            portal.position = ccp((winSize.width/2)+30, (winSize.height/2)+10);
            break;
        case 3:
            mapa = [CCTMXTiledMap tiledMapWithTMXFile:@"cenario-03.tmx"];
            portal.position = ccp((winSize.width/2)+16, (winSize.height/2));
            break;
        case 4:
            mapa = [CCTMXTiledMap tiledMapWithTMXFile:@"cenario-04.tmx"];
            portal.position = ccp(310, 175);
            break;
        case 5:
            mapa = [CCTMXTiledMap tiledMapWithTMXFile:@"cenario-05.tmx"];
            portal.position = ccp((winSize.width/2)-140, (winSize.height/2)+80);
            break;
        case 1:
        default:
            mapa = [CCTMXTiledMap tiledMapWithTMXFile:@"cenario-01.tmx"];
            portal.position = ccp(winSize.width/2, winSize.height/2);
            break;
    }
    
    [self addChild:portal z:0];

    
    [self addChild:mapa];
    [self processaObjetosBox2D];
    
    
    [self schedule:@selector(tick:)];
}

//
// funcao para valores randomicos
//
- (float)randomValueBetween:(float)low andValue:(float)high {
    return (((float) arc4random() / 0xFFFFFFFFu) * (high - low)) + low;
}

-(void) setupDisc:(float) x andY:(float) y
{
    //
    // Cria o Body e o Shape do disco (círculo)
    //
    discTouch = false;
    Disk * disc;
    disc = [Disk spriteWithFile:@"spacedisc-disc.png"];
    disc.tag = 666;
    [disc setup];
    [self addChild:disc z:1];
    
    b2BodyDef ballBodyDef;
    ballBodyDef.type = b2_dynamicBody;
    ballBodyDef.position.Set(x/PTM_RATIO, y/PTM_RATIO); // posição inicial do body (em metros)
    ballBodyDef.userData = disc; // aqui fica a ligação entre o sprite do Cocos2D e o body do Box2D
    body = world->CreateBody(&ballBodyDef);
    
    b2CircleShape circle;
    circle.m_radius = 40.0/PTM_RATIO; // raio do círculo em metros (26 é o raio da estrela, que tem 52 pixels de largura)
    
    //
    // Conecta o Shape no Body com um Fixture
    //
    b2FixtureDef ballShapeDef;
    ballShapeDef.shape = &circle;
    ballShapeDef.density = 1.0f;
    ballShapeDef.friction = 0.6f;
    ballShapeDef.restitution = 0.5f;
    body->CreateFixture(&ballShapeDef);
}

-(void) setupAst:(float) x andY:(float) y andT:(int) t
{
    //
    // Cria o asteroide
    //
    //CCSprite* ast;
    Asteroide* ast;
    nextAsteroid++;
    b2BodyDef ballBodyDef;
    ballBodyDef.type = b2_dynamicBody;
    ballBodyDef.position.Set(x/PTM_RATIO, y/PTM_RATIO); // posição inicial do body (em metros)
    b2CircleShape circle;
    
    switch (t) {
        case 3:
            ast = [Asteroide spriteWithFile:@"spacedisc-asteroide-grande.png"];
            ast.tag = 3;
            [ast setVida:5];
            max_points += 15;
            circle.m_radius = 64.0/PTM_RATIO;
            break;
        case 2:
            ast = [Asteroide spriteWithFile:@"spacedisc-asteroide-medio.png"];
            ast.tag = 2;
            [ast setVida:3];
            max_points += 5;
            circle.m_radius = 32.0/PTM_RATIO;
            break;
        case 1:
            ast = [Asteroide spriteWithFile:@"spacedisc-asteroide-pequeno.png"];
            ast.tag = 1;
            max_points += 1;
            circle.m_radius = 16.0/PTM_RATIO;
            break;
        default:
            break;
    }
    ballBodyDef.userData = ast; // aqui fica a ligação entre o sprite do Cocos2D e o body do Box2D
    bodyAst = world->CreateBody(&ballBodyDef);
    [self addChild:ast];
    
    //
    // Conecta o Shape no Body com um Fixture
    //
    b2FixtureDef ballShapeDef;
    ballShapeDef.shape = &circle;
    ballShapeDef.density = 1.0f;
    ballShapeDef.friction = 0.6f;
    ballShapeDef.restitution = 0.5f;
    bodyAst->CreateFixture(&ballShapeDef);
    
    b2Vec2 pos = bodyAst->GetPosition();
    
    CGSize winSize = [CCDirector sharedDirector].winSize;
    float randY = [self randomValueBetween:0.0 andValue:winSize.height];
    float randX = [self randomValueBetween:0.0 andValue:winSize.width];
    
    b2Vec2 force;
    force.x = (randX - pos.x);
    force.y = (randY - pos.y);
    
    bodyAst->ApplyLinearImpulse(force, pos);

}

- (void)tick:(ccTime) dt 
{    
    world->Step(dt, 10, 10);
    
    
    std::vector<b2Body *> toDestroy;
    
    while(gerCont->count())
    {
        //contato
        contato ct = gerCont->popContato();
        
        b2Body* bodyA = ct.fixtureA->GetBody();
        b2Body* bodyB = ct.fixtureB->GetBody();
        Asteroide* spriteA = (Asteroide*)bodyA->GetUserData();
        Asteroide* spriteB = (Asteroide*)bodyB->GetUserData();
        
        if((spriteA.tag == 666 && spriteB.tag == 1) || (spriteA.tag == 1 && spriteB.tag == 666))
        {
            //NSLog(@"NAVE COLIDE COM AST PEQUENO");
            if(spriteA.tag == 1)
            {
                if(std::find(toDestroy.begin(), toDestroy.end(), bodyA) == toDestroy.end())
                {
                    toDestroy.push_back(bodyA);
                    destroy += 1;
                }
                Disk* spriteB = (Disk*)bodyB->GetUserData();
                int ener = spriteB.energy;
                ener = ener - 3;
                [spriteB setEnergy:ener];
                [spriteB nivel];
            }
            else
            {
                if(std::find(toDestroy.begin(), toDestroy.end(), bodyB) == toDestroy.end())
                {
                    toDestroy.push_back(bodyB);
                    destroy += 1;
                }
                Disk* spriteA = (Disk*)bodyA->GetUserData();
                int ener = spriteA.energy;
                ener = ener - 3;
                [spriteA setEnergy:ener];
                [spriteA nivel];
            }
            /*
            CCParticleSystemQuad* boom = [CCParticleSystemQuad particleWithFile:@"Explosao.plist"];
            boom.position = ccp(ct.ponto.x * PTM_RATIO,ct.ponto.y * PTM_RATIO);
            boom.autoRemoveOnFinish = YES;
            [self addChild:boom];
            */
        }
        else if((spriteA.tag == 666 && spriteB.tag == 2) || (spriteA.tag == 2 && spriteB.tag == 666))
        {
            //NSLog(@"NAVE COLIDE COM AST MEDIO");
            if(spriteA.tag == 2)
            {
                if(spriteA.vida <= 0)
                {
                    if(std::find(toDestroy.begin(), toDestroy.end(), bodyA) == toDestroy.end())
                    {
                        toDestroy.push_back(bodyA);
                        destroy += 5;
                    }
                }
                else
                {
                    int vida = spriteA.vida;
                    vida = vida - 1;
                    [spriteA setVida:vida];
                }
                Disk* spriteB = (Disk*)bodyB->GetUserData();
                int ener = spriteB.energy;
                ener = ener - 5;
                [spriteB setEnergy:ener];
                [spriteB nivel];
            }
            else
            {
                if(spriteB.vida <= 0)
                {
                    if(std::find(toDestroy.begin(), toDestroy.end(), bodyB) == toDestroy.end())
                    {
                        toDestroy.push_back(bodyB);
                        destroy += 5;
                    }
                }
                else
                {
                    int vida = spriteB.vida;
                    vida = vida - 1;
                    [spriteB setVida:vida];
                }
                Disk* spriteA = (Disk*)bodyA->GetUserData();
                int ener = spriteA.energy;
                ener = ener - 3;
                [spriteA setEnergy:ener];
                [spriteA nivel];
            }
            /*
            CCParticleSystemQuad* boom = [CCParticleSystemQuad particleWithFile:@"Explosao.plist"];
            boom.position = ccp(ct.ponto.x * PTM_RATIO,ct.ponto.y * PTM_RATIO);
            boom.autoRemoveOnFinish = YES;
            [self addChild:boom];
            */
        }
        else if((spriteA.tag == 666 && spriteB.tag == 3) || (spriteA.tag == 3 && spriteB.tag == 666))
        {
            if(spriteA.tag == 3)
            {
                if(spriteA.vida <= 0)
                {
                    if(std::find(toDestroy.begin(), toDestroy.end(), bodyA) == toDestroy.end())
                    {
                        toDestroy.push_back(bodyA);
                        destroy += 15;
                    }
                }
                else
                {
                    int vida = spriteA.vida;
                    vida = vida - 1;
                    [spriteA setVida:vida];
                }
                Disk* spriteB = (Disk*)bodyB->GetUserData();
                int ener = spriteB.energy;
                ener = ener - 10;
                [spriteB setEnergy:ener];
                [spriteB nivel];
            }
            else
            {
                if(spriteB.vida <= 0)
                {
                    if(std::find(toDestroy.begin(), toDestroy.end(), bodyB) == toDestroy.end())
                    {
                        toDestroy.push_back(bodyB);
                        destroy += 15;
                    }
                }
                else
                {
                    int vida = spriteB.vida;
                    vida = vida - 1;
                    [spriteB setVida:vida];
                }
                Disk* spriteA = (Disk*)bodyA->GetUserData();
                int ener = spriteA.energy;
                ener = ener - 3;
                [spriteA setEnergy:ener];
                [spriteA nivel];
            }
            /*
            CCParticleSystemQuad* boom = [CCParticleSystemQuad particleWithFile:@"Explosao.plist"];
            boom.position = ccp(ct.ponto.x * PTM_RATIO,ct.ponto.y * PTM_RATIO);
            boom.autoRemoveOnFinish = YES;
            [self addChild:boom];
            */
        }
        else
        {
            CCParticleSystemQuad* boom = [CCParticleSystemQuad particleWithFile:@"Explosao.plist"];
            boom.position = ccp(ct.ponto.x * PTM_RATIO,ct.ponto.y * PTM_RATIO);
            boom.autoRemoveOnFinish = YES;
            [self addChild:boom];
        }
    }
    
    std::vector<b2Body *>::iterator pos;
    for (pos = toDestroy.begin(); pos != toDestroy.end(); ++pos) {
        b2Body * by = *pos;
        if(by->GetUserData() != NULL)
        {
            CCSprite * sprite = (CCSprite *) by->GetUserData();
            if(sprite.tag == 1) [self removeChild:sprite cleanup:YES];
            else if(sprite.tag == 2) [self removeChild:sprite cleanup:YES];
            else if(sprite.tag == 3) [self removeChild:sprite cleanup:YES];
        }
        world->DestroyBody(by);
    }
    
    CGSize winSize = [CCDirector sharedDirector].winSize;
    
    double curTime = CACurrentMediaTime();
    if (curTime > nextAsteroidSpawn)
    {
        
        float numerodeasteroide = [self randomValueBetween:1.0 andValue:5.0];
        
        for (int i=0; i < numerodeasteroide; i++)
        {
            float randSecs = [self randomValueBetween:0.20 andValue:20.0];
            nextAsteroidSpawn = randSecs + curTime;
        
            float randY = [self randomValueBetween:0.0 andValue:winSize.height];
            float randX = [self randomValueBetween:0.0 andValue:winSize.width];
            float randT = [self randomValueBetween:1.0 andValue:3.0];
        
            [self setupAst: randX andY:randY andT:(int)randT];
        }
    }

    b2Body *b = world->GetBodyList();
    while( b != NULL ) 
    {    
        if (b->GetUserData() != NULL) 
        {
            CCSprite *estrela = (CCSprite *)b->GetUserData();
            //NSLog(@"tag %d", estrela.tag);
            estrela.position = ccp(b->GetPosition().x * PTM_RATIO,
                                   b->GetPosition().y * PTM_RATIO);
            estrela.rotation = -1 * CC_RADIANS_TO_DEGREES(b->GetAngle()); // Converte de radianos para graus
            
        }
        
        b = b->GetNext();
    }
    
    
    b2Vec2 p = body->GetPosition();
    Disk* disk = (Disk*)body->GetUserData();
    CGPoint pp = portal.position;
    
    if([self distancia:pp.x :pp.y :p.x*PTM_RATIO :p.y*PTM_RATIO] < 44)
    {
        [self go2Score];
    }
    else
    {
        if (disk.dead) {
            [self go2Score];
        }
    }
    
    /*
    CCSprite* hell = (CCSprite*)[self getChildByTag:666];
    rastro.position = hell.position;
    */
}

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event 
{
    UITouch *myTouch = [touches anyObject];
    CGPoint location = [myTouch locationInView:[myTouch view]];
    location = [[CCDirector sharedDirector] convertToGL:location];
    
    b2Vec2 locationWorld = b2Vec2(location.x/PTM_RATIO, location.y/PTM_RATIO);
    b2Vec2 pos = body->GetPosition();
    
    if([self distancia:locationWorld.x :locationWorld.y :pos.x :pos.y] < 2.0)
    {
        if(discTouch)
        {
            Disk* disc = (Disk*)body->GetUserData();
            int ener = disc.energy;
            ener = ener + 5;
            if (ener > 100) {
                ener = 100;
            }
            [disc setEnergy:ener];
            [disc nivel];
        }
        
        b2Vec2 force;
        force.x = 0;
        force.y = 0;
        
        body->ApplyLinearImpulse(force, pos);
        
        discTouch = true;
    }
    else
    {
        discTouch = false;
    }
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(discTouch)
    {
        UITouch *myTouch = [touches anyObject];
        CGPoint location = [myTouch locationInView:[myTouch view]];
        location = [[CCDirector sharedDirector] convertToGL:location];
    
        b2Vec2 locationWorld = b2Vec2(location.x/PTM_RATIO, location.y/PTM_RATIO);
        b2Vec2 pos = body->GetPosition();
    
        b2Vec2 force;
        force.x = (locationWorld.x - pos.x)*10.0;
        force.y = (locationWorld.y - pos.y)*10.0;
    
        body->ApplyLinearImpulse(force, pos);
        
        impulse++;
        discTouch = false;
    }
}

- (void) voltar:(id)sender
{
    [[CCDirector sharedDirector] popScene];
}

- (void) go2Score
{
    Disk* spriteB = (Disk*)body->GetUserData();
    int score = 0;
    int star = 0;

    if(spriteB.dead == false)
    {
        //
        // Calculo de destroyyy
        //
        int max_impulse = 15;
        
        if(impulse > 10)
            max_impulse = 1;
        else if(impulse > 8)
            max_impulse = 5;
        else if(impulse > 5)
            max_impulse = 15;
        else if(impulse > 3)
            max_impulse = 25;
        else if (impulse > 1)
            max_impulse = 30;
        
        max_points += max_impulse;
        
        int bonus_time = 15;
        if(myTime > 5) bonus_time = 0;
        
        int ener = spriteB.energy;
        
        int bonus_ener = ((ener * 10) / 100);
        
        //max_points += bonus_ener;
        
        score  = bonus_ener + destroy + max_impulse + bonus_time;
        
        float perc = (score * 100 / max_points);
        
        if (perc > 150) {
            star = 5;
        }else if(perc > 120){
            star = 4;
        }else if(perc > 90){
            star = 3;
        }else if(perc > 75){
            star = 2;
        }else if(perc > 45){
            star = 1;
        }else{
            star = 0;
        }
        
        Gerenciador * manager = [Gerenciador sharedInstance];
        NSArray * steps = manager.conf.steps;
        Step * fase = [steps objectAtIndex:(step-1)];

        int points = fase.points;
        if(points < score){
            [fase setPoints:score];
        }
        int estrelas = fase.star;
        if(estrelas < star){
            [fase setStar:star];
        }
        
        if(estrelas > 2 && step < 6){
            fase = [steps objectAtIndex:step];
            [fase setOpen:true];
        }
    }
    
    [[CCDirector sharedDirector] pushScene:[CCTransitionMoveInB transitionWithDuration:1.0 scene:[ScoreLayer scene:step andScore:score andStar:star]]];
}

@end
