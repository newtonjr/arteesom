//
//  Asteroide.m
//  Spacedisc
//
//  Created by Unisinos Universidade on 15/05/12.
//  Copyright 2012 Universidade do Vale do Rio dos Sinos. All rights reserved.
//

#import "Asteroide.h"


@implementation Asteroide

@synthesize vida;

-(id) init
{
	if( (self=[super init])) 
    {
        vida = 1;
    }
    return self;
}

@end
