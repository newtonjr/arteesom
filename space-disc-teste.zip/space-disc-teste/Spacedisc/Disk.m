//
//  Disk.m
//  Spacedisc
//
//  Created by Unisinos Universidade on 24/05/12.
//  Copyright 2012 Universidade do Vale do Rio dos Sinos. All rights reserved.
//

#import "Disk.h"


@implementation Disk

@synthesize energy, dead;

-(id) init
{
	if( (self=[super init])) 
    {
        energy = 100;
        dead = false;
    }
    return self;
}

-(void) setup
{
    nivel01 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel01.png"];
    nivel01.position = ccp(50,50);
    nivel01.tag = 1;
    [self addChild:nivel01];
    
    nivel02 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel02.png"];
    nivel02.position = ccp(50,50);
    nivel02.tag = 2;
    [nivel02 setVisible:false];
    [self addChild:nivel02];
    
    nivel03 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel03.png"];
    nivel03.position = ccp(50,50);
    nivel03.tag = 3;
    [nivel03 setVisible:false];
    [self addChild:nivel03];
    
    nivel04 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel04.png"];
    nivel04.position = ccp(50,50);
    nivel04.tag = 4;
    [nivel04 setVisible:false];
    [self addChild:nivel04];
    
    nivel05 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel05.png"];
    nivel05.position = ccp(50,50);
    nivel05.tag = 5;
    [nivel05 setVisible:false];
    [self addChild:nivel05];

    nivel06 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel06.png"];
    nivel06.position = ccp(50,50);
    nivel06.tag = 6;
    [nivel06 setVisible:false];
    [self addChild:nivel06];
    
    nivel07 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel07.png"];
    nivel07.position = ccp(50,50);
    nivel07.tag = 7;
    [nivel07 setVisible:false];
    [self addChild:nivel07];
    
    nivel08 = [CCSprite spriteWithFile:@"spacedisc-disc-nivel08.png"];
    nivel08.position = ccp(50,50);
    nivel08.tag = 8;
    [nivel08 setVisible:false];
    [self addChild:nivel08];
    
}

-(void) nivel
{
    if (energy > 90) {
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 1){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
        
    }else if(energy > 75){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 2){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
    }else if(energy > 65){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 3){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
    }else if(energy > 50){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 4){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
    }else if(energy > 40){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 5){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
    }else if(energy > 30){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 6){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
    }else if(energy > 20){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 7){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
    }else if(energy > 10){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            if(node.tag == 8){
                [node setVisible:true];
            }
            else
            {
                [node setVisible:false];
            }
        }
    }else if(energy <= 0){
        CCArray * arr = self.children;
        CCSprite *node;
        CCARRAY_FOREACH(arr, node){
            [node setVisible:false];
        }
    }else{
        dead = true;
    }
}

@end
