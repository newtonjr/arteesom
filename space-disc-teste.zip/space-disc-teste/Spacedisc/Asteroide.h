//
//  Asteroide.h
//  Spacedisc
//
//  Created by Unisinos Universidade on 15/05/12.
//  Copyright 2012 Universidade do Vale do Rio dos Sinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Asteroide : CCSprite {
    int vida;
}

@property int vida;

@end
