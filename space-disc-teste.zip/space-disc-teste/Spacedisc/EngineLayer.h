//
//  EngineLayer.h
//  Spacedisc
//
//  Created by Unisinos Universidade on 24/04/12.
//  Copyright 2012 Universidade do Vale do Rio dos Sinos. All rights reserved.
//

#import "cocos2d.h"
#import "Box2D.h"
#import "GLES-Render.h"
#import "GerenciadorContatos.h"

@interface EngineLayer : CCLayer {
    b2World *world;
    b2Body *body;
    b2Body *bodyAst;
    CCSprite * portal;
    CCTMXTiledMap* mapa;
    GerenciadorContatos* gerCont;
    CCParticleSystemPoint* rastro;
    
    bool discTouch;
    double nextAsteroidSpawn;
    int nextAsteroid;
    int step;
    
    CCLabelTTF *timeLabel;
	ccTime totalTime;
	int myTime;
	int currentTime;
    
    int destroy;
    int impulse;
    
    int max_points;
}

@property int step;

+(CCScene *) scene:(int)s;

- (void) config;
- (void) voltar:(id)sender;
- (void) setupDisc:(float) x andY:(float) y;
- (void) setupAst:(float) x andY:(float) y andT:(int) t;
- (void) update:(ccTime)dt;
- (void) go2Score;

@end
