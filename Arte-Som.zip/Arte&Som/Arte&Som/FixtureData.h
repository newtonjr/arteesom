//
//  FixtureData.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/25/13.
//
//

#import "cocos2d.h"
#import "Box2D.h"

@interface FixtureData : NSObject {
}

@property b2Body * body;
@property int tag;

@end
