//
//  DrawingLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/26/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "DrawingLayer.h"
#import "FixtureData.h"

@implementation DrawingLayer

@synthesize active, viewPoint;

-(id) init {
	if( (self=[super init])) {
        
        self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
        //
        // Load brush
        //
        sBrush = [CCSprite spriteWithFile:@"brush_test.png"];
        [sBrush retain];
        
        target = [CCRenderTexture renderTextureWithWidth:SCREEN.width height:SCREEN.height pixelFormat:kCCTexture2DPixelFormat_RGBA8888];
        target.position = ccp( SCREEN.width / 2, SCREEN.height / 2);
        [target retain];
        
        viewPoint = CGPointZero;
        
//        bullet = [CCSprite spriteWithFile:@"Default-Landscape.png"];
//        bullet.position = ccp( SCREEN.width / 2, SCREEN.height / 2);
//        [self addChild:bullet];
        
        self.active = false;
        
        NSLog(@"Draw init");
        
        [self scheduleUpdate];
        
    }
    return self;
}

-(void)update: (ccTime) dt {
    target.position = ccp( (SCREEN.width / 2) + (viewPoint.x * -1), (SCREEN.height / 2) + (viewPoint.y * -1));
    //bullet.position = target.position;
    //NSLog(@"%f %f",target.position.x,target.position.y);
}

-(void)setPhysicsWorld:(b2World *) b2World {
    world = b2World;
}

-(void) addRectangleBetweenPointsToBody:(b2Body *)body startPoint:(CGPoint)start endPoint:(CGPoint)end {
    
    float distance = sqrt(pow(end.x - start.x,2) + pow(end.y - start.y, 2));
    
    float sx = start.x;
    float sy = start.y;
    float ex = end.x;
    float ey = end.y;
    float dist_x = sx-ex;
    float dist_y = sy-ey;
    float angle = atan2(dist_y,dist_x);
    
    float px= (sx+ex)/2/PTM_RATIO - body->GetPosition().x;
    float py = (sy+ey)/2/PTM_RATIO - body->GetPosition().y;
    
    float width = fabsf(distance)/PTM_RATIO;
    float height = sBrush.boundingBox.size.height / PTM_RATIO;
    //float height = sBrush.boundinbog.size.height /PTM_RATIO;
    
    b2PolygonShape boxShape;
    boxShape.SetAsBox(width / 2, height / 2, b2Vec2(px,py),angle);
    
    FixtureData * fixtureData = [[FixtureData alloc] init];
    fixtureData.tag = kFixtureIdentifyGroung;
    fixtureData.body = body;
    
    b2FixtureDef boxFixtureDef;
    boxFixtureDef.userData = fixtureData;
    boxFixtureDef.shape = &boxShape;
    boxFixtureDef.density = 5;
    
    body->CreateFixture(&boxFixtureDef);
}

- (CGRect) getBodyRectangle:(b2Body *)body {
    CGSize s = [CCDirector sharedDirector].winSize;
    
    float minX2 = s.width;
    float maxX2 = 0;
    float minY2 = s.height;
    float maxY2 = 0;
    
    const b2Transform& xf = body->GetTransform();
    for (b2Fixture* f = body->GetFixtureList(); f; f = f->GetNext()) {
        
        b2PolygonShape* poly = (b2PolygonShape*)f->GetShape();
        int32 vertexCount = poly->m_vertexCount;
        b2Assert(vertexCount <= b2_maxPolygonVertices);
        
        for (int32 i = 0; i < vertexCount; ++i)
        {
            b2Vec2 vertex = b2Mul(xf, poly->m_vertices[i]);
            
            
            if(vertex.x < minX2)
            {
                minX2 = vertex.x;
            }
            
            if(vertex.x > maxX2)
            {
                maxX2 = vertex.x;
            }
            
            if(vertex.y < minY2)
            {
                minY2 = vertex.y;
            }
            
            if(vertex.y > maxY2)
            {
                maxY2 = vertex.y;
            }
        }
    }
    
    maxX2 *= PTM_RATIO;
    minX2 *= PTM_RATIO;
    maxY2 *= PTM_RATIO;
    minY2 *= PTM_RATIO;
    
    float width2 = maxX2 - minX2;
    float height2 = maxY2 - minY2;
    
    float remY2 = s.height - maxY2;
    
    return CGRectMake(minX2, remY2, width2, height2);
}

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    if (active) {
        //
        // if exist currentbody destroy
        //
        if (currentSprite != nil) {
            [self removeChild:currentSprite cleanup:true];
            world->DestroyBody(currentBody);
        }
        
        //
        // create tempbody
        //
        UITouch *touch = [touches anyObject];

        plataformPoints = [[CCArray alloc] initWithCapacity:1];

        CGPoint loc = [touch locationInView:[touch view]];
        loc = [[CCDirector sharedDirector] convertToGL: loc];
        
        //NSLog(@"%f %f",loc.x, loc.y);
        
        loc = ccp(loc.x + (viewPoint.x * -1), loc.y + (viewPoint.y * -1));

        [plataformPoints addObject:[NSValue valueWithCGPoint:loc]];

        previousLocation = loc;

        b2BodyDef myBodyDef;
        myBodyDef.type = b2_staticBody;
        myBodyDef.position.Set(loc.x/PTM_RATIO,loc.y/PTM_RATIO);
        tempBody = world->CreateBody(&myBodyDef);
    }
}

- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
     if (active) {
         
        UITouch *touch = [touches anyObject];
        
        CGPoint start = [touch locationInView:[touch view]];
        start = [[CCDirector sharedDirector] convertToGL: start];

        CGPoint end = [touch previousLocationInView:[touch view]];
        end = [[CCDirector sharedDirector] convertToGL:end];
         
        [target begin];
        
        float distance = ccpDistance(start, end);
        
        for (int i =0; i < distance; i++) {
            float difx = end.x - start.x;
            float dify = end.y - start.y;
            float delta = i / distance;
            sBrush.position = ccp(start.x + (difx * delta), start.y + (dify * delta));
            [sBrush visit];
        }
        
        [target end];
         
         
//         start = ccp(start.x + (viewPoint.x * -1), start.y + (viewPoint.y * -1));
//         end = ccp(end.x + (viewPoint.x * -1), end.y + (viewPoint.y * -1));
    

         CGPoint loc = start;//[touch locationInView:[touch view]];
        //loc = [[CCDirector sharedDirector] convertToGL: loc];
         
        loc = ccp(loc.x + (viewPoint.x * -1), loc.y + (viewPoint.y * -1));
        
        distance = sqrt(pow(loc.x - previousLocation.x, 2) + pow(loc.y - previousLocation.y, 2));
        
        if (distance > 15) {
            [self addRectangleBetweenPointsToBody:tempBody startPoint:previousLocation endPoint:loc];
            [plataformPoints addObject:[NSValue valueWithCGPoint:loc]];
            previousLocation = loc;
        }
    }
}

- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if (active) {
        b2BodyDef myBodyDef;
        
        //this will be a dynamic body
        myBodyDef.type = b2_dynamicBody;
        
        //set the starting position
        myBodyDef.position.Set(tempBody->GetPosition().x, tempBody->GetPosition().y);
        currentBody = world->CreateBody(&myBodyDef);
        
        NSValue *nodePrev = NULL;
        NSValue *nodeAct = NULL;
        CCARRAY_FOREACH(plataformPoints, nodeAct) {
            if (nodePrev != NULL) {
                [self addRectangleBetweenPointsToBody:currentBody startPoint:nodePrev.CGPointValue endPoint:nodeAct.CGPointValue];
            }
            nodePrev = nodeAct;
        }
        
        world->DestroyBody(tempBody);
        
        CGSize s = SCREEN;
        
        CGRect bodyRectangle = [self getBodyRectangle:currentBody];
        
        CGImage * pImage = [target newCGImage];
        
        //CCTexture2D * tex = [[CCTextureCache sharedTextureCache] addCGImage:pImage forKey:nil];
        CCTexture2D * tex = [[CCTexture2D alloc] initWithCGImage:pImage resolutionType:kCCResolutioniPad];
        
        CFRelease(pImage);
        
        CGRect bodyScreen = CGRectMake(bodyRectangle.origin.x + viewPoint.x, bodyRectangle.origin.y + (viewPoint.y * -1), bodyRectangle.size.width, bodyRectangle.size.height);
        
//        NSLog(@"p: %f %f",bodyRectangle.origin.x,bodyRectangle.origin.y);
//        NSLog(@"p: %f %f",viewPoint.x,viewPoint.y);
//        NSLog(@"p: %f %f",bodyScreen.origin.x,bodyScreen.origin.y);
        
        currentSprite = [PhysicsSprite spriteWithTexture:tex rect:bodyScreen];
        [self addChild:currentSprite];
        
        float anchorX = currentBody->GetPosition().x * PTM_RATIO - bodyRectangle.origin.x;
        float anchorY = bodyRectangle.size.height - (s.height - bodyRectangle.origin.y - currentBody->GetPosition().y * PTM_RATIO);
        
        //NSLog(@"p: %f %f",anchorX,anchorY);
        
        currentSprite.anchorPoint = ccp(anchorX / bodyRectangle.size.width,  anchorY / bodyRectangle.size.height);
        
        [currentSprite setPhysicsBody:currentBody];
        
        [self removeChild:target cleanup:true];
        [target release];
        
        target = [CCRenderTexture renderTextureWithWidth:s.width height:s.height pixelFormat:kCCTexture2DPixelFormat_RGBA8888];
        [target retain];
        target.position = ccp( s.width / 2, s.height / 2);
        
        [self addChild:target];
    }
}

@end
