//
//  MyCocos2DClass.m
//  Spacedisc
//
//  Created by iMac on 24/06/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Step.h"

@implementation Step

//@synthesize points, star, open;

- (Step*) init
{
    self = [super init];
    if(self)
    {
        self.points = 0;
        self.star = 0;
        self.open = false;
    }
    return self;
}


- (Step*) initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        self.points = [aDecoder decodeIntForKey:@"POINTS"];
        self.star = [aDecoder decodeIntForKey:@"STAR"];
        self.open = [aDecoder decodeBoolForKey:@"OPEN"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeInteger:_points forKey:@"POINTS"];
    [aCoder encodeInteger:_star forKey:@"STAR"];
    [aCoder encodeBool:_open forKey:@"OPEN"];
}

@end


