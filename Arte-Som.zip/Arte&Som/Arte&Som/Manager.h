//  Baseado na
//
//  Singleton.h
//  BaseCocos2D
//  
//  Created by Farlei Jose Heinen on 04/04/11.
//  Copyright 2011 Ficta. All rights reserved.
//

#import "Config.h"

@interface Manager : NSObject
{
    Config* conf;
}

@property(nonatomic, retain) Config* conf;

+ (Manager*) sharedInstance;

- (NSString*) configFile;
- (void) salvar;
- (void) carregar;

@end