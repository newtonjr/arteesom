//
//  ActionSprite.m
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "SimpleAudioEngine.h"
#import "ActionSprite.h"

@implementation ActionSprite

@synthesize actionState, size, fixtureData;

-(b2Body*)getBody {
    return body_;
}
-(void) setFixedRotation:(bool)fixedRotation;
{
    assert(body_);
    body_->SetFixedRotation(fixedRotation);
}

-(void)definePhysics:(b2World*)world b2BodyType:(b2BodyType)type fixturedef:(b2FixtureDef)fixture {
    b2PolygonShape polygonShape;
    
    int num = 4;
    float halfw = size.width / 2;
    float halfh = size.height / 2;
    
    b2Vec2 vertices[] = {
        b2Vec2(-halfw / PTM_RATIO, -halfh / PTM_RATIO),
        b2Vec2(halfw / PTM_RATIO, -halfh / PTM_RATIO),
        b2Vec2(halfw / PTM_RATIO, halfh / PTM_RATIO),
        b2Vec2(-halfw / PTM_RATIO, halfh / PTM_RATIO)
    };
    
    polygonShape.Set(vertices, num);
    
    b2BodyDef bodyDef;
    bodyDef.type = type;
    bodyDef.angularVelocity = 0;
    //bodyDef.position.Set((self.position.x + halfw) / PTM_RATIO,(self.position.y + halfh) / PTM_RATIO);
    bodyDef.position.Set((self.position.x) / PTM_RATIO, self.position.y / PTM_RATIO);
    bodyDef.angle = 0;
    
    body_ = world->CreateBody(&bodyDef);
    
    fixtureData.body = body_;
    
    fixture.shape = &polygonShape;
    fixture.userData = fixtureData;
    
    body_->CreateFixture(&fixture);
    //body_->SetUserData([self retain]);
    
    //body_->SetGravityScale(-1.0);
}

-(void)idle {
    if (actionState != kActionStateIdle) {
        //NSLog(@"idle");
        
        [self stopAllActions];
        //[self runAction:_idleAction];
        actionState = kActionStateIdle;
        _velocity = CGPointZero;
    }
}

-(void)walkWithDirection:(CGPoint)direction {
    //NSLog(@"walkWithDirection");
    if (actionState == kActionStateIdle) {
        [self stopAllActions];
        //[self runAction:_walkAction];
        actionState = kActionStateWalk;
    }
    if (actionState == kActionStateWalk) {
        
        // get the current velocity
        b2Vec2 velocity = body_->GetLinearVelocity();
        float vX = velocity.x;
        
        // clamp velocity
        const float maxVelocity = 5.0;
        float v = velocity.Length();
        if(v > maxVelocity)
        {
            body_->SetLinearVelocity(maxVelocity/v*velocity);
        }
        
        bool isLeft = (direction.x < 0);

        if((isLeft && (vX > -_walkMaxSpeed)) || ((!isLeft && (vX < _walkMaxSpeed)))) {
            
            b2Vec2 force;
            force.x = _walkSpeed * direction.x;
            force.y = 0;
            
            //NSLog(@"walkWithDirection: %f %f", force.x, force.y);
            
            body_->ApplyLinearImpulse(force, body_->GetWorldCenter());
        }
    }
}

-(void)hurtWithDamage:(float)damage {
    if (actionState != kActionStateKnockedOut) {
        [self stopAllActions];
        [self runAction:_hurtAction];
        actionState = kActionStateHurt;
        _hitPoints -= damage;
        
//        int randomSound = random_range(0, 1);
//        [[SimpleAudioEngine sharedEngine] playEffect:[NSString stringWithFormat:@"pd_hit%d.caf", randomSound]];
        
        if (_hitPoints <= 0.0) {
            [self knockout];
        }
    }
}

-(void)knockout {
    [self stopAllActions];
    [self runAction:_knockedOutAction];
    _hitPoints = 0.0;
    actionState = kActionStateKnockedOut;
}

-(void)update:(ccTime)dt {
//    if (actionState == kActionStateWalk || actionState == kActionStateRun) {
//        _desiredPosition = ccpAdd(position_, ccpMult(_velocity, dt));
//    }
}

-(void)setPosition:(CGPoint)position {
    [super setPosition:position];
}

@end
