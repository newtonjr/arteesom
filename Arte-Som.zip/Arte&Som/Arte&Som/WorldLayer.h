//
//  WorldLayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface WorldLayer : CCLayer {
    BOOL isMultiplayer;
    BOOL isFirstplayer;
    
    CCMenuItemImage *itemModoOne;
    CCMenuItemImage *itemModoTwo;
    
    CCMenuItemImage *itemTipoSound;
    CCMenuItemImage *itemTipoArt;
    
    CCMenuItemToggle * itemTipo;
}

// returns a CCScene that co ntains the WorldLayer as the only child
+(CCScene *) scene;

@end
