//
//  ActionMusic.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 12/2/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "ActionSprite.h"

@interface ActionMusic : ActionSprite {
    BOOL hasColor;
    BOOL isPaint;
    BOOL selected;
}

@property BOOL hasColor;
@property BOOL isPaint;
@property BOOL selected;

-(void)paintElement:(float)perc;

@end
