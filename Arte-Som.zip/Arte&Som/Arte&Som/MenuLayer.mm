//
//  MenuLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#import "GCHelper.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"

#import "MenuLayer.h"
#import "StoryLayer.h"
#import "WorldLayer.h"
#import "ScoreLayer.h"
#import "SettingsLayer.h"
#import "Manager.h"


@implementation MenuLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MenuLayer *layer = [MenuLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super init])) {
		
		// enable events
		self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
		CGSize s = [CCDirector sharedDirector].winSize;
        
        CCSprite *background;
        
        background = [CCSprite spriteWithFile:@"tl-inicial.jpg"];

        background.position = ccp(s.width/2, s.height/2);
        
        // add the label as a child to this Layer
        [self addChild: background z:0];
		
		// create reset button
		[self createMenu];
	}
	return self;
}

-(void) createMenu
{
    // Configuration Menu Item using blocks
//	CCMenuItem *itemSettings = [CCMenuItemFont itemWithString:@"Configuração" block:^(id sender) {
//        //
//        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[SettingsLayer scene] withColor:ccWHITE]];
//	}];
    
    CCLabelTTF *labelLevel = [CCLabelTTF labelWithString:@"novo jogo" fontName:@"Marker Felt" fontSize:34];
    [labelLevel setColor:ccc3(0,0,0)];
    
    CCMenuItemLabel *itemLevel = [CCMenuItemLabel itemWithLabel:labelLevel block:^(id sender) {
        //
        [[Manager sharedInstance].conf reset];
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[StoryLayer scene] withColor:ccWHITE]];
//        [Manager sharedInstance].conf.levelActual = 1;
//        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[ScoreLayer scene:600 andMax:780] withColor:ccWHITE]];
	}];
    
    // Load game Menu Item using blocks
	
    CCLabelTTF *labelWorld = [CCLabelTTF labelWithString:@"continuar" fontName:@"Marker Felt" fontSize:34];
    [labelWorld setColor:ccc3(0,0,0)];
    
    CCMenuItemLabel *itemWorld = [CCMenuItemLabel itemWithLabel:labelWorld block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[WorldLayer scene] withColor:ccWHITE]];
	}];
    
    // Load game Menu Item using blocks
    
    CCLabelTTF *labelScore = [CCLabelTTF labelWithString:@"game center" fontName:@"Marker Felt" fontSize:34];
    [labelScore setColor:ccc3(0,0,0)];
    
    CCMenuItemLabel *itemScore = [CCMenuItemLabel itemWithLabel:labelScore block:^(id sender) {
        //
        [[GCHelper sharedInstance] gamecenter];
	}];
	
	CCMenu *menu = [CCMenu menuWithItems:itemLevel, itemWorld, itemScore, nil];

    [menu alignItemsVerticallyWithPadding:68];
	
	[menu setPosition:ccp(SCREEN.width/2, 170)];

    [self addChild:menu z:1];
}

@end
