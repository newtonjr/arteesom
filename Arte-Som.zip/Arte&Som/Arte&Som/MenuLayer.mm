//
//  MenuLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#import "GCHelper.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"

#import "MenuLayer.h"
#import "StoryLayer.h"
#import "WorldLayer.h"
#import "SettingsLayer.h"


@implementation MenuLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MenuLayer *layer = [MenuLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super init])) {
		
		// enable events
		self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
		CGSize s = [CCDirector sharedDirector].winSize;
		
		// create reset button
		[self createMenu];
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Arte&Som" fontName:@"Marker Felt" fontSize:32];
		[self addChild:label z:0];
		[label setColor:ccc3(0,0,255)];
		label.position = ccp(s.width/2, s.height-50);
	}
	return self;
}

-(void) createMenu
{
	// Default font size will be 22 points.
	[CCMenuItemFont setFontSize:22];
	
	// New game Menu Item using blocks
	CCMenuItem *itemNewGame = [CCMenuItemFont itemWithString:@"Novo jogo" block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[StoryLayer scene] withColor:ccWHITE]];
	}];
	
	// Load game Menu Item using blocks
	CCMenuItem *itemLoadGame = [CCMenuItemFont itemWithString:@"Continuar" block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[WorldLayer scene] withColor:ccWHITE]];
	}];
    
    // Configuration Menu Item using blocks
	CCMenuItem *itemSettings = [CCMenuItemFont itemWithString:@"Configuração" block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[SettingsLayer scene] withColor:ccWHITE]];
	}];
    
    // Load game Menu Item using blocks
	CCMenuItem *itemGameCenter = [CCMenuItemFont itemWithString:@"Game Center" block:^(id sender) {
        //
        // Login in game center
        //
        if ([GCHelper sharedInstance].userAuthenticated == YES) {
            GKLeaderboardViewController *leaderboardViewController = [[GKLeaderboardViewController alloc] init];
            leaderboardViewController.leaderboardDelegate = self;
            
            AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
            
            [[app navController] presentModalViewController:leaderboardViewController animated:YES];
            
            [leaderboardViewController release];
        } else {
            [[GCHelper sharedInstance] authenticateLocalUser];
        }
	}];
	
	CCMenu *menu = [CCMenu menuWithItems:itemNewGame, itemLoadGame, itemSettings, itemGameCenter, nil];
	
	[menu alignItemsVertically];
	
	CGSize size = [[CCDirector sharedDirector] winSize];
	[menu setPosition:ccp( size.width/2, size.height/2)];
	
	
	[self addChild: menu z:-1];
}

#pragma mark GameKit delegate

-(void) achievementViewControllerDidFinish:(GKAchievementViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}

-(void) leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}

@end
