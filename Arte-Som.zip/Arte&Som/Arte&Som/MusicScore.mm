//
//  MusicScore.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/29/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "MusicScore.h"


@implementation MusicScore

@synthesize score, maxScore;

-(id)init {
    if ((self = [super init])) {
        
        [self setup];
        
        int i, j, h;
        
        _getScore = NO;
        
        //
        // read the songs
        //
        NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"songs" ofType:@"plist" ];
        NSMutableArray * list = [NSMutableArray arrayWithContentsOfFile:plistPath];
        songs = [[CCArray alloc] initWithCapacity:list.count];
        
        for (i = 0; i < list.count; i++) {
            NSMutableArray * s = [[NSMutableArray alloc] initWithArray:list[i]];
            
            CCArray * arr = [[CCArray alloc] initWithCapacity:s.count];
            
            for (j = 0; j < s.count; j++) {
                NSMutableArray * z = [[NSMutableArray alloc] initWithArray:s[j]];
                
                CCArray * a = [[CCArray alloc] initWithCapacity:z.count];
                
                for (h = 0; h < z.count; h++) {
                    [a addObject:z[h]];
                }
                
                [arr addObject:a];
            }
            
            [songs addObject:arr];
        }
        
        //NSLog(@"%i", songs.count);
    }
    return self;
}

-(void)setup {
    _max = 3;
    _count = 0;
    _running = NO;
    allRunning = NO;
    
    time = 0;
    step = MUSIC_VALUE_TIME / 8;
    
    elements = [[CCArray alloc] initWithCapacity:_max];
    
    label = [CCLabelTTF labelWithString:@"1" fontName:@"Marker Felt" fontSize:20];
    label.opacity = 0;
    [label setColor:ccc3(255,10,10)];
    
    [self addChild:label z:1];
    
    labelShadow = [CCLabelTTF labelWithString:@"1" fontName:@"Marker Felt" fontSize:20];
    labelShadow.opacity = 0;
    [labelShadow setColor:ccc3(0,0,0)];
    
    [self addChild:labelShadow z:0];
}

-(void)start:(BOOL)hasBar andIndexSong:(int)song{
    if (_count != 0 && _running == NO) {

        _running = YES;
        score = maxScore = 0;
        
        ActionMusic * el;
        
        //
        // selecting song of the array
        //
        CCArray * list = (CCArray *)[songs objectAtIndex:(_count-1)];
        
        if (song < 0) {
            _indexSong = random_range(0, list.count-1);
        }else{
            _indexSong = song;
        }
        
        currentSong = [list objectAtIndex:_indexSong];
        
        //currentSong = [list randomObject];
        
        //NSLog(@"%i", currentSong.count);
        
        missing = maxNotes = currentSong.count;
        
        symbols = [[CCArray alloc] initWithCapacity:missing];
        id ms;
        float icctime = 0;
        CCARRAY_FOREACH(currentSong, ms) {
            //SongNote n = el;
            NSArray* songnote = [ms componentsSeparatedByString:@" "];
            
            //NSLog(@"%@", songnote[1]);
            int type = [songnote[1] integerValue];
            
            MusicSymbol * note = [MusicSymbol node];
            [note setup:songnote[0] andTime:icctime andType:type];
            
            maxScore += note.highValue;
            
            if (_count == 2) {
                maxScore += note.highValue * 0.20;
            } else if (_count == 3) {
                maxScore += note.highValue * 0.40;
            }
            
            icctime += MUSIC_VALUE_TIME / type;
            
            el = [elements randomObject];
            
            float xx = frandom_range(0, el.size.width / 2);
            float xxx = random_range(0, 100);
            
            b2Vec2 position = [el getBody]->GetPosition();
            
            if ((int)xxx % 2 == 0) {
                xx = (position.x * PTM_RATIO) - xx;
            } else {
                xx = (position.x * PTM_RATIO) + xx;
            }
            
            note.position = note.startPoint = ccp(xx, (position.y * PTM_RATIO));
            
            //[note run];
            
            [self addChild:note z:2];
            [symbols addObject:note];
            
            //NSLog(@"%f", icctime);
        }
        
        //
        //
        //
        sprites = [[CCArray alloc] initWithCapacity:_count];
        
        
        CCARRAY_FOREACH(elements, el) {
            el.isPaint = YES;
            
            CCSprite * line = [CCSprite spriteWithFile:@"line.png"];
            //line.position = ccp(el.position.x,el.position.y + 100);
            b2Vec2 position = [el getBody]->GetPosition();
            line.position = ccp((position.x * PTM_RATIO), (position.y * PTM_RATIO) + 100);
            
            //NSLog(@"%f %f", el.position.x, el.position.y);
            line.visible = hasBar;
            
            [self addChild:line z:1];
            [sprites addObject:line];
        }
        
        //[self scheduleUpdate];
        
        [self schedule:@selector(tick:) interval:MUSIC_VALUE_TIME / 8];
    }
}

//
// RETORNA SE PODE INICIAR
//
-(BOOL)addElement:(ActionMusic *) el {
    if (_count < _max) {
        [elements addObject:el];
        ++_count;
        if (_count == _max) {
            //[self start];
            return YES;
        }
    }
    return NO;
}

-(void)tick: (ccTime) dt {
    //NSLog(@"tick musicscore");
    
    MusicSymbol * note;
    
    if (allRunning == NO) {
        allRunning = YES;
        CCARRAY_FOREACH(symbols, note) {
            if (note.running == NO) {
                allRunning = NO;
                if(time >= note.time) {
                    [note run];
                }
            }
            //NSLog(@"| %f", note.position.y);
        }
    } else {
        note = [symbols lastObject];
        if (note.finished == YES) {
            [self finish];
        }
    }
    
    if (missing <= 0) {
        [self finish];
    }
    
    time += step;
}

-(void)finish {
    
    [self unschedule:@selector(tick:)];
    
    CCSprite * sp;
    CCARRAY_FOREACH(sprites, sp) {
        [self removeChild:sp cleanup:true];
    }
    MusicSymbol * note;
    CCARRAY_FOREACH(symbols, note) {
        if (note.finished == NO) {
            [note finish];
        }
        [self removeChild:note cleanup:true];
    }
    
    float perc = 100 * (maxNotes - missing) / maxNotes;
    
    ActionMusic * el;
    CCARRAY_FOREACH(elements, el) {
        el.isPaint = NO;
        el.selected = NO;
        //NSLog(@"missing %i",missing);
        if (perc > 35) {
            [el paintElement:perc];
            _getScore = YES;
        }
    }
    
    [self setup];
}

-(void)keyTouch:(NSString *) key {
    BOOL another = NO;
    BOOL playedNote = NO;
    MusicSymbol * note;
    CCARRAY_FOREACH(symbols, note) {
        // NSLog(@"notes %@ == %@", key, note.name);
        
        if (note.played == YES || note.running == NO) {
            //
            //
            //
            continue;
            
        } else {
            if (note.played == NO && [key compare:note.name] == NSOrderedSame) {
                
                float start = note.startPoint.y;
                float actual = note.position.y;
                float position = actual - start;
                float percentage = 0;
                
                //
                // SE MAIOR QUE 110 SIGNIFICA QUE A NOTA PASSOU A LINHA
                // E ELA PERDE SEU VALOR
                //
                if (position > 105) {
                    position = 100;// - (position - 100);
                }
                
                if (position > 90) {
                    percentage = 1.0;
                } else if (position > 60) {
                    percentage = 0.70;
                } else if (position > 30) {
                    percentage = 0.50;
                } else {
                    percentage = 0.20;
                }
                
                // NSLog(@"%f %f %f %f", start, actual, position, percentage);
                
                //
                // verify if the note correct
                //
                int point;
                if (another == YES) {
                    //
                    // late note
                    //
                    point = note.lowValue * percentage;
                    
                    if (_count == 2) {
                        point += note.lowValue * 0.20;
                    } else if (_count == 3) {
                        point += note.lowValue * 0.40;
                    }
                } else {
                    point = note.highValue * percentage;
                    
                    if (_count == 2) {
                        point += note.highValue * 0.20;
                    } else if (_count == 3) {
                        point += note.highValue * 0.40;
                    }
                }
                
                
                [note showPoints:point];
                score += point;
                
                // NSLog(@"score %f", score);
                playedNote = YES;
                
                note.played = YES;
                
                [note finish];
                missing--;
                
                break;
                
            } else {
                another = YES;
            }
        }
    }
    
    //
    // note wrong, lose point
    //
    if (playedNote == NO) {
        
        //
        //
        //
        
        score -= 20;
        
        ActionMusic * el = [elements randomObject];
        if (el != nil) {
            b2Vec2 position = [el getBody]->GetPosition();
            
            [label setString:[NSString stringWithFormat:@"-%i",20]];
            [labelShadow setString:[NSString stringWithFormat:@"-%i",20]];
            
            label.position = ccp((position.x * PTM_RATIO), (position.y * PTM_RATIO));
            labelShadow.position = ccp(label.position.x-1,label.position.y-1);
            
            id action1 = [CCFadeIn actionWithDuration:0.25];
            id action2 = [CCDelayTime actionWithDuration:0.5];
            id action3 = [CCFadeOut actionWithDuration:0.25];
            
            [label runAction:[CCSequence actions:action1,action2,action3,nil]];
            
            id action4 = [CCFadeIn actionWithDuration:0.25];
            id action5 = [CCDelayTime actionWithDuration:0.5];
            id action6 = [CCFadeOut actionWithDuration:0.25];
            [labelShadow runAction:[CCSequence actions:action4,action5,action6,nil]];
        }
        
        if (score < -200) {
            score = maxScore = 0;
            //
            // END ANIMATION
            //
            [self finish];
        }
    }
    // NSLog(@"touchKey");
    
}
@end
