//
//  MusicScore.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/29/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "MusicScore.h"


@implementation MusicScore


-(id)init {
    if ((self = [super init])) {
        
        [self setup];
        
        int i, j, h;
        
        //
        // read the songs
        //
        NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"songs" ofType:@"plist" ];
        NSMutableArray * list = [NSMutableArray arrayWithContentsOfFile:plistPath];
        songs = [[CCArray alloc] initWithCapacity:list.count];
        
        for (i = 0; i < list.count; i++) {
            NSMutableArray * s = [[NSMutableArray alloc] initWithArray:list[i]];
            
            CCArray * arr = [[CCArray alloc] initWithCapacity:s.count];
            
            for (j = 0; j < s.count; j++) {
                NSMutableArray * z = [[NSMutableArray alloc] initWithArray:s[j]];
                
                CCArray * a = [[CCArray alloc] initWithCapacity:z.count];
                
                for (h = 0; h < z.count; h++) {
                    [a addObject:z[h]];
                }
                
                [arr addObject:a];
            }
            
            [songs addObject:arr];
        }
        
        //NSLog(@"%i", songs.count);
    }
    return self;
}

-(void)setup {
    _max = 3;
    _count = 0;
    _running = NO;
    allRunning = NO;
    
    time = 0;
    step = MUSIC_VALUE_TIME / 8;
    
    elements = [[CCArray alloc] initWithCapacity:_max];
}

-(void)start {
    if (_count != 0 && _running == NO) {

        _running = YES;
        score = 0;
        
        Element * el;
        
        //
        // selecting song of the array
        //
        CCArray * list = (CCArray *)[songs objectAtIndex:(_count-1)];
        
        currentSong = [list randomObject];
        
        //NSLog(@"%i", currentSong.count);
        
        missing = currentSong.count;
        
        symbols = [[CCArray alloc] initWithCapacity:missing];
        id ms;
        float icctime = 0;
        CCARRAY_FOREACH(currentSong, ms) {
            //SongNote n = el;
            NSArray* songnote = [ms componentsSeparatedByString:@" "];
            
            //NSLog(@"%@", songnote[1]);
            int type = [songnote[1] integerValue];
            
            MusicSymbol * note = [MusicSymbol node];
            [note setup:songnote[0] andTime:icctime andType:type];
            
            icctime += MUSIC_VALUE_TIME / type;
            
            el = [elements randomObject];
            
            float xx = frandom_range(0, el.size.width / 2);
            float xxx = random_range(0, 100);
            
            if ((int)xxx % 2 == 0) {
                xx = el.position.x - xx;
            } else {
                xx = el.position.x + xx;
            }
            
            note.position = note.startPoint = ccp(xx, el.position.y);
            
            //[note run];
            
            [self addChild:note z:2];
            [symbols addObject:note];
            
            //NSLog(@"%f", icctime);
        }
        
        //
        //
        //
        sprites = [[CCArray alloc] initWithCapacity:_count];
        
        
        CCARRAY_FOREACH(elements, el) {
            el.isPaint = YES;
            
            CCSprite * line = [CCSprite spriteWithFile:@"line.png"];
            line.position = ccp(el.position.x,el.position.y + 100);
            
            //NSLog(@"%f %f", el.position.x, el.position.y);
            
            [self addChild:line z:1];
            [sprites addObject:line];
        }
        
        //[self scheduleUpdate];
        
        [self schedule:@selector(tick:) interval:MUSIC_VALUE_TIME / 8];
    }
}

-(void)addElement:(Element *) el {
    if (_count < _max) {
        [elements addObject:el];
        ++_count;
        if (_count == _max) {
            [self start];
        }
    }
}

-(void)tick: (ccTime) dt {
    //NSLog(@"tick musicscore");
    
    MusicSymbol * note;
    
    if (allRunning == NO) {
        allRunning = YES;
        CCARRAY_FOREACH(symbols, note) {
            if (note.running == NO) {
                allRunning = NO;
                if(time >= note.time) {
                    [note run];
                }
            }
            //NSLog(@"| %f", note.position.y);
        }
    } else {
        note = [symbols lastObject];
        if (note.finished == YES) {
            [self finish];
        }
    }
    
    if (missing <= 0) {
        [self finish];
    }
    
    time += step;
}

-(void)finish {
    
    [self unschedule:@selector(tick:)];
    
    CCSprite * sp;
    CCARRAY_FOREACH(sprites, sp) {
        [self removeChild:sp cleanup:true];
    }
    MusicSymbol * note;
    CCARRAY_FOREACH(symbols, note) {
        if (note.finished == NO) {
            [note finish];
        }
        [self removeChild:note cleanup:true];
    }
    
    Element * el;
    CCARRAY_FOREACH(elements, el) {
        el.isPaint = NO;
        el.selected = NO;
        NSLog(@"missing %i",missing);
        if (missing <= 0) {
            el.hasColor = YES;
        }
    }
    
    [self setup];
}

-(void)keyTouch:(NSString *) key {
    BOOL another = NO;
    BOOL playedNote = NO;
    MusicSymbol * note;
    CCARRAY_FOREACH(symbols, note) {
        // NSLog(@"notes %@ == %@", key, note.name);
        
        if (note.played == YES || note.running == NO) {
            //
            //
            //
            continue;
            
        } else {
            if (note.played == NO && [key compare:note.name] == NSOrderedSame) {
                
                float start = note.startPoint.y;
                float actual = note.position.y;
                float position = actual - start;
                float percentage = 0;
                
                if (position > 100) {
                    position = 100 - (position - 100);
                }
                
                if (position > 90) {
                    percentage = 1.0;
                } else if (position > 60) {
                    percentage = 0.70;
                } else if (position > 30) {
                    percentage = 0.50;
                } else {
                    percentage = 0.20;
                }
                
                // NSLog(@"%f %f %f %f", start, actual, position, percentage);
                
                //
                // verify if the note correct
                //
                if (another == YES) {
                    //
                    // late note
                    //
                    score += note.lowValue * percentage;
                } else {
                    score += note.highValue * percentage;
                }
                
                // NSLog(@"score %f", score);
                playedNote = YES;
                
                note.played = YES;
                
                [note finish];
                missing--;
                
                break;
                
            } else {
                another = YES;
            }
        }
    }
    
    //
    // note wrong, lose point
    //
    if (playedNote == NO) {
        
        //
        //
        //
        
        score -= 20;
        
        if (score < -200) {
            //
            // END ANIMATION
            //
            [self finish];
        }
    }
    // NSLog(@"touchKey");
    
}
@end
