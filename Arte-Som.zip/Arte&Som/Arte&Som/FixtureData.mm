//
//  FixtureData.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/25/13.
//
//

#import "FixtureData.h"

@implementation FixtureData

@end