//
//  DrawingLayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/26/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Box2D.h"
#import "PhysicsSprite.h"

@class DrawingLayer;

@protocol DrawingLayerDelegate <NSObject>

-(void)drawingLayer:(DrawingLayer *)drawingLayer pointSelectedStart:(CGPoint)point;
-(void)drawingLayer:(DrawingLayer *)drawingLayer pointSelected:(CGPoint)point;
-(void)drawingLayer:(DrawingLayer *)drawingLayer paintRegion:(CGPoint)start andEnd:(CGPoint)end;
-(void)drawingLayerEnded:(DrawingLayer *)drawingLayer;

@end

@interface DrawingLayer : CCLayer<CCTargetedTouchDelegate> {
	b2World * world;
    b2Body * tempBody;
    b2Body * currentBody;
    
    //
    // points
    //
    CGPoint previousLocation;
    CCArray * plataformPoints;
    CGPoint viewPoint;
    
    //
    // graphics
    //
    PhysicsSprite * currentSprite;
    CCSprite * tempDrawImage;
    CCSprite * sBrush;
//    CCSprite * bullet;
    CCRenderTexture * target;
    
    //
    // default
    //
    bool active;
}

-(void)setPhysicsWorld:(b2World *) b2World;
-(void)createdShape;
-(void)createdShapeTemp:(CGPoint)loc;
-(float)paintTexture:(CGPoint)start andEnd:(CGPoint)end;
-(void)definePreviousLocation:(CGPoint)loc;

@property(nonatomic,retain)id <DrawingLayerDelegate> delegate;

@property bool active;
@property CGPoint viewPoint;

@end
