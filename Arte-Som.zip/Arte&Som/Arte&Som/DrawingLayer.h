//
//  DrawingLayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/26/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Box2D.h"
#import "PhysicsSprite.h"

@interface DrawingLayer : CCLayer<CCTargetedTouchDelegate> {
	b2World * world;
    b2Body * tempBody;
    b2Body * currentBody;
    
    //
    // points
    //
    CGPoint previousLocation;
    CCArray * plataformPoints;
    CGPoint viewPoint;
    
    //
    // graphics
    //
    PhysicsSprite * currentSprite;
    CCSprite * tempDrawImage;
    CCSprite * sBrush;
//    CCSprite * bullet;
    CCRenderTexture * target;
    
    //
    // default
    //
    bool active;
}

-(void)setPhysicsWorld:(b2World *) b2World;

@property bool active;
@property CGPoint viewPoint;

@end
