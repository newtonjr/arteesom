//
//  LevelLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "LevelLayer.h"
#import "WorldLayer.h"
#import "ScoreLayer.h"
#import "PhysicsSprite.h"

@implementation LevelLayer

+(CCScene *)scene:(int) level andInviteFriend:(BOOL) invite {
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	LevelLayer *levelLayer = [LevelLayer node];
    
    [levelLayer initTileMap:level];
    
	// add layer as a child to scene
	[scene addChild: levelLayer z:0];
    
    // add hud layer in game scene
    HudLayer * hudLayer = [HudLayer node];
    [scene addChild:hudLayer z:1];
    
    hudLayer.delegate = levelLayer;
    hudLayer.dPad.delegate = levelLayer;
    hudLayer.keyboard.delegate = levelLayer;
    levelLayer.hud = hudLayer;
    
    //[levelLayer initFriend];
    
    if (invite == YES) {
        AppController * delegate = (AppController *) [UIApplication sharedApplication].delegate;
        [[GCHelper sharedInstance] findMatchWithMinPlayers:2 maxPlayers:2 viewController:delegate.navController delegate:self];
    }
	
	// return the scene
	return scene;
}
//
// read tilemap
//

//
// retorna negativo se for CCW
//
-(float)areaPoligono: (b2PolygonShape) shape {
    float area = 0.0;
    int n = shape.m_vertexCount;
    for (int i = 0; i < n; ++i)
    {
        int k = (i + 1) % n;
        area += (shape.m_vertices[k].x * shape.m_vertices[i].y) - (shape.m_vertices[i].x * shape.m_vertices[k].y);
    }
    return area;
}

-(b2PolygonShape)invertePoligono: (b2PolygonShape) shape {
    b2PolygonShape reverseShape;
    reverseShape.m_vertexCount = shape.m_vertexCount;
    int n = shape.m_vertexCount;
    int i,k;
    for (i = n - 1, k = 0; i > -1; --i, ++k)
    {
        reverseShape.m_vertices[i].Set(shape.m_vertices[k].x, shape.m_vertices[k].y);
    }
    return reverseShape;
}

-(void)adicionaPoligonoBox2D: (NSArray*) polyArray noPonto:(CGPoint) posicao {
    if([polyArray count] > b2_maxPolygonVertices) return;
    
    b2PolygonShape polygon;
    polygon.m_vertexCount = [polyArray count];
    
    int i = 0;
    for(NSValue* pt in polyArray)
    {
        CGPoint point = [pt CGPointValue];
        polygon.m_vertices[i].Set(point.x/PTM_RATIO, point.y/PTM_RATIO);
        i++;
    }
    if([self areaPoligono:polygon] > 0)
    {
        //NSLog(@"CW: invertendo para CCW");
        polygon = [self invertePoligono:polygon];
    }
    
    polygon.Set(polygon.m_vertices, polygon.m_vertexCount);
    
    b2BodyDef polyBodyDef;
    polyBodyDef.position.Set(posicao.x/PTM_RATIO,posicao.y/PTM_RATIO);
    b2Body *polyBody = world->CreateBody(&polyBodyDef);
    
    FixtureData * fixtureData = [[FixtureData alloc] init];
    fixtureData.tag = kFixtureIdentifyGroung;
    fixtureData.body = polyBody;
    
    b2FixtureDef polyShapeDef;
    polyShapeDef.userData = fixtureData;
    polyShapeDef.shape = &polygon;
    polyBody->CreateFixture(&polyShapeDef);
}

-(void)processaObjetosBox2D {
    CCTMXObjectGroup* grupo = [_tileMap objectGroupNamed:@"interaction"];
    NSMutableArray* poligonos = [grupo objects];
    for(NSDictionary* obj in poligonos)
    {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        NSString* pontos = [obj objectForKey:@"polygonPoints"];
        
        NSArray* comVirgula = [pontos componentsSeparatedByString:@" "];
        NSMutableArray* polyArray = [[NSMutableArray new] autorelease];
        for(NSString* pt in comVirgula)
        {
            NSArray* xy = [pt componentsSeparatedByString:@","];
            
            CGPoint xyPT;
            xyPT.x = [[xy objectAtIndex:0] floatValue];
            xyPT.y = -[[xy objectAtIndex:1] floatValue];
            NSValue* valuePT = [NSValue valueWithCGPoint:xyPT];
            [polyArray addObject:valuePT];
        }
        //NSLog(@"Processando: %f , %f",px,py);
        [self adicionaPoligonoBox2D:polyArray noPonto:CGPointMake(px,py)];
    }
}

-(void)initObjects {
    
    CCTMXObjectGroup* grupo = [_tileMap objectGroupNamed:@"startplayer"];
    NSMutableArray* poligonos = [grupo objects];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        
        _firstPlayer = [FirstPlayer node];
        [self addChild:_firstPlayer z:3];
        _firstPlayer.position = ccp(px + 16, py);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        ballShapeDef.density = 2.0f;
        ballShapeDef.friction = 0.5f;
        ballShapeDef.restitution = 0.1f;

        [_firstPlayer definePhysics:world b2BodyType:b2_dynamicBody fixturedef:ballShapeDef];
        [_firstPlayer setFixedRotation:true];
        
        [_firstPlayer idle];
    }
    
    grupo = [_tileMap objectGroupNamed:@"object"];
    poligonos = [grupo objects];

    _elements = [[CCArray alloc] initWithCapacity:poligonos.count];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        
        Element * e = [Element node];
        
        [self addChild:e z:2];
        [_elements addObject:e];
        
        e.position = ccp(px + 16, py);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        ballShapeDef.isSensor = true;
        ballShapeDef.density = 0.0f;
        ballShapeDef.friction = 0.0f;
        ballShapeDef.restitution = 0.0f;
        
        [e definePhysics:world b2BodyType:b2_staticBody fixturedef:ballShapeDef];
        
        //[e idle];
    }
    
    grupo = [_tileMap objectGroupNamed:@"startenemy"];
    poligonos = [grupo objects];
    
    _enemies = [[CCArray alloc] initWithCapacity:poligonos.count];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        
        Enemy * e = [Enemy node];
        
        [self addChild:e z:4];
        [_enemies addObject:e];
        
        e.position = ccp(px + 16, py);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        ballShapeDef.isSensor = true;
        ballShapeDef.density = 0.0f;
        ballShapeDef.friction = 0.0f;
        ballShapeDef.restitution = 0.0f;
        
        [e definePhysics:world b2BodyType:b2_staticBody fixturedef:ballShapeDef];
    }
    
    //
    //end
    //
    
    
    //
    //
    //
    _musicScore = [MusicScore node];
    [self addChild:_musicScore z:2];
}

//
// ini
//
-(id)init {
	if( (self=[super initWithColor:ccc4(255,255,255,255)]) ) {
    //if( (self=[super init]) ) {
        
        //NSLog(@"INIT");
		
		// enable events
		self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
        
        _isFistPlayer = YES;
        
        //
		// create reset button
        //
		[self createMenu];
		
        //
        // title
        //
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Fase" fontName:@"Marker Felt" fontSize:32];
		[self addChild:label z:0];
		[label setColor:ccc3(0,0,255)];
		label.position = ccp(SCREEN.width/2, SCREEN.height-50);
	}
	return self;
}

-(void)initPhysics:(CGSize) s {
	
	b2Vec2 gravity;
	gravity.Set(0.0f, -10.0f);
	world = new b2World(gravity);
	
	
	// Do we want to let bodies sleep?
	world->SetAllowSleeping(true);
	
	world->SetContinuousPhysics(true);
	
	m_debugDraw = new GLESDebugDraw( PTM_RATIO );
	world->SetDebugDraw(m_debugDraw);
	
	uint32 flags = 0;
	flags += b2Draw::e_shapeBit;
	//		flags += b2Draw::e_jointBit;
	//		flags += b2Draw::e_aabbBit;
	//		flags += b2Draw::e_pairBit;
	//		flags += b2Draw::e_centerOfMassBit;
	m_debugDraw->SetFlags(flags);
	
	
	// Define the ground body.
	b2BodyDef groundBodyDef;
	groundBodyDef.position.Set(0, 0); // bottom-left corner
	
	// Call the body factory which allocates memory for the ground body
	// from a pool and creates the ground box shape (also from a pool).
	// The body is also added to the world.
	b2Body* groundBody = world->CreateBody(&groundBodyDef);
	
	// Define the ground box shape.
	b2EdgeShape groundBox;
	
	// bottom
	
	groundBox.Set(b2Vec2(0,0), b2Vec2(s.width/PTM_RATIO,0));
	groundBody->CreateFixture(&groundBox,0);
	
	// top
	groundBox.Set(b2Vec2(0,s.height/PTM_RATIO), b2Vec2(s.width/PTM_RATIO,s.height/PTM_RATIO));
	groundBody->CreateFixture(&groundBox,0);
	
	// left
	groundBox.Set(b2Vec2(0,s.height/PTM_RATIO), b2Vec2(0,0));
	groundBody->CreateFixture(&groundBox,0);
	
	// right
	groundBox.Set(b2Vec2(s.width/PTM_RATIO,s.height/PTM_RATIO), b2Vec2(s.width/PTM_RATIO,0));
	groundBody->CreateFixture(&groundBox,0);
    
    
    //
    //
    //
    _drawing = [DrawingLayer node];
    [_drawing setPhysicsWorld:world];
    [self addChild:_drawing];
}

-(void)initFriend {
    _inviteFriend = YES;
    
    
}
//
// load tile map
//
-(void)initTileMap:(int) level {
    
    // NSLog(@"initTileMap");
    
    _level = level;
    
    //
    // load map.tmx and create the tilemap
    //
    _tileMap = [CCTMXTiledMap tiledMapWithTMXFile:[NSString stringWithFormat:@"map-%i.tmx",_level]];
    
    for (CCTMXLayer *child in [_tileMap children]) {
        [[child texture] setAliasTexParameters];
    }
    
    [self addChild:_tileMap z:1];
    
    //NSLog(@"%f %f",_tileMap.boundingBox.size.width, _tileMap.boundingBox.size.height);
    
    //
    // init physics
    //
    [self initPhysics:_tileMap.boundingBox.size];
    //self.boundingBox.size = _tileMap.boundingBox.size;
    
    //
    // read object in tilemap
    //
    [self processaObjetosBox2D];
    [self initObjects];
    
    
    //
    // tick
    //
    [self scheduleUpdate];
}

-(void)createMenu {
	// Default font size will be 22 points.
	//[CCMenuItemFont setFontSize:22];
    
    // New game Menu Item using blocks
    
    CCLabelTTF *labelLevel = [CCLabelTTF labelWithString:@"Repetir fase" fontName:@"Marker Felt" fontSize:22];
    [labelLevel setColor:ccc3(0,0,0)];
    
	//CCMenuItemLabel *itemLevel = [CCMenuItemFont itemWithString:@"Repetir fase" block:^(id sender) {
    CCMenuItemLabel *itemLevel = [CCMenuItemLabel itemWithLabel:labelLevel block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[LevelLayer scene:_level andInviteFriend:_inviteFriend ] withColor:ccBLACK]];
	}];
    
    // Load game Menu Item using blocks
	
    CCLabelTTF *labelWorld = [CCLabelTTF labelWithString:@"Selecionar fase" fontName:@"Marker Felt" fontSize:22];
    [labelWorld setColor:ccc3(0,0,0)];
    
	//CCMenuItemLabel *itemWorld = [CCMenuItemFont itemWithString:@"Selecionar fase" block:^(id sender) {
    CCMenuItemLabel *itemWorld = [CCMenuItemLabel itemWithLabel:labelWorld block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[WorldLayer scene] withColor:ccBLACK]];
	}];
    
    // Load game Menu Item using blocks
    
    CCLabelTTF *labelScore = [CCLabelTTF labelWithString:@"Finalizar fase" fontName:@"Marker Felt" fontSize:22];
    [labelScore setColor:ccc3(0,0,0)];
    
    //CCMenuItemLabel *itemScore = [CCMenuItemFont itemWithString:@"Finalizar fase" block:^(id sender) {
    CCMenuItemLabel *itemScore = [CCMenuItemLabel itemWithLabel:labelScore block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[ScoreLayer scene] withColor:ccBLACK]];
	}];
	
	CCMenu *menu = [CCMenu menuWithItems:itemLevel, itemWorld, itemScore, nil];
	
	[menu alignItemsVertically];
	
	[menu setPosition:ccp(SCREEN.width/2, SCREEN.height/2)];
	
	[self addChild: menu z:1];
}

-(void)setViewpointCenter:(CGPoint) position {
    
    CGSize winSize = SCREEN;
    
    int x = MAX(position.x, winSize.width / 2);
    int y = MAX(position.y, winSize.height / 2);
    x = MIN(x, (_tileMap.mapSize.width * _tileMap.tileSize.width)
            - winSize.width / 2);
    y = MIN(y, (_tileMap.mapSize.height * _tileMap.tileSize.height)
            - winSize.height/2);
    CGPoint actualPosition = ccp(x, y);
    
    CGPoint centerOfView = ccp(winSize.width/2, winSize.height/2);
    CGPoint viewPoint = ccpSub(centerOfView, actualPosition);
    
    self.position = viewPoint;
    _drawing.viewPoint = viewPoint;
    
    //NSLog(@"VIEW %f %f", viewPoint.x, viewPoint.y);
    //NSLog(@"VIEW %f %f", _drawing.position.x, _drawing.position.y);
}

-(void)update: (ccTime) dt {
	//It is recommended that a fixed time step is used with Box2D for stability
	//of the simulation, however, we are using a variable time step here.
	//You need to make an informed choice, the following URL is useful
	//http://gafferongames.com/game-physics/fix-your-timestep/
	
	int32 velocityIterations = 8;
	int32 positionIterations = 1;
	
	// Instruct the world to perform a single step of simulation. It is
	// generally best to keep the time step and iterations fixed.
	world->Step(dt, velocityIterations, positionIterations);
    
    //
    // MOVE O MAPA
    //
    b2Vec2 p = [_firstPlayer getBody]->GetPosition();
    CGPoint position = ccp(p.x*PTM_RATIO, p.y*PTM_RATIO);
    //NSLog(@"%f", position.x);
    [self setViewpointCenter:position];
}

-(void)draw {
	//
	// IMPORTANT:
	// This is only for debug purposes
	// It is recommend to disable it
	//
	[super draw];
	
	ccGLEnableVertexAttribs( kCCVertexAttribFlag_Position );
	
	kmGLPushMatrix();
	
	world->DrawDebugData();
	
	kmGLPopMatrix();
}

-(void)dealloc {
	delete world;
	world = NULL;
	
	delete m_debugDraw;
	m_debugDraw = NULL;
	
	[super dealloc];
}

-(float) distancia : (float) x1 : (float) y1 : (float) x2 : (float) y2
{
    return sqrt(pow(x1-x2,2.0) + pow(y1-y2,2.0));
}

//
// events
//
-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
}

-(void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    //NSLog(@"ccTouchesMoved");
    if (((_inviteFriend == YES && _isFistPlayer == NO) || (_inviteFriend == NO && _isFistPlayer == YES)) && !_hud.isDrawing && _musicScore.running == NO) {
        UITouch *myTouch = [touches anyObject];
        CGPoint location = [myTouch locationInView:[myTouch view]];
        location = [[CCDirector sharedDirector] convertToGL:location];
        b2Vec2 locationWorld = b2Vec2((location.x-self.position.x)/PTM_RATIO, (location.y-self.position.y)/PTM_RATIO);
        
        Element *node;
        CCARRAY_FOREACH(_elements, node) {
            b2Vec2 pos = [node getBody]->GetPosition();
            
            if(node.hasColor == NO && node.selected == NO && [self distancia:locationWorld.x :locationWorld.y :pos.x :pos.y] < 2.0)
            {
                //NSLog(@"TOUCH");
                node.selected = YES;
                [_musicScore addElement:node];
            }
        }
    }
}

-(void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if (((_inviteFriend == YES && _isFistPlayer == NO) || (_inviteFriend == NO && _isFistPlayer == YES)) && !_hud.isDrawing && _musicScore.running == NO) [_musicScore start];
}

#pragma mark SimpleDPad
-(void)simpleDPad:(SimpleDPad *)simpleDPad didChangeDirectionTo:(CGPoint)direction {
    //NSLog(@"didChangeDirectionTo: %f",direction.x);
    if (_hud.isRunning) {
        if (_isFistPlayer == YES) {
            [_firstPlayer runWithDirection:direction];
        } else {
            [_secondPlayer runWithDirection:direction];
        }
    } else {
        if (_isFistPlayer == YES) {
            [_firstPlayer walkWithDirection:direction];
        } else {
            [_secondPlayer walkWithDirection:direction];
        }
    }
}

-(void)simpleDPadTouchEnded:(SimpleDPad *)simpleDPad {
    //NSLog(@"simpleDPadTouchEnded");
    if (_isFistPlayer == YES) {
        if (_firstPlayer.actionState == kActionStateWalk || _firstPlayer.actionState == kActionStateRun) {
            [_firstPlayer idle];
        }
    } else {
        if (_secondPlayer.actionState == kActionStateWalk || _secondPlayer.actionState == kActionStateRun) {
            [_secondPlayer idle];
        }
    }
}

-(void)simpleDPad:(SimpleDPad *)simpleDPad isHoldingDirection:(CGPoint)direction {
    //NSLog(@"isHoldingDirection: %f",direction.x);
    if (_hud.isRunning) {
        if (_isFistPlayer == YES) {
            [_firstPlayer runWithDirection:direction];
        } else {
            [_secondPlayer runWithDirection:direction];
        }
    } else {
        if (_isFistPlayer == YES) {
            [_firstPlayer walkWithDirection:direction];
        } else {
            [_secondPlayer walkWithDirection:direction];
        }
    }
}

#pragma mark KeyboardLayer
-(void)keyboardLayer:(KeyboardLayer *)keyboardLayer whyKeyPlay:(NSString *)keyId {
    //NSLog(@"%@", keyId);
    if (_musicScore.running == YES) {
        [_musicScore keyTouch:keyId];
    }
}

-(void)keyboardLayerTouchEnded:(KeyboardLayer *)keyboardLayer {
    //NSLog(@"keyboard end");
}

#pragma mark HudLayer
-(void)HudLayer:(HudLayer *)HudLayer pressedButton:(ButtonType)type {
    switch (type) {
        case kButtonTypeJumping:
            if (!_hud.isDrawing) {
                [_firstPlayer jump];
            }
            break;
        case kButtonTypeRunning:
            //[_firstPlayer jump];
            if (_hud.isRunning) {
                NSLog(@"RUN");
            } else {
                NSLog(@"WALK");
            }
            break;
        case kButtonTypeDrawing:
            //[_firstPlayer jump];
            if (_hud.isDrawing) {
                _drawing.active = true;
                NSLog(@"MODE DRAWING ACTIVE");
            } else {
                _drawing.active = false;
                NSLog(@"MODE DRAWING DESACTIVE");
            }
            break;
        default:
            break;
    }
    
}

#pragma mark GCHelperDelegate
- (void)matchStarted {
    NSLog(@"Match started");
//    if (receivedRandom) {
//        [self setGameState:kGameStateWaitingForStart];
//    } else {
//        [self setGameState:kGameStateWaitingForRandomNumber];
//    }
//    [self sendRandomNumber];
//    [self tryStartGame];
}

- (void)inviteReceived {
    NSLog(@"inviteReceived");
//    [self restartTapped:nil];
}

- (void)matchEnded {
    NSLog(@"Match ended");
    [[GCHelper sharedInstance].match disconnect];
    [GCHelper sharedInstance].match = nil;
//    [self endScene:kEndReasonDisconnect];
}

- (void)match:(GKMatch *)match didReceiveData:(NSData *)data fromPlayer:(NSString *)playerID {
    NSLog(@"Match");
    // Store away other player ID for later
//    if (otherPlayerID == nil) {
//        otherPlayerID = [playerID retain];
//    }
//    
//    Message *message = (Message *) [data bytes];
//    if (message->messageType == kMessageTypeRandomNumber) {
//        
//        MessageRandomNumber * messageInit = (MessageRandomNumber *) [data bytes];
//        CCLOG(@"Received random number: %ud, ours %ud", messageInit->randomNumber, ourRandom);
//        bool tie = false;
//        
//        if (messageInit->randomNumber == ourRandom) {
//            CCLOG(@"TIE!");
//            tie = true;
//            ourRandom = arc4random();
//            [self sendRandomNumber];
//        } else if (ourRandom > messageInit->randomNumber) {
//            CCLOG(@"We are player 1");
//            isPlayer1 = YES;
//        } else {
//            CCLOG(@"We are player 2");
//            isPlayer1 = NO;
//        }
//        
//        if (!tie) {
//            receivedRandom = YES;
//            if (gameState == kGameStateWaitingForRandomNumber) {
//                [self setGameState:kGameStateWaitingForStart];
//            }
//            [self tryStartGame];
//        }
//        
//    } else if (message->messageType == kMessageTypeGameBegin) {
//        
//        [self setGameState:kGameStateActive];
//        [self setupStringsWithOtherPlayerId:playerID];
//        
//    } else if (message->messageType == kMessageTypeMove) {
//        
//        CCLOG(@"Received move");
//        
//        if (isPlayer1) {
//            [player2 moveForward];
//        } else {
//            [player1 moveForward];
//        }
//    } else if (message->messageType == kMessageTypeGameOver) {
//        
//        MessageGameOver * messageGameOver = (MessageGameOver *) [data bytes];
//        CCLOG(@"Received game over with player 1 won: %d", messageGameOver->player1Won);
//        
//        if (messageGameOver->player1Won) {
//            [self endScene:kEndReasonLose];
//        } else {
//            [self endScene:kEndReasonWin];
//        }
//        
//    }
}
@end
