//
//  LevelLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#import "Manager.h"

#import "LevelLayer.h"
#import "WorldLayer.h"
#import "ScoreLayer.h"
#import "PhysicsSprite.h"

@implementation LevelLayer

//
// MULTIPLAYER ACTIONS
//
-(void)sendData:(NSData *)data {
    NSError *error;
    BOOL success = [[GCHelper sharedInstance].match sendDataToAllPlayers:data withDataMode:GKMatchSendDataReliable error:&error];
    if (!success) {
        CCLOG(@"Error sending init packet");
        [self matchEnded];
    }
}

//
// actions from player walk, run
//
-(void)sendMove:(CGPoint)direction {
    
    MessageMove message;
    message.message.messageType = kMessageTypeMove;
    message.direction = direction;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageMove)];
    [self sendData:data];
    
}

-(void)sendPosition:(b2Vec2)position andAngle:(Float32)angle {
    
    MessagePlayerPosition message;
    message.message.messageType = kMessageTypePlayerPosition;
    message.position = position;
    message.angle = angle;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessagePlayerPosition)];
    [self sendData:data];
}

-(void)sendRun:(CGPoint)direction {
    
    MessageRun message;
    message.message.messageType = kMessageTypeRun;
    message.direction = direction;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageRun)];
    [self sendData:data];
}

-(void)sendJump {
    
    MessageJump message;
    message.message.messageType = kMessageTypeJump;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageJump)];
    [self sendData:data];
    
}

-(void)sendSelectedElement:(CGPoint)position {
    
    MessageSelectedElement message;
    message.message.messageType = kMessageTypeSelectedElement;
    message.position = position;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageSelectedElement)];
    [self sendData:data];
    
}

-(void)sendStartMusicScore:(int)indexSong {
    
    MessageStartMusicScore message;
    message.message.messageType = kMessageTypeStartMusicScore;
    message.index = indexSong;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageStartMusicScore)];
    [self sendData:data];
    
}

-(void)sendWhyKeyPlayed:(int)key {
    
    MessageWhyKeyPlayed message;
    message.message.messageType = kMessageTypeWhyKeyPlayed;
    message.key = key;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageWhyKeyPlayed)];
    [self sendData:data];
    
}

-(void)sendScore:(int)score andMax:(int)maxScore {
    
    MessageScore message;
    message.message.messageType = kMessageTypeScore;
    message.score = score;
    message.maxScore = maxScore;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageScore)];
    [self sendData:data];
    
}

-(void)sendDrawing:(int)command andStart:(CGPoint)first andEnd:(CGPoint)second {

    MessageDrawing message;
    message.message.messageType = kMessageTypeDrawing;
    message.command = command;
    message.first = first;
    message.second = second;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageDrawing)];
    [self sendData:data];
    
}

//
// stats game
//
-(void)sendGameBegin {
    
    MessageGameBegin message;
    message.message.messageType = kMessageTypeGameBegin;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageGameBegin)];
    [self sendData:data];
    
}

-(void)sendGameOver:(BOOL)player1Won {
    
    MessageGameOver message;
    message.message.messageType = kMessageTypeGameOver;
    message.player1Won = player1Won;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageGameOver)];
    [self sendData:data];
    
}

+(CCScene *)scene {
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	LevelLayer *levelLayer = [LevelLayer node];
    
	// add layer as a child to scene
	[scene addChild: levelLayer z:0];
    
    // add hud layer in game scene
    HudLayer * hudLayer = [HudLayer node];
    [scene addChild:hudLayer z:1];
    
    hudLayer.delegate = levelLayer;
    hudLayer.dPad.delegate = levelLayer;
    hudLayer.keyboard.delegate = levelLayer;
    levelLayer.hud = hudLayer;
	
	// return the scene
	return scene;
}
//
// read tilemap
//

//
// retorna negativo se for CCW
//
-(float)areaPoligono: (b2PolygonShape) shape {
    float area = 0.0;
    int n = shape.m_vertexCount;
    for (int i = 0; i < n; ++i)
    {
        int k = (i + 1) % n;
        area += (shape.m_vertices[k].x * shape.m_vertices[i].y) - (shape.m_vertices[i].x * shape.m_vertices[k].y);
    }
    return area;
}

-(b2PolygonShape)invertePoligono: (b2PolygonShape) shape {
    b2PolygonShape reverseShape;
    reverseShape.m_vertexCount = shape.m_vertexCount;
    int n = shape.m_vertexCount;
    int i,k;
    for (i = n - 1, k = 0; i > -1; --i, ++k)
    {
        reverseShape.m_vertices[i].Set(shape.m_vertices[k].x, shape.m_vertices[k].y);
    }
    return reverseShape;
}

-(void)adicionaPoligonoBox2D: (NSArray*) polyArray noPonto:(CGPoint) posicao {
    if([polyArray count] > b2_maxPolygonVertices) return;
    
    b2PolygonShape polygon;
    polygon.m_vertexCount = [polyArray count];
    
    int i = 0;
    for(NSValue* pt in polyArray)
    {
        CGPoint point = [pt CGPointValue];
        polygon.m_vertices[i].Set(point.x/PTM_RATIO, point.y/PTM_RATIO);
        i++;
    }
    if([self areaPoligono:polygon] > 0)
    {
        //NSLog(@"CW: invertendo para CCW");
        polygon = [self invertePoligono:polygon];
    }
    
    polygon.Set(polygon.m_vertices, polygon.m_vertexCount);
    
    b2BodyDef polyBodyDef;
    polyBodyDef.position.Set(posicao.x/PTM_RATIO,posicao.y/PTM_RATIO);
    b2Body *polyBody = world->CreateBody(&polyBodyDef);
    
    FixtureData * fixtureData = [[FixtureData alloc] init];
    fixtureData.tag = kFixtureIdentifyGroung;
    fixtureData.body = polyBody;
    
    b2FixtureDef polyShapeDef;
    polyShapeDef.userData = fixtureData;
    polyShapeDef.shape = &polygon;
    polyShapeDef.filter.groupIndex = -1;
    //polyShapeDef.filter.maskBits = 0xFFF0;
    polyBody->CreateFixture(&polyShapeDef);
}

-(void)processaObjetosBox2D {
    CCTMXObjectGroup* grupo = [_tileMap objectGroupNamed:@"interaction"];
    NSMutableArray* poligonos = [grupo objects];
    for(NSDictionary* obj in poligonos)
    {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        NSString* pontos = [obj objectForKey:@"polygonPoints"];
        
        NSArray* comVirgula = [pontos componentsSeparatedByString:@" "];
        NSMutableArray* polyArray = [[NSMutableArray new] autorelease];
        for(NSString* pt in comVirgula)
        {
            NSArray* xy = [pt componentsSeparatedByString:@","];
            
            CGPoint xyPT;
            xyPT.x = [[xy objectAtIndex:0] floatValue];
            xyPT.y = -[[xy objectAtIndex:1] floatValue];
            NSValue* valuePT = [NSValue valueWithCGPoint:xyPT];
            [polyArray addObject:valuePT];
        }
        //NSLog(@"Processando: %f , %f",px,py);
        [self adicionaPoligonoBox2D:polyArray noPonto:CGPointMake(px,py)];
    }
}

-(void)initObjects {
    
    CCTMXObjectGroup* grupo = [_tileMap objectGroupNamed:@"startplayer"];
    NSMutableArray* poligonos = [grupo objects];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        
        _firstPlayer = [FirstPlayer node];
        [self addChild:_firstPlayer z:3];
        _firstPlayer.position = ccp(px + 16, py);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        ballShapeDef.density = 2.0f;
        ballShapeDef.friction = 0.5f;
        ballShapeDef.restitution = 0.1f;
        ballShapeDef.filter.groupIndex = -2;
        //ballShapeDef.filter.maskBits = 0xFFF0;

        [_firstPlayer definePhysics:world b2BodyType:b2_dynamicBody fixturedef:ballShapeDef];
        [_firstPlayer setFixedRotation:true];
        
        [_firstPlayer idle];
    }
    
    if (_isMultiplayer == YES) {
        _secondPlayer = [SecondPlayer node];
        [self addChild:_secondPlayer z:3];
        _secondPlayer.position = ccp(_firstPlayer.position.x, _firstPlayer.position.y);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        ballShapeDef.density = 2.0f;
        ballShapeDef.friction = 0.5f;
        ballShapeDef.restitution = 0.1f;
        ballShapeDef.filter.groupIndex = -2;
        
        [_secondPlayer definePhysics:world b2BodyType:b2_dynamicBody fixturedef:ballShapeDef];
        [_secondPlayer setFixedRotation:true];
        
        [_secondPlayer idle];

    }
    
    grupo = [_tileMap objectGroupNamed:@"object"];
    poligonos = [grupo objects];

    _elements = [[CCArray alloc] initWithCapacity:poligonos.count];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        
        Element * e = [Element node];
        
        [self addChild:e z:2];
        [_elements addObject:e];
        
        e.position = ccp(px + 16, py);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        ballShapeDef.isSensor = true;
        ballShapeDef.density = 0.0f;
        ballShapeDef.friction = 0.0f;
        ballShapeDef.restitution = 0.0f;
        
        [e definePhysics:world b2BodyType:b2_staticBody fixturedef:ballShapeDef];
        
        //[e idle];
    }
    
    grupo = [_tileMap objectGroupNamed:@"startenemy"];
    poligonos = [grupo objects];
    
    _enemies = [[CCArray alloc] initWithCapacity:poligonos.count];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        
        Enemy * e = [Enemy node];
        
        e.firstPlayer = _firstPlayer;
        if (_isMultiplayer == YES) {
            e.secondPlayer = _secondPlayer;
        }
        
        [self addChild:e z:4];
        [_enemies addObject:e];
        
        e.position = ccp(px + 16, py);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        //ballShapeDef.isSensor = true;
        ballShapeDef.density = 0.0f;
        ballShapeDef.friction = 0.0f;
        ballShapeDef.restitution = 0.0f;
        ballShapeDef.filter.groupIndex = -1;
        //ballShapeDef.filter.maskBits = 0xFFFF;
        
        [e definePhysics:world b2BodyType:b2_dynamicBody fixturedef:ballShapeDef];
        if (_isFirstplayer == YES) {
            [e startStateMachine];
        }
    }
    
    //
    //end
    //
    grupo = [_tileMap objectGroupNamed:@"end"];
    poligonos = [grupo objects];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        
        saida = [ActionSprite spriteWithFile:@"exit.png"];
        saida.size = CGSizeMake(32.0, 32.0);
        saida.fixtureData = [[FixtureData alloc] init];
        saida.fixtureData.tag = kFixtureIdentifyEnd;

        [self addChild:saida];
        
        saida.position = ccp(px + 16, py - 16);
        
        //
        // Conecta o Shape no Body com um Fixture
        //
        b2FixtureDef ballShapeDef;
        ballShapeDef.isSensor = true;
        ballShapeDef.density = 0.0f;
        ballShapeDef.friction = 0.0f;
        ballShapeDef.restitution = 0.0f;
        
        [saida definePhysics:world b2BodyType:b2_staticBody fixturedef:ballShapeDef];
    }

    //
    //
    //
    _musicScore = [MusicScore node];
    [self addChild:_musicScore z:5];
}

//
// ini
//
-(id)init {
	if( (self=[super initWithColor:ccc4(255,255,255,255)]) ) {
        
		// enable events
		self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
        
        _schedulerRestart = NO;
        
        //
        // get the information from global location
        //
        _level = [Manager sharedInstance].conf.levelActual;
        _isFirstplayer = [Manager sharedInstance].conf.isFirstplayer;
        _isMultiplayer = [Manager sharedInstance].conf.isMultiplayer;
        
        [self initTileMap:_level];
        
        if (_isMultiplayer == YES) {
            gameState = kGameStateWaitingForMatch;
            [[GCHelper sharedInstance] findMatch:(_isFirstplayer == YES ? MyRole_FirstPlayer : MyRole_SecondPlayer) playerGroup:_level delegate:self];
        } else {
            gameState = kGameStateActive;
        }
	}
	return self;
}

-(void)initPhysics:(CGSize) s {
	
	b2Vec2 gravity;
	gravity.Set(0.0f, -10.0f);
	world = new b2World(gravity);
    
    //
    // Configura o gerenciador de contatos
    //
    gerContact = new GerenciadorContatos();
    world->SetContactListener(gerContact);
	
	
	// Do we want to let bodies sleep?
	world->SetAllowSleeping(true);
	
	world->SetContinuousPhysics(true);
	
	m_debugDraw = new GLESDebugDraw( PTM_RATIO );
	world->SetDebugDraw(m_debugDraw);
	
	uint32 flags = 0;
	flags += b2Draw::e_shapeBit;
	//		flags += b2Draw::e_jointBit;
	//		flags += b2Draw::e_aabbBit;
	//		flags += b2Draw::e_pairBit;
	//		flags += b2Draw::e_centerOfMassBit;
	m_debugDraw->SetFlags(flags);
	
	
	// Define the ground body.
	b2BodyDef groundBodyDef;
	groundBodyDef.position.Set(0, 0); // bottom-left corner
	
	// Call the body factory which allocates memory for the ground body
	// from a pool and creates the ground box shape (also from a pool).
	// The body is also added to the world.
	b2Body* groundBody = world->CreateBody(&groundBodyDef);
	
	// Define the ground box shape.
	b2EdgeShape groundBox;
    
    FixtureData * fix = [[FixtureData alloc] init];
    fix.tag = kFixtureIdentifyWorld;
	// bottom
	
	groundBox.Set(b2Vec2(0,0), b2Vec2(s.width/PTM_RATIO,0));
	groundBody->CreateFixture(&groundBox,0)->SetUserData(fix);
	
	// top
	groundBox.Set(b2Vec2(0,s.height/PTM_RATIO), b2Vec2(s.width/PTM_RATIO,s.height/PTM_RATIO));
	groundBody->CreateFixture(&groundBox,0);//->SetUserData(fix);
	
	// left
	groundBox.Set(b2Vec2(0,s.height/PTM_RATIO), b2Vec2(0,0));
	groundBody->CreateFixture(&groundBox,0);//->SetUserData(fix);
	
	// right
	groundBox.Set(b2Vec2(s.width/PTM_RATIO,s.height/PTM_RATIO), b2Vec2(s.width/PTM_RATIO,0));
	groundBody->CreateFixture(&groundBox,0);//->SetUserData(fix);
    
    //
    //
    //
    _drawing = [DrawingLayer node];
    _drawing.delegate = self;
    [_drawing setPhysicsWorld:world];
    [self addChild:_drawing];
}

//
// load tile map
//
-(void)initTileMap:(int) level {
    
    // NSLog(@"initTileMap");
    
    _level = level;
    
    //
    // load map.tmx and create the tilemap
    //
    _tileMap = [CCTMXTiledMap tiledMapWithTMXFile:[NSString stringWithFormat:@"map-%i.tmx",_level]];
    
    for (CCTMXLayer *child in [_tileMap children]) {
        [[child texture] setAliasTexParameters];
    }
    
    [self addChild:_tileMap z:1];
    
    //NSLog(@"%f %f",_tileMap.boundingBox.size.width, _tileMap.boundingBox.size.height);
    
    //
    // init physics
    //
    [self initPhysics:_tileMap.boundingBox.size];
    //self.boundingBox.size = _tileMap.boundingBox.size;
    
    //
    // read object in tilemap
    //
    [self processaObjetosBox2D];
    [self initObjects];
    
    
    //
    // tick
    //
    [self scheduleUpdate];
}

-(void)setViewpointCenter:(CGPoint) position {
    
    CGSize winSize = SCREEN;
    
    int x = MAX(position.x, winSize.width / 2);
    int y = MAX(position.y, winSize.height / 2);
    x = MIN(x, (_tileMap.mapSize.width * _tileMap.tileSize.width)
            - winSize.width / 2);
    y = MIN(y, (_tileMap.mapSize.height * _tileMap.tileSize.height)
            - winSize.height/2);
    CGPoint actualPosition = ccp(x, y);
    
    CGPoint centerOfView = ccp(winSize.width/2, winSize.height/2);
    CGPoint viewPoint = ccpSub(centerOfView, actualPosition);
    
    self.position = viewPoint;
    _drawing.viewPoint = viewPoint;
    
    //NSLog(@"VIEW %f %f", viewPoint.x, viewPoint.y);
    //NSLog(@"VIEW %f %f", _drawing.position.x, _drawing.position.y);
}

-(void)update: (ccTime) dt {
	//It is recommended that a fixed time step is used with Box2D for stability
	//of the simulation, however, we are using a variable time step here.
	//You need to make an informed choice, the following URL is useful
	//http://gafferongames.com/game-physics/fix-your-timestep/
	
	int32 velocityIterations = 8;
	int32 positionIterations = 1;
	
	// Instruct the world to perform a single step of simulation. It is
	// generally best to keep the time step and iterations fixed.
	world->Step(dt, velocityIterations, positionIterations);
    
    //
    // MOVE O MAPA
    //
    b2Vec2 p;
    if (_isFirstplayer == YES) {
        p = [_firstPlayer getBody]->GetPosition();
    } else {
        p = [_secondPlayer getBody]->GetPosition();
    }
    
    CGPoint position = ccp(p.x*PTM_RATIO, p.y*PTM_RATIO);
    //NSLog(@"%f", position.x);
    [self setViewpointCenter:position];
    
    //
    // verificar colisões
    //
    while(gerContact->count()) {
        //contato
        contato ct = gerContact->popContato();
        
        FixtureData *a = (FixtureData*)ct.fixtureA->GetUserData();
        FixtureData *b = (FixtureData*)ct.fixtureB->GetUserData();

        //
        // verifica se colide com a saida
        //
        if (a != nil && b != nil && ((b.tag == kFixtureIdentifyFirstPlayer || a.tag == kFixtureIdentifyFirstPlayer) || (b.tag == kFixtureIdentifySecondPlayer || a.tag == kFixtureIdentifySecondPlayer)) && (b.tag == kFixtureIdentifyEnd || a.tag == kFixtureIdentifyEnd)) {
            
            [self finish];
        }
        
        //
        // verifica se colide mundo
        //
        if (_schedulerRestart == NO) {
            
            if (a != nil && b != nil && ((b.tag == kFixtureIdentifyFirstPlayer || a.tag == kFixtureIdentifyFirstPlayer) || (b.tag == kFixtureIdentifySecondPlayer || a.tag == kFixtureIdentifySecondPlayer)) && (b.tag == kFixtureIdentifyWorld || a.tag == kFixtureIdentifyWorld)) {

                [self scheduleOnce:@selector(restart) delay:1.0];
                
                _schedulerRestart = YES;
            }
        }
    }
    
    if (_isFirstplayer == YES) {
        if (_musicScore.getScore == YES) {
            _score += _musicScore.score;
            _scoreMax += _musicScore.maxScore;
            
            [self sendScore:_score andMax:_scoreMax];
            
            [_hud updateScore:_score];
            
            _musicScore.getScore = NO;
        }
    }
}

-(void)draw {
	//
	// IMPORTANT:
	// This is only for debug purposes
	// It is recommend to disable it
	//
	[super draw];
	
	ccGLEnableVertexAttribs( kCCVertexAttribFlag_Position );
	
	kmGLPushMatrix();
	
	world->DrawDebugData();
	
	kmGLPopMatrix();
}

-(void)dealloc {
	delete world;
	world = NULL;
	
	delete m_debugDraw;
	m_debugDraw = NULL;
	
	[super dealloc];
}

-(float) distancia : (float) x1 : (float) y1 : (float) x2 : (float) y2
{
    return sqrt(pow(x1-x2,2.0) + pow(y1-y2,2.0));
}

-(void)restart {
    [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[LevelLayer scene] withColor:ccBLACK]];
}

-(void)finish {
    //
    //
    //
    [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[ScoreLayer scene:_score andMax:_scoreMax] withColor:ccBLACK]];
}

//
// events touches
//
-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
}

-(void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    if (gameState != kGameStateActive) return;
    
    if (((_isMultiplayer == YES && _isFirstplayer == NO) || (_isMultiplayer == NO && _isFirstplayer == YES)) && !_hud.isDrawing && _musicScore.running == NO) {
        UITouch *myTouch = [touches anyObject];
        CGPoint location = [myTouch locationInView:[myTouch view]];
        location = [[CCDirector sharedDirector] convertToGL:location];
        b2Vec2 locationWorld = b2Vec2((location.x-self.position.x)/PTM_RATIO, (location.y-self.position.y)/PTM_RATIO);
        
        Element *node;
        CCARRAY_FOREACH(_elements, node) {
            b2Vec2 pos = [node getBody]->GetPosition();
            
            if(node.hasColor == NO && node.selected == NO && [self distancia:locationWorld.x :locationWorld.y :pos.x :pos.y] < 2.0)
            {
                //NSLog(@"TOUCH");
                node.selected = YES;
                [_musicScore addElement:node];
                
                //
                // send if multiplayer
                //
                if (_isMultiplayer == YES) {
                    [self sendSelectedElement:CGPointMake(pos.x, pos.y)];
                }
            }
        }
        
        Enemy *nod;
        CCARRAY_FOREACH(_enemies, nod) {
            b2Vec2 pos = [nod getBody]->GetPosition();
            
            if(nod.isHold == YES && nod.selected == NO && [self distancia:locationWorld.x :locationWorld.y :pos.x :pos.y] < 2.0)
            {
                //NSLog(@"TOUCH");
                nod.selected = YES;
                [_musicScore addElement:nod];
                
                //
                // send if multiplayer
                //
                if (_isMultiplayer == YES) {
                    [self sendSelectedElement:CGPointMake(pos.x, pos.y)];
                }
            }
        }
    }
}

-(void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    if (gameState != kGameStateActive) return;
    
    if (((_isMultiplayer == YES && _isFirstplayer == NO) || (_isMultiplayer == NO && _isFirstplayer == YES)) && !_hud.isDrawing && _musicScore.running == NO){
        //
        // send if multiplayer
        //
        if (_isMultiplayer == YES) {
            [self sendStartMusicScore:-1];
        } else {
            [_musicScore start:TRUE andIndexSong:-1];
        }
    }
}

#pragma mark SimpleDPad
-(void)simpleDPad:(SimpleDPad *)simpleDPad didChangeDirectionTo:(CGPoint)direction {
    if (gameState != kGameStateActive) return;
    
    //NSLog(@"didChangeDirectionTo: %f",direction.x);
    if (_hud.isRunning) {
        if (_isFirstplayer == YES) {
            [_firstPlayer runWithDirection:direction];
        } else {
            [_secondPlayer runWithDirection:direction];
        }
        
        if (_isMultiplayer == YES) {
            [self sendRun:direction];
        }
        
    } else {
        if (_isFirstplayer == YES) {
            [_firstPlayer walkWithDirection:direction];
        } else {
            [_secondPlayer walkWithDirection:direction];
        }
        
        if (_isMultiplayer == YES) {
            [self sendMove:direction];
        }
    }
}

-(void)simpleDPadTouchEnded:(SimpleDPad *)simpleDPad {
    if (gameState != kGameStateActive) return;
    
    //NSLog(@"position %f %f",[_firstPlayer getBody]->GetPosition().x, [_firstPlayer getBody]->GetPosition().y);
    if (_isFirstplayer == YES) {
        if (_firstPlayer.actionState == kActionStateWalk || _firstPlayer.actionState == kActionStateRun) {
            [_firstPlayer idle];
        }
        
        if (_isMultiplayer == YES) {
            b2Vec2 pos([_firstPlayer getBody]->GetPosition().x,[_firstPlayer getBody]->GetPosition().y);
            [self sendPosition:pos andAngle:[_firstPlayer getBody]->GetAngle()];
        }
    } else {
        if (_secondPlayer.actionState == kActionStateWalk || _secondPlayer.actionState == kActionStateRun) {
            [_secondPlayer idle];
        }
        
        if (_isMultiplayer == YES) {
            b2Vec2 pos([_secondPlayer getBody]->GetPosition().x,[_secondPlayer getBody]->GetPosition().y);
            [self sendPosition:pos andAngle:[_secondPlayer getBody]->GetAngle()];
        }
    }
}

-(void)simpleDPad:(SimpleDPad *)simpleDPad isHoldingDirection:(CGPoint)direction {
    if (gameState != kGameStateActive) return;
    
    //NSLog(@"isHoldingDirection: %f",direction.x);
    if (_hud.isRunning) {
        if (_isFirstplayer == YES) {
            [_firstPlayer runWithDirection:direction];
        } else {
            [_secondPlayer runWithDirection:direction];
        }
        
        if (_isMultiplayer == YES) {
            [self sendRun:direction];
        }
    } else {
        if (_isFirstplayer == YES) {
            [_firstPlayer walkWithDirection:direction];
        } else {
            [_secondPlayer walkWithDirection:direction];
        }
        
        if (_isMultiplayer == YES) {
            [self sendMove:direction];
        }
    }
}

#pragma mark KeyboardLayer
-(void)keyboardLayer:(KeyboardLayer *)keyboardLayer whyKeyPlay:(int)keyId andName:(NSString *)name {
    if (gameState != kGameStateActive) return;
    
    //NSLog(@"%@", keyId);
    if (_musicScore.running == YES) {
        if (_isMultiplayer == YES) {
            //NSLog(@"sendWhyKeyPlayed");
            [self sendWhyKeyPlayed:keyId];
        }
        
        [_musicScore keyTouch:name];
    }
}

-(void)keyboardLayerTouchEnded:(KeyboardLayer *)keyboardLayer {
    //NSLog(@"keyboard end");
}

#pragma mark Drawing
-(void)drawingLayer:(DrawingLayer *)drawingLayer pointSelectedStart:(CGPoint)point{
    //NSLog(@"drawingLayer pointSelectedStart %f %f", point.x , point.y);
    if (_isMultiplayer == YES) {
        [self sendDrawing:1 andStart:point andEnd:CGPointZero ];
    }
}
-(void)drawingLayer:(DrawingLayer *)drawingLayer paintRegion:(CGPoint)start andEnd:(CGPoint)end{
    //NSLog(@"drawingLayer paintRegion %f %f", start.x , start.y);
    if (_isMultiplayer == YES) {
        [self sendDrawing:2 andStart:start andEnd:end ];
    }

}
-(void)drawingLayer:(DrawingLayer *)drawingLayer pointSelected:(CGPoint)point{
    //NSLog(@"drawingLayer pointSelected");
    if (_isMultiplayer == YES) {
        [self sendDrawing:3 andStart:point andEnd:CGPointZero ];
    }
}
-(void)drawingLayerEnded:(DrawingLayer *)drawingLayer{
    //NSLog(@"drawingLayerEnded");
    if (_isMultiplayer == YES) {
        [self sendDrawing:4 andStart:CGPointZero andEnd:CGPointZero ];
    }
}

#pragma mark HudLayer
-(void)HudLayer:(HudLayer *)HudLayer pressedButton:(ButtonType)type {
    if (gameState != kGameStateActive) return;
    
    switch (type) {
        case kButtonTypeJumping:
            if (!_hud.isDrawing) {
                if (_isFirstplayer == YES) {
                    [_firstPlayer jump];
                } else {
                    [_secondPlayer jump];
                }
                
                if (_isMultiplayer == YES) {
                    [self sendJump];
                }
            }
            break;
        case kButtonTypeRunning:
            //[_firstPlayer jump];
            if (_hud.isRunning) {
                NSLog(@"RUN");
            } else {
                NSLog(@"WALK");
            }
            break;
        case kButtonTypeRestar:
            [self restart];
            break;
        case kButtonTypeSelectedLevel:
            [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[WorldLayer scene] withColor:ccBLACK]];
            break;
        case kButtonTypeDrawing:
            //[_firstPlayer jump];
            if (_hud.isDrawing) {
                _drawing.active = true;
                NSLog(@"MODE DRAWING ACTIVE");
            } else {
                _drawing.active = false;
                NSLog(@"MODE DRAWING DESACTIVE");
            }
            break;
        default:
            break;
    }
    
}

#pragma mark GCHelperDelegate
- (void)inviteReceived {
    NSLog(@"inviteReceived");
    //    [self restartTapped:nil];
}

- (void)matchStarted {
    NSLog(@"Match started");
    gameState = kGameStateActive;
}

- (void)matchEnded {
    NSLog(@"Match ended");
    
    [[GCHelper sharedInstance].match disconnect];
    [GCHelper sharedInstance].match = nil;
    
    //
    // finished the level
    //
}

- (void)match:(GKMatch *)match didReceiveData:(NSData *)data fromPlayer:(NSString *)playerID {
    //NSLog(@"Match");

    Message *message = (Message *) [data bytes];
    
    if (message->messageType == kMessageTypeGameBegin) {
        
//        [self setGameState:kGameStateActive];
//        [self setupStringsWithOtherPlayerId:playerID];
        
    } else if (message->messageType == kMessageTypeMove) {
        
        //CCLOG(@"Received kMessageTypeMove");
        
        MessageMove * message = (MessageMove *) [data bytes];
        
        if (_isFirstplayer == NO) {
            [_firstPlayer walkWithDirection:message->direction];
        } else {
            [_secondPlayer walkWithDirection:message->direction];
        }
    } else if (message->messageType == kMessageTypeScore) {
        
        if (_isFirstplayer == NO) {
        
            MessageScore * message = (MessageScore *) [data bytes];

            _score += message->score;
            _scoreMax += message->maxScore;
            
            [_hud updateScore:_score];
        }
        
    } else if (message->messageType == kMessageTypeRun) {
        
        //CCLOG(@"Received kMessageTypeRun");
        
        MessageRun * message = (MessageRun *) [data bytes];
        
        if (_isFirstplayer == NO) {
            [_firstPlayer runWithDirection:message->direction];
        } else {
            [_secondPlayer runWithDirection:message->direction];
        }
        
    } else if (message->messageType == kMessageTypePlayerPosition) {
        
        //CCLOG(@"Received kMessageTypePlayerPosition");
        
        MessagePlayerPosition * message = (MessagePlayerPosition *) [data bytes];
        
        if (_isFirstplayer == NO) {
            [_firstPlayer idle];
            [_firstPlayer getBody]->SetTransform(message->position, message->angle);
            
        } else {
            [_secondPlayer idle];
            [_secondPlayer getBody]->SetTransform(message->position, message->angle);
        }
        
    } else if (message->messageType == kMessageTypeJump) {
        
        if (_isFirstplayer == NO) {
            [_firstPlayer jump];
        } else {
            [_secondPlayer jump];
        }
        
    } else if (message->messageType == kMessageTypeSelectedElement) {
        
        CCLOG(@"Received kMessageTypeSelectedElement");
        
        if (_isFirstplayer == YES) {
            
            MessageSelectedElement * message = (MessageSelectedElement *) [data bytes];
            
            Element *node;
            CCARRAY_FOREACH(_elements, node) {
                b2Vec2 pos = [node getBody]->GetPosition();
                
                if(node.hasColor == NO && node.selected == NO && pos.x == message->position.x && pos.y == message->position.y)
                {
                    //NSLog(@"TOUCH");
                    node.selected = YES;
                    [_musicScore addElement:node];
                }
            }
            
            Enemy *nod;
            CCARRAY_FOREACH(_enemies, nod) {
                b2Vec2 pos = [nod getBody]->GetPosition();
                
                if(nod.isHold == YES && nod.selected == NO && pos.x == message->position.x && pos.y == message->position.y)
                {
                    //NSLog(@"TOUCH");
                    nod.selected = YES;
                    [_musicScore addElement:nod];
                }
            }
            
        }
        
    } else if (message->messageType == kMessageTypeStartMusicScore) {
        
        //CCLOG(@"Received kMessageTypeStartMusicScore");
        //
        // HERO RECEIVED
        //
        if (_isFirstplayer == YES) {
            [_musicScore start:YES andIndexSong:-1];
            //
            // SEND TO HELPER THE SONG CORRECT
            //
            [self sendStartMusicScore:_musicScore.indexSong];
        } else {
            MessageStartMusicScore * message = (MessageStartMusicScore *) [data bytes];
            [_musicScore start:NO andIndexSong:message->index];
        }
        
    } else if (message->messageType == kMessageTypeWhyKeyPlayed) {
        
        //CCLOG(@"Received kMessageTypeWhyKeyPlayed");
        //
        // HELPER RECEIVED
        //

        MessageWhyKeyPlayed * message = (MessageWhyKeyPlayed *) [data bytes];

        NSString * name = [_hud.keyboard getNameById:message->key];

        //NSLog(@"note: %@",name);

        [_musicScore keyTouch:name];
        
    } else if (message->messageType == kMessageTypeDrawing) {
        
        //CCLOG(@"Received kMessageTypeDrawing");
        
        //
        // HERO RECEIVED
        //
        if (_isFirstplayer == YES) {
            MessageDrawing * message = (MessageDrawing *) [data bytes];
            
            //NSLog(@"command: %i",message->command);
            
            //NSLog(@"command: %f %f",message->x1, message->y1);
            
            if (message->command == 1) {
                [_drawing definePreviousLocation:message->first];
            } else if (message->command == 2) {
                [_drawing paintTexture:message->first andEnd:message->second ];
            } else if (message->command == 3) {
                [_drawing createdShapeTemp:message->first];
            } else if (message->command == 4) {
                [_drawing createdShape];
            }
        }
        
    } else if (message->messageType == kMessageTypeGameOver) {
        
//        MessageGameOver * messageGameOver = (MessageGameOver *) [data bytes];
//        CCLOG(@"Received game over with player 1 won: %d", messageGameOver->player1Won);
//        
//        if (messageGameOver->player1Won) {
//            [self endScene:kEndReasonLose];
//        } else {
//            [self endScene:kEndReasonWin];
//        }
        
    }
}
@end
