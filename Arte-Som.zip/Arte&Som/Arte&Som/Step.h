//
//  MyCocos2DClass.h
//  Spacedisc
//
//  Created by iMac on 24/06/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Step : NSObject <NSCoding>
{
//    int points;
//    int star;
//    bool open;
}

@property int points, star;
@property bool open;
 
@end
