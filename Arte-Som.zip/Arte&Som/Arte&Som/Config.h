//
//  Config.h
//  Plataforma
//
//  Created by Farlei Heinen on 27/03/12.
//  Copyright (c) 2012 Unisinos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Step.h"

@interface Config : NSObject <NSCoding>
{
    NSArray * steps;
}

@property(nonatomic, retain) NSArray * steps;
@property BOOL isMultiplayer;
@property BOOL isFirstplayer;
@property int levelActual;

-(void)reset;

@end