//
//  Config.h
//  Plataforma
//
//  Created by Farlei Heinen on 27/03/12.
//  Copyright (c) 2012 Unisinos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Config : NSObject <NSCoding>
{
    //NSArray * steps;
}

@property(nonatomic, retain) NSArray * steps;
@property BOOL inviteFriend;
@property int levelActual;


@end