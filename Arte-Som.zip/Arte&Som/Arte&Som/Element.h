//
//  Element.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ActionSprite.h"

@interface Element : ActionSprite {
    CCSprite * image_gray;
    CCSprite * image_color;
    CCSprite * image_brush;
}

@property BOOL hasColor;
@property BOOL isPaint;
@property BOOL selected;

@end
