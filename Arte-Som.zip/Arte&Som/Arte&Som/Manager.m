//
//  Singleton.m
//  
//
//  Created by Farlei Jose Heinen on 18/04/10.
//  Copyright 2010 Ficta. All rights reserved.
//

#import "Manager.h"

static Manager *sharedInstance = nil;

@implementation Manager

@synthesize conf;

- (NSString*) configFile
{
    NSArray* docDirs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* docDir = [docDirs objectAtIndex:0];
    NSString* path = [docDir stringByAppendingPathComponent:@"game.config"];
    return path;
}

- (void) salvar
{    
    [NSKeyedArchiver archiveRootObject:conf toFile:[self configFile]];
}

- (void) carregar
{
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:[self configFile]];
    
    if(fileExists)
        self.conf = [NSKeyedUnarchiver unarchiveObjectWithFile:[self configFile]];
    else
        conf = [[Config alloc] init];
}

+ (Manager*)sharedInstance
{
    @synchronized(self)
    {
        if (sharedInstance == nil)
			sharedInstance = [[Manager alloc] init];
    }
    return sharedInstance;
}

- (id) init
{
    self = [super init];
    if(self)
    {
        [self carregar];
    }
    return self;
}

- (id)retain 
{
    return self;
}

- (unsigned)retainCount {
    return UINT_MAX;  // indica que o objeto não pode ser desalocado
}

- (id)autorelease {
    return self;
}

@end