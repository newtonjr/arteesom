//
//  Config.m
//  Plataforma
//
//  Created by Farlei Heinen on 27/03/12.
//  Copyright (c) 2012 Unisinos. All rights reserved.
//
#import "Config.h"

@implementation Config

@synthesize steps;

- (Config*) init
{
    self = [super init];
    if(self)
    {
        _isMultiplayer = NO;
        _isFirstplayer = YES;
        
        [self reset];
    }
    return self;
}

-(void)reset{
    
    Step * step1 = [Step new];
    Step * step2 = [Step new];
    Step * step3 = [Step new];
    Step * step4 = [Step new];
    Step * step5 = [Step new];
    Step * step6 = [Step new];
    Step * step7 = [Step new];
    Step * step8 = [Step new];
    Step * step9 = [Step new];
    Step * step10 = [Step new];
    Step * step11 = [Step new];
    Step * step12 = [Step new];
    Step * step13 = [Step new];
    Step * step14 = [Step new];
    Step * step15 = [Step new];
    Step * step16 = [Step new];
    Step * step17 = [Step new];
    
    self.steps = [NSArray arrayWithObjects:step1, step2, step3, step4, step5, step6, step7, step8, step9, step10, step11, step12, step13, step14, step15, step16, step17, nil];
}


- (Config*) initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        _isMultiplayer = [aDecoder decodeBoolForKey:@"isMultiplayer"];
        _isFirstplayer = [aDecoder decodeBoolForKey:@"isFirstplayer"];
        self.steps = [aDecoder decodeObjectForKey:@"STEPS"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeBool:_isMultiplayer forKey:@"isMultiplayer"];
    [aCoder encodeBool:_isFirstplayer forKey:@"isFirstplayer"];
    [aCoder encodeObject:steps forKey:@"STEPS"];
    //NSLog(@"GRAVAR");
}

@end