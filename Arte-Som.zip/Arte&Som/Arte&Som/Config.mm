//
//  Config.m
//  Plataforma
//
//  Created by Farlei Heinen on 27/03/12.
//  Copyright (c) 2012 Unisinos. All rights reserved.
//
#import "Config.h"

@implementation Config

@synthesize steps;

- (Config*) init
{
    self = [super init];
    if(self)
    {
    }
    return self;
}


- (Config*) initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        //self.steps = [aDecoder decodeObjectForKey:@"STEPS"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *)aCoder
{
    //[aCoder encodeObject:steps forKey:@"STEPS"];
}

@end