//
//  ActionPlayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "ActionPlayer.h"

@implementation ActionPlayer

@synthesize impulseFactor, maxJump;

-(void)drawing {
    if (actionState == kActionStateIdle) {
        [self stopAllActions];
        [self runAction:_drawAction];
        actionState = kActionStateDraw;
    }
}

-(void)playing {
    if (actionState == kActionStateIdle) {
        [self stopAllActions];
        [self runAction:_playAction];
        actionState = kActionStatePlay;
    }
}

-(void)idle {
    if (!isJump) {
        [super idle];
    }
}

-(void)walkWithDirection:(CGPoint)direction {
    if (!isJump) {
        //NSLog(@"walkWithDirection");
        [super walkWithDirection:direction];
    }
}

-(void)jump {
    if (actionState == kActionStateIdle || actionState == kActionStateWalk || actionState == kActionStateRun) {
        [self stopAllActions];
        //[self runAction:_jumpAction];
        actionState = kActionStateJump;

        b2Vec2 force;
        force.x = 0;
        force.y = maxJump * impulseFactor * body_->GetMass();
        
        //NSLog(@"jump");
        
        body_->ApplyLinearImpulse(force, body_->GetWorldCenter());
        
        isJump = true;
        
    }
    
}

-(void)update:(ccTime)dt {
    if (actionState == kActionStateJump) {
        
        // get the current velocity
        b2Vec2 velocity = body_->GetLinearVelocity();
        float vY = velocity.y;
        
        if (vY <= 0) {
//            isJump = false;
//            [self idle];
            
            for (b2ContactEdge* bc = body_->GetContactList(); bc; bc = bc->next)
            {
                b2Contact *contact = bc->contact;
                if (contact->IsTouching())
                {
                    //NSLog(@"touch");
                    FixtureData *a = (FixtureData*)contact->GetFixtureA()->GetUserData();
                    FixtureData *b = (FixtureData*)contact->GetFixtureB()->GetUserData();
                    
//                    NSLog(@"%i",a.tag);
//                    
//                    NSLog(@"%i",b.tag);
                    
                    if (a != nil && b != nil && (b.tag == kFixtureIdentifyGroung || a.tag == kFixtureIdentifyGroung)) {
                        bool isTouchHead = false;
                        b2Vec2 ap = a.body->GetPosition();
                        b2Vec2 bp = b.body->GetPosition();
                        
                        //
                        // check if is not touching to head
                        //
                        if (a.tag == kFixtureIdentifyGroung) {
                            if (ap.y > bp.y) {
                                isTouchHead = true;
                            }
                        } else if (b.tag == kFixtureIdentifyGroung) {
                            if (ap.y < bp.y) {
                                isTouchHead = true;
                            }
                        }
                        if (!isTouchHead) {
                            isJump = false;
                            [self idle];
                        }
                    }
                }
            }
        }
    }
}

-(void)runWithDirection:(CGPoint)direction {
    if (!isJump && (actionState == kActionStateIdle || actionState == kActionStateWalk)) {
        [self stopAllActions];
        //[self runAction:_runAction];
        actionState = kActionStateRun;
    }
    if (actionState == kActionStateRun) {
        
        // get the current velocity
        b2Vec2 velocity = body_->GetLinearVelocity();
        float vX = velocity.x;
        
        // clamp velocity
        const float maxVelocity = 8.0;
        float v = velocity.Length();
        if(v > maxVelocity)
        {
            body_->SetLinearVelocity(maxVelocity/v*velocity);
        }
        
        bool isLeft = (direction.x < 0);
        
        if((isLeft && (vX > -_runMaxSpeed)) || ((!isLeft && (vX < _runMaxSpeed)))) {
            
            b2Vec2 force;
            force.x = _runSpeed * direction.x;
            force.y = 0;
            
            //NSLog(@"runWithDirection: %f %f", force.x, force.y);
            
            body_->ApplyLinearImpulse(force, body_->GetWorldCenter());
        }
    }
}

@end
