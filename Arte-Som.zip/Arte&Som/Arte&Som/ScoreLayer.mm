//
//  ScoreLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "Manager.h"

#import "ScoreLayer.h"
#import "WorldLayer.h"
#import "LevelLayer.h"
#import "StoryLayer.h"

@implementation ScoreLayer

+(CCScene *) scene:(int)score andMax:(int)maxScore
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	ScoreLayer *layer = [ScoreLayer node];
    
    layer.score = score;
    layer.maxScore = maxScore;
    
    [layer createMenu];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super initWithColor:ccc4(255,255,255,255)])) {
		
		// enable events
		self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
        
		CCSprite *background;
        
        background = [CCSprite spriteWithFile:@"tl-score.jpg"];

        background.position = ccp(SCREEN.width/2, SCREEN.height/2);
        
        // add the label as a child to this Layer
        [self addChild: background];

		
	}
	return self;
}

-(void) createMenu
{
    CCLabelTTF *label = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%i",_score] fontName:@"Marker Felt" fontSize:92];
    [self addChild:label z:0];
    [label setColor:ccc3(0,0,0)];
    label.position = ccp(230, 450);
    
    float perc = _score * 100 / _maxScore;
    int stars = 0;
    
    if (perc > 90) {
        stars = 3;
    } else if (perc > 70) {
        stars = 2;
    } else if (perc > 50) {
        stars = 1;
    }
    
    for (int i = 0; i < 3; i++) {
        CCSprite* star;
        if(i < stars){
            star = [CCSprite spriteWithFile:@"icon-star-big-on.png"];
        }else{
            star = [CCSprite spriteWithFile:@"icon-star-big-off.png"];
        }
        switch (i) {
            case 0:
                star.position = ccp(0,-120);
                break;
            case 1:
                star.position = ccp(130,-120);
                break;
            case 2:
                star.position = ccp(260,-120);
                break;
        }
        [label addChild:star z:1];
    }
    
    int level = [Manager sharedInstance].conf.levelActual;
    NSArray * steps = [Manager sharedInstance].conf.steps;
    Step * step = [steps objectAtIndex:level-1];
    
    if (step.star <= stars && step.points < _score) {
        //atualiza
        step.star = stars;
        step.points = _score;
    }
    
    CCMenuItemImage *itemWorld = [CCMenuItemImage itemWithNormalImage:@"btn-back-player-off.jpg" selectedImage:@"btn-back-player-on.jpg" block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[WorldLayer scene] withColor:ccWHITE]];
    }];
    
    CCMenuItemImage *itemLevel = [CCMenuItemImage itemWithNormalImage:@"btn-replay-off.png" selectedImage:@"btn-replay-on.png" block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[LevelLayer scene] withColor:ccWHITE]];
    }];
    
    CCMenuItemImage *itemNext = [CCMenuItemImage itemWithNormalImage:@"btn-next-off.png" selectedImage:@"btn-next-on.png" block:^(id sender) {
        //
        Step * step = [steps objectAtIndex:level];
        [step setOpen:true];
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[WorldLayer scene] withColor:ccWHITE]];
    }];
    
    if (stars == 0 || level == 17) {
        itemNext.visible = false;
    }
    
    CCMenu *menu = [CCMenu menuWithItems:itemWorld, itemLevel, itemNext, nil];
    
    [menu alignItemsHorizontally];
    
    [menu setPosition:ccp(570, 140)];
    
    [self addChild: menu];
}

@end
