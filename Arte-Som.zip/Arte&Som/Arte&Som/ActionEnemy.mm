//
//  ActionEnemy.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "ActionEnemy.h"

@implementation ActionEnemy

-(void)attack {
    if (actionState == kActionStateIdle || actionState == kActionStateAttack || actionState == kActionStateWalk) {
        [self stopAllActions];
        [self runAction:_attackAction];
        actionState = kActionStateAttack;
    }
}

@end
