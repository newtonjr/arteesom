//
//  ActionEnemy.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "ActionEnemy.h"

@implementation ActionEnemy

-(void)startStateMachine {
    stateCount = 0;
    flyPoint = CGPointZero;
    isFlyLeft = random_range(0, 200) > 100 ? YES : NO;
    isFlyHigh = random_range(0, 200) > 100 ? YES : NO;
    
    actionState = kActionStateFly;
    
    body_->SetGravityScale(0);
    
    [self schedule:@selector(stateMachine:) interval:1.0];
    [self scheduleUpdate];
}

-(void)idle {
    if (actionState != kActionStateIdle || actionState == kActionStateFly || actionState == kActionStateAttack) {
        //NSLog(@"idle");
        
        [self stopAllActions];
        //[self runAction:_idleAction];
        actionState = kActionStateIdle;
    }
    if (actionState == kActionStateIdle) {
        //
        // realiza o impulso
        //
        b2Vec2 velocity = body_->GetLinearVelocity();
        
        // clamp velocity
        const float maxVelocity = 0;
        float v = velocity.Length();
        if(v > maxVelocity)
        {
            body_->SetLinearVelocity(maxVelocity/v*velocity);
        }
        
        b2Vec2 force;
        force.x = 0;
        force.y = 0;
        
        body_->ApplyLinearImpulse(force, body_->GetWorldCenter());
    }
}

-(void)absorb {
    if (actionState == kActionStateIdle || actionState == kActionStateAttack) {
        [self stopAllActions];
        //[self runAction:_attackAction];
        stateCount = 2;
        actionState = kActionStateAbsorb;
    }
    if (actionState == kActionStateAbsorb) {
        [self moveToPlayer];
    }
}

-(void)paintElement:(float)perc {
    //hasColor = YES;
    actionState = kActionStateKnockedOut;
}

-(void)absorbPlayer {
    [label setString:[NSString stringWithFormat:@"%i",(int)self.damage]];
    
    if (identifyAttack == kFixtureIdentifyFirstPlayer) {
        [_firstPlayer hurtWithDamage:self.damage];
    } else if (identifyAttack == kFixtureIdentifySecondPlayer) {
        [_secondPlayer hurtWithDamage:self.damage];
    }
    
    label.position = ccp(frandom_range(0, self.size.width),frandom_range(0, self.size.height));
    
    id action1 = [CCFadeIn actionWithDuration:0.25];
    id action2 = [CCDelayTime actionWithDuration:0.5];
    id action3 = [CCFadeOut actionWithDuration:0.25];
    
    [label runAction:[CCSequence actions:action1,action2,action3,nil]];
}

-(void)attack {
    if (actionState == kActionStateIdle || actionState == kActionStateFly || actionState == kActionStateAbsorb) {
        [self stopAllActions];
        //[self runAction:_attackAction];
        actionState = kActionStateAttack;
    }
    if (actionState == kActionStateAttack) {
        [self moveToPlayer];
    }
}

-(void)moveToPlayer {
    //
    // determinar a direção
    //
    _direction = CGPointMake(pointAttack.x - body_->GetPosition().x, pointAttack.y - body_->GetPosition().y);
    
    
    //
    // realiza o impulso
    //
    b2Vec2 velocity = body_->GetLinearVelocity();
    float vX = velocity.x;
    
    // clamp velocity
    const float maxVelocity = _flyMaxSpeed;
    float v = velocity.Length();
    if(v > maxVelocity)
    {
        body_->SetLinearVelocity(maxVelocity/v*velocity);
    }
    
    bool isLeft = (_direction.x < 0);
    
    //NSLog(@"_direction: %f %f and vX: %f", _direction.x, _direction.y, vX);
    
    if((isLeft && (vX > -_flyMaxSpeed*2)) || ((!isLeft && (vX < _flyMaxSpeed*2)))) {
        
        b2Vec2 force;
        force.x = _flySpeed * _direction.x;
        force.y = _flySpeed * _direction.y;
        
        //NSLog(@"flyDirection: %f %f", force.x, force.y);
        
        body_->ApplyLinearImpulse(force, body_->GetWorldCenter());
    }
}

-(void)defineFly{
    if (flyPoint.x >= 3) {
        isFlyLeft = YES;
    } else if (flyPoint.x <= -3) {
        isFlyLeft = NO;
    }
    if (isFlyLeft == YES) {
        --flyPoint.x;
        _direction.x = -1;
    } else {
        ++flyPoint.x;
        _direction.x = 1;
    }
    
    if (flyPoint.y >= 2) {
        isFlyHigh = YES;
        _direction.y = 1;
    } else if (flyPoint.y <= -2) {
        isFlyHigh = NO;
        _direction.y = -1;
    }
    if (isFlyHigh == YES) {
        --flyPoint.y;
    } else {
        ++flyPoint.y;
    }
    
    //NSLog(@"defineFly: %f %f", flyPoint.x, flyPoint.y);
}

-(void)fly {
    if (actionState == kActionStateIdle || actionState == kActionStateFly || actionState == kActionStateWalk) {
        [self stopAllActions];
        //[self runAction:_attackAction];
        actionState = kActionStateFly;
        //NSLog(@"enter fly");
    }
    if (actionState == kActionStateFly) {
        // NSLog(@"fly");
        
        // get the current velocity
        b2Vec2 velocity = body_->GetLinearVelocity();
        float vX = velocity.x;
        
        // clamp velocity
        const float maxVelocity = _flyMaxSpeed;
        float v = velocity.Length();
        if(v > maxVelocity)
        {
            body_->SetLinearVelocity(maxVelocity/v*velocity);
        }
        
        bool isLeft = (_direction.x < 0);
        
        //NSLog(@"_direction: %f %f and vX: %f", _direction.x, _direction.y, vX);
        
        if((isLeft && (vX > -_flyMaxSpeed)) || ((!isLeft && (vX < _flyMaxSpeed)))) {
            
            b2Vec2 force;
            force.x = _flySpeed * _direction.x;
            force.y = _flySpeed * _direction.y;
            
            //NSLog(@"flyDirection: %f %f", force.x, force.y);
            
            body_->ApplyLinearImpulse(force, body_->GetWorldCenter());
        }
    }
}

-(void)update:(ccTime)dt{
    _isHold = NO;
    for (b2ContactEdge* bc = body_->GetContactList(); bc; bc = bc->next)
    {
        BOOL attack = YES;
        b2Contact *contact = bc->contact;
        if (contact->IsTouching())
        {
            FixtureData *a = (FixtureData*)contact->GetFixtureA()->GetUserData();
            FixtureData *b = (FixtureData*)contact->GetFixtureB()->GetUserData();
            
            if (a != nil && b != nil && ((b.tag == kFixtureIdentifyFirstPlayer || a.tag == kFixtureIdentifyFirstPlayer) || (b.tag == kFixtureIdentifySecondPlayer || a.tag == kFixtureIdentifySecondPlayer)) && (b.tag == kFixtureIdentifyEnemy || a.tag == kFixtureIdentifyEnemy)) {
                
                b2Vec2 posicaoPlayer;
                if (a.tag != kFixtureIdentifyEnemy) {
                    identifyAttack = a.tag;
                    posicaoPlayer = contact->GetFixtureA()->GetBody()->GetPosition();
                    
                    if (!contact->GetFixtureB()->IsSensor()) {
                        attack = NO;
                    }
                    
                } else {
                    identifyAttack = b.tag;
                    posicaoPlayer = contact->GetFixtureB()->GetBody()->GetPosition();
                    
                    if (!contact->GetFixtureA()->IsSensor()) {
                        attack = NO;
                    }
                }
                
                pointAttack = CGPointMake(posicaoPlayer.x, posicaoPlayer.y);
                
                if (attack == YES) {
                    [self attack];
                } else {
                    [self absorb];
                }
                break;
                
            } else if (a != nil && b != nil && ((b.tag == kFixtureIdentifyEnemy || a.tag == kFixtureIdentifyLineDrawing) || (b.tag == kFixtureIdentifyLineDrawing || a.tag == kFixtureIdentifyEnemy))){
                _isHold = YES;
            }
        }
    }
}

-(void)stateMachine:(ccTime)dt {
    switch (actionState) {
        case kActionStateAttack:
            //NSLog(@"kActionStateAttack");
            [self attack];
            break;
        case kActionStateAbsorb:
            //NSLog(@"kActionStateAbsorb");
            [self absorb];
            ++stateCount;
            if (stateCount >= 2) {
                stateCount = 0;
                [self absorbPlayer];
            }
            break;
        case kActionStateFly:
            //NSLog(@"kActionStateFly");
            [self defineFly];
            [self fly];
            ++stateCount;
            if (stateCount >= 10) {
                stateCount = 0;
                [self idle];
            }
            break;
        case kActionStateKnockedOut:
            //[self setVisible:NO];
            [self setOpacity:30];
            break;
        case kActionStateIdle:
        default:
            //NSLog(@"kActionStateIdle");
            [self idle];
            ++stateCount;
            if (stateCount >= 4) {
                stateCount = 0;
                [self fly];
            }
            break;
    }
}

@end
