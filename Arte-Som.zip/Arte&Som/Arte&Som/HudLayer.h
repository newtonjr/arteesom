//
//  HudLayer.h
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

#import "SimpleDPad.h"
#import "KeyboardLayer.h"

@class HudLayer;

@protocol HudLayerDelegate <NSObject>

-(void)HudLayer:(HudLayer *)HudLayer pressedButton:(ButtonType)type;

@end

@interface HudLayer : CCLayer {
    bool isRunning;
    bool isDrawing;
    
    CCMenuItem * drawButtonItem;
}

@property(nonatomic,retain)id <HudLayerDelegate> delegate;

@property(nonatomic,retain)SimpleDPad *dPad;
@property(nonatomic,retain)CCMenuItem *drawButtonItem;
@property bool isRunning;
@property bool isDrawing;


@property(nonatomic,retain)KeyboardLayer *keyboard;

@end
