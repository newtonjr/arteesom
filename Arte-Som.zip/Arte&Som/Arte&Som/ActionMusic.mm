//
//  ActionMusic.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 12/2/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "ActionMusic.h"


@implementation ActionMusic

@synthesize hasColor, isPaint, selected;

-(void)paintElement:(float)perc {
    
}

@end