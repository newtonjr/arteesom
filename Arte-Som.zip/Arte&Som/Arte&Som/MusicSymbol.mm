//
//  MusicSymbol.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/30/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "MusicSymbol.h"


@implementation MusicSymbol

@synthesize name;

-(id)init {
	if( (self=[super init])) {
        //
        _running = NO;
        _played = NO;
        _finished = NO;
        
        smoke = [CCParticleSystemQuad particleWithFile:@"smoke.plist"];
        smoke.blendFunc = (ccBlendFunc) { GL_ONE, GL_ONE_MINUS_SRC_ALPHA };
    }
    return self;
}

-(void)setup:(NSString *) note andTime:(float) time andType:(int) type {
    name = [[NSString alloc] initWithString:note];
    _time = time;
    
    //NSLog(@"%@",name);
    
    switch (type) {
        case 8:
            _lowValue = 60;
            _highValue = 100;
            draw = [CCSprite spriteWithFile:@"musical_symbol_8.png"];
            break;
        case 4:
            _lowValue = 45;
            _highValue = 80;
            draw = [CCSprite spriteWithFile:@"musical_symbol_4.png"];
            break;
        case 2:
            _lowValue = 25;
            _highValue = 50;
            draw = [CCSprite spriteWithFile:@"musical_symbol_2.png"];
            break;
        case 1:
        default:
            _lowValue = 5;
            _highValue = 20;
            draw = [CCSprite spriteWithFile:@"musical_symbol_1.png"];
            break;
    }
    
    draw.opacity = 0;
    
    [self addChild:draw];
}

-(void)run {
    
    _running = YES;
    
    //NSLog(@"%@",name);
    
    float duration = (MUSIC_VALUE_TIME * 2);
    
    id _moveAction = [CCMoveTo actionWithDuration:duration position:ccp(self.position.x, self.position.y + 200)];
    
    [self runAction:_moveAction];
    
    id action1 = [CCFadeIn actionWithDuration:0.25];
    id action2 = [CCDelayTime actionWithDuration:duration-0.5];
    id action3 = [CCFadeOut actionWithDuration:0.25];
    id action4 = [CCCallFunc actionWithTarget:self selector:@selector(finish)];
    
    //[draw runAction:action3];
    
    [draw runAction:[CCSequence actions:action1,action2,action3,action4,nil]];
    
    //smoke.blendAdditive = NO;
    
    if ([name compare:@"4C"] == NSOrderedSame) {
        // violeta rgb(111,36,163)
        smoke.startColor = ccc4FFromccc3B(ccc3(111,36,163));
        
    } else if ([name compare:@"4Cs"] == NSOrderedSame) {
        //sutenido... azul escuro rgb(20,30,144)
        smoke.startColor = ccc4FFromccc3B(ccc3(20,30,144));
        
    } else if ([name compare:@"4D"] == NSOrderedSame) {
        //azul rgb(0,0,255)
        smoke.startColor = ccc4FFromccc3B(ccc3(0,0,255));
        
    } else if ([name compare:@"4Ds"] == NSOrderedSame) {
        //sutenido... azul claro rgb(0,127,255)
        smoke.startColor = ccc4FFromccc3B(ccc3(0,127,255));
        
    } else if ([name compare:@"4E"] == NSOrderedSame) {
        //verde rgb(75,129,25)
        smoke.startColor = ccc4FFromccc3B(ccc3(75,129,25));
        
    } else if ([name compare:@"4F"] == NSOrderedSame) {
        //verde claro rgb(168,199,0)
        smoke.startColor = ccc4FFromccc3B(ccc3(168,199,0));
        
    } else if ([name compare:@"4Fs"] == NSOrderedSame) {
        //sutenido... verde limao rgb(0,255,0)
        smoke.startColor = ccc4FFromccc3B(ccc3(0,255,0));
        
    } else if ([name compare:@"4G"] == NSOrderedSame) {
        // amarelo rgb(255,255,0)
        smoke.startColor = ccc4FFromccc3B(ccc3(255,255,0));
        
    } else if ([name compare:@"4Gs"] == NSOrderedSame) {
        //sutenido... laranja rgb(255,127,0)
        smoke.startColor = ccc4FFromccc3B(ccc3(255,127,0));
        
    } else if ([name compare:@"5A"] == NSOrderedSame) {
        //laranja/marrom rgb(162,73,0)
        smoke.startColor = ccc4FFromccc3B(ccc3(162,73,0));
        
    } else if ([name compare:@"5As"] == NSOrderedSame) {
        //sutenido.. rosa rgb(208,56,152)
        smoke.startColor = ccc4FFromccc3B(ccc3(208,56,152));
        
    } else if ([name compare:@"5B"] == NSOrderedSame) {
        //vermelho rgb(255,0,0)
        smoke.startColor = ccc4FFromccc3B(ccc3(255,0,0));
    }
    
    smoke.position = ccp(10.0,24.0);
    smoke.duration = duration;
    smoke.autoRemoveOnFinish = YES;
    [draw addChild:smoke z:-1];
}

-(void)finish {
    _finished = YES;
    
    [smoke stopSystem];
    
    [self stopAllActions];
    [draw stopAllActions];
    
    id action2 = [CCFadeOut actionWithDuration:0.25];
    [draw runAction:action2];
}

@end
