//
//  SecondPlayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#import "ActionPlayer.h"

@interface SecondPlayer : ActionPlayer {
    
}

@end
