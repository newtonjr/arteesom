//
//  StoryLayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface StoryLayer : CCLayer {
    CGFloat time;
}

// returns a CCScene that contains the StoryLayer as the only child
+(CCScene *) scene;

@property CGFloat time;

@end
