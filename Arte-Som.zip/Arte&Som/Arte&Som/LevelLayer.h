//
//  LevelLayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <GameKit/GameKit.h>

#import "AppDelegate.h"
#import "GCHelper.h"

// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"
#import "Box2D.h"
#import "GLES-Render.h"

#import "HudLayer.h"
#import "DrawingLayer.h"

#import "FirstPlayer.h"
#import "SecondPlayer.h"
#import "Element.h"
#import "Enemy.h"

#import "MusicScore.h"

#import "GerenciadorContatos.h"

typedef enum {
    kMessageTypeRandomNumber = 0,
    kMessageTypeGameBegin,
    kMessageTypeMove,
    kMessageTypeRun,
    kMessageTypeJump,
    kMessageTypeScore,
    kMessageTypeSelectedElement,
    kMessageTypeDrawing,
    kMessageTypePlayerPosition,
    kMessageTypeEnemyDirection,
    kMessageTypeStartMusicScore,
    kMessageTypeWhyKeyPlayed,
    kMessageTypeGameOver
} MessageType;

typedef struct {
    MessageType messageType;
} Message;

typedef struct {
    Message message;
    uint32_t randomNumber;
} MessageRandomNumber;

typedef struct {
    Message message;
} MessageGameBegin;

typedef struct {
    Message message;
    CGPoint direction;
} MessageMove;

typedef struct {
    Message message;
    CGPoint direction;
} MessageRun;

typedef struct {
    Message message;
    b2Vec2 position;
    float32 angle;
} MessagePlayerPosition;

typedef struct {
    Message message;
    CGPoint direction;
    int index;
} MessageEnemyDirection;

typedef struct {
    Message message;
} MessageJump;

typedef struct {
    Message message;
    int index;
} MessageStartMusicScore;

typedef struct {
    Message message;
    CGPoint position;
} MessageSelectedElement;

typedef struct {
    Message message;
    int command;
    CGPoint first;
    CGPoint second;
} MessageDrawing;

typedef struct {
    Message message;
    int key;
} MessageWhyKeyPlayed;

typedef struct {
    Message message;
    int score;
    int maxScore;
} MessageScore;

typedef struct {
    Message message;
    BOOL player1Won;
} MessageGameOver;

typedef enum {
    kEndReasonWin,
    kEndReasonLose,
    kEndReasonDisconnect
} EndReason;

typedef enum {
    kGameStateWaitingForMatch = 0,
    kGameStateWaitingForRandomNumber,
    kGameStateWaitingForStart,
    kGameStateActive,
    kGameStateDone
} GameState;

@interface LevelLayer : CCLayerColor<SimpleDPadDelegate, HudLayerDelegate, KeyboardLayerDelegate, GCHelperDelegate, DrawingLayerDelegate> {
    //
    // strong ref
    //
	b2World * world;
	GLESDebugDraw * m_debugDraw;
    GerenciadorContatos * gerContact;
    
    //
    // weak ref
    //
    CCTMXTiledMap * _tileMap;
    //CCTexture2D * _spriteTexture;
    
    //
    // general
    //
    int _level;
    BOOL _isMultiplayer;
    BOOL _isFirstplayer;
    BOOL _schedulerRestart;
    int _score;
    int _scoreMax;
    
    //
    // hero
    //
    FirstPlayer * _firstPlayer;
    SecondPlayer * _secondPlayer;
    ActionSprite * saida;
    
    //
    // AI
    //
    
    //
    // multiplayer
    //
    uint32_t ourRandom;
    BOOL receivedRandom;
    NSString *otherPlayerID;
    GameState gameState;
}
@property(nonatomic,retain)MusicScore *musicScore;
@property(nonatomic,retain)DrawingLayer *drawing;
@property(nonatomic,retain)HudLayer *hud;
@property(nonatomic,strong)CCArray * elements;
@property(nonatomic,strong)CCArray * enemies;

// returns a CCScene that contains the LevelLayer as the only child
+(CCScene *) scene;
-(void) initTileMap:(int) level;

@end
