//
//  GerenciadorContatos.m
//  ExemploBox2D
//
//  Created by Farlei Jose Heinen on 02/05/11.
//  Copyright 2011 Ficta. All rights reserved.
//
#import "FixtureData.h"
#import "GerenciadorContatos.h"

GerenciadorContatos::GerenciadorContatos() : Contatos() 
{
}

GerenciadorContatos::~GerenciadorContatos() 
{
}

int GerenciadorContatos::count()
{
    return Contatos.size();
}

contato GerenciadorContatos::popContato()
{
    contato val = Contatos.back();
    Contatos.pop_back();
    return val;
}

void GerenciadorContatos::BeginContact(b2Contact* contact) 
{
    // Obtem o ponto onde ocorreu o contato
    b2WorldManifold worldManifold;
    contact->GetWorldManifold(&worldManifold);
    b2Vec2 pontoContato = worldManifold.points[0];

    // Guarda o contato (somente se for entre estrelas)
    FixtureData *a = (FixtureData*)contact->GetFixtureA()->GetUserData();
    FixtureData *b = (FixtureData*)contact->GetFixtureB()->GetUserData();
    
    //NSLog(@"%i",a.tag);
    //NSLog(@"%i",b.tag);
    
    if (a != nil &&
        b != nil) {
        contato myContact = { contact->GetFixtureA(), contact->GetFixtureB(), pontoContato };
        Contatos.push_back(myContact);
    }

}

void GerenciadorContatos::EndContact(b2Contact* contact) 
{
    contato myContact = { contact->GetFixtureA(), contact->GetFixtureB() };
    std::vector<contato>::iterator pos;
    pos = std::find(Contatos.begin(), Contatos.end(), myContact);
    if (pos != Contatos.end()) {
        Contatos.erase(pos);
    }
}

void GerenciadorContatos::PreSolve(b2Contact* contact, 
                                   const b2Manifold* oldManifold) 
{
    // usado para evitar um contato:
    b2WorldManifold worldManifold;
    contact->GetWorldManifold(&worldManifold);
    
    FixtureData *a = (FixtureData*)contact->GetFixtureA()->GetUserData();
    FixtureData *b = (FixtureData*)contact->GetFixtureB()->GetUserData();
    if (a != nil &&
        b != nil &&
        ((b.tag == kFixtureIdentifyFirstPlayer || a.tag == kFixtureIdentifyFirstPlayer) ||
         (b.tag == kFixtureIdentifySecondPlayer || a.tag == kFixtureIdentifySecondPlayer)) &&
        (b.tag == kFixtureIdentifyEnemy || a.tag == kFixtureIdentifyEnemy)) {
        contact->SetEnabled(false);
    }
    
    if (a != nil &&
        b != nil &&
        ((b.tag == kFixtureIdentifyFirstPlayer || a.tag == kFixtureIdentifyFirstPlayer) ||
         (b.tag == kFixtureIdentifySecondPlayer || a.tag == kFixtureIdentifySecondPlayer)) &&
        (b.tag == kFixtureIdentifyWorld || a.tag == kFixtureIdentifyWorld)) {
        contact->SetEnabled(false);
    }
}

void GerenciadorContatos::PostSolve(b2Contact* contact, 
                                    const b2ContactImpulse* impulse) 
{
    // usado para obter a força do contato
    // float forca = impulse->normalImpulses[0];
}








