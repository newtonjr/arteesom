//
//  MusicSymbol.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/30/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MusicSymbol : CCSprite {
    CCSprite * draw;
    NSString * name;
    CCParticleSystemQuad* smoke;
}

@property int lowValue;
@property int highValue;

@property CGPoint startPoint;
@property float tick;
@property float time;
@property BOOL running;
@property BOOL played;
@property BOOL finished;
@property(nonatomic, strong) NSString * name;

-(void)setup:(NSString *) note andTime:(float) time andType:(int) type;
-(void)run;
-(void)finish;

@end
