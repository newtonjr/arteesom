//
//  ConfigurationLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "SettingsLayer.h"
#import "MenuLayer.h"

@implementation SettingsLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	SettingsLayer *layer = [SettingsLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super init])) {
		
		// enable events
		self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
		CGSize s = [CCDirector sharedDirector].winSize;
		
		// create reset button
		[self createMenu];
		
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Configuração" fontName:@"Marker Felt" fontSize:32];
		[self addChild:label z:0];
		[label setColor:ccc3(0,0,255)];
		label.position = ccp(s.width/2, s.height-50);
	}
	return self;
}

-(void) createMenu
{
	// Default font size will be 22 points.
	[CCMenuItemFont setFontSize:22];
	
	// New game Menu Item using blocks
	CCMenuItem *itemMenu = [CCMenuItemFont itemWithString:@"Voltar" block:^(id sender) {
        //
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[MenuLayer scene] withColor:ccWHITE]];
	}];
	
	CCMenu *menu = [CCMenu menuWithItems:itemMenu, nil];
	
	[menu alignItemsVertically];
	
	CGSize size = [[CCDirector sharedDirector] winSize];
	[menu setPosition:ccp( size.width/2, size.height/2)];
	
	
	[self addChild: menu z:-1];
}

@end
