//
//  ActionEnemy.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#import "ActionMusic.h"
#import "FirstPlayer.h"
#import "SecondPlayer.h"

//@class ActionEnemy;
//
//@protocol ActionEnemyDelegate <NSObject>
//
//-(void)ActionEnemy:(ActionEnemy *)ActionEnemy direction:(CGPoint)direction andIndex:(int)index;
//
//@end

@interface ActionEnemy : ActionMusic {
    CGPoint pointAttack;
    int identifyAttack;
    
    int stateCount;
    CGPoint flyPoint;
    BOOL isFlyLeft;
    BOOL isFlyHigh;
}

//actions
@property(nonatomic,strong)id attackAction;

@property float flySpeed;
@property float flyMaxSpeed;
@property CGPoint direction;
@property BOOL isHold;
@property BOOL isAI;
@property BOOL isMAI;
@property BOOL isChangeDirection;

//action methods
-(void)attack;
-(void)fly;
-(void)startStateMachine;
-(void)startSchedule;

@property(nonatomic,assign)FirstPlayer * firstPlayer;
@property(nonatomic,assign)SecondPlayer * secondPlayer;

@end
