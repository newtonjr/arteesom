//
//  StoryLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "StoryLayer.h"
#import "WorldLayer.h"

@implementation StoryLayer

@synthesize time;

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	StoryLayer *layer = [StoryLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super init])) {
        time = .0f;
        
        self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
        CGSize s = [CCDirector sharedDirector].winSize;
        
        CCLabelTTF *label = [CCLabelTTF labelWithString:@"StoryBoard" fontName:@"Marker Felt" fontSize:32];
		[self addChild:label z:0];
		[label setColor:ccc3(0,0,255)];
		label.position = ccp(s.width/2, s.height-50);
        
        //
        // time control
        //
        [self scheduleUpdate];
	}
	return self;

}

-(void) update: (ccTime) dt
{
    time += dt;
    //NSLog(@"time: %f %f", time, dt);
    if (time > 3.0) {
        //NSLog(@"ok");
        [self unscheduleUpdate];
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[WorldLayer scene] withColor:ccWHITE]];
    }
}

@end
