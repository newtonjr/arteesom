//
//  ActionSprite.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PhysicsSprite.h"
#import "GLES-Render.h"
#import "FixtureData.h"

@interface ActionSprite : PhysicsSprite {
    ActionState actionState;
    FixtureData * fixtureData;
}

//@property b2World * world;
//-(void)setPhysicsBody:(b2Body*)b2Body;
-(b2Body*)getBody;
-(void) setFixedRotation:(bool)fixedRotation;

//actions
@property(nonatomic,strong)id idleAction;
@property(nonatomic,strong)id walkAction;
@property(nonatomic,strong)id hurtAction;
@property(nonatomic,strong)id knockedOutAction;

//states
@property(nonatomic,assign)ActionState actionState;

//attributes
@property(nonatomic,assign)float walkSpeed;
@property(nonatomic,assign)float walkMaxSpeed;
@property(nonatomic,assign)float hitPoints;
@property(nonatomic,assign)float damage;
@property(nonatomic,assign)CGSize size;
@property(nonatomic,assign)FixtureData * fixtureData;

//movement
@property(nonatomic,assign)CGPoint velocity;
@property(nonatomic,assign)CGPoint desiredPosition;

//measurements
//@property(nonatomic,assign)float centerToSides;
//@property(nonatomic,assign)float centerToBottom;

//action methods
-(void)idle;
-(void)hurtWithDamage:(float)damage;
-(void)knockout;
-(void)walkWithDirection:(CGPoint)direction;
-(void)setPosition:(CGPoint)position;

//
-(void)definePhysics:(b2World*)world b2BodyType:(b2BodyType)type fixturedef:(b2FixtureDef)fixture;

//scheduled methods
-(void)update:(ccTime)dt;

@end
