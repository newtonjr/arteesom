//
//  GerenciadorContatos.h
//  ExemploBox2D
//
//  Created by Farlei Jose Heinen on 02/05/11.
//  Copyright 2011 Ficta. All rights reserved.
//

#import "cocos2d.h"
#import "Box2D.h"
#import <vector>
#import <algorithm>

struct contato 
{
    b2Fixture *fixtureA;
    b2Fixture *fixtureB;
    b2Vec2 ponto;
    bool operator==(const contato& other) const
    {
        return (fixtureA == other.fixtureA) && (fixtureB == other.fixtureB);
    }
};

class GerenciadorContatos : public b2ContactListener 
{  
private:
    std::vector<contato> Contatos;
    
public:
    
    GerenciadorContatos();
    ~GerenciadorContatos();
    
    int count();
    contato popContato();
    
    // metodos usados pelo Box2D
    virtual void BeginContact(b2Contact* contact);
    virtual void EndContact(b2Contact* contact);
    virtual void PreSolve(b2Contact* contact, const b2Manifold* oldManifold);    
    virtual void PostSolve(b2Contact* contact, const b2ContactImpulse* impulse);
    
};
