//
//  ActionPlayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/23/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#import "ActionSprite.h"

@interface ActionPlayer : ActionSprite {
    bool isJump;
    float impulseFactor;
    float maxJump;
}

//actions
@property(nonatomic,strong)id runAction;
@property(nonatomic,strong)id jumpAction;
@property(nonatomic,strong)id playAction;
@property(nonatomic,strong)id drawAction;

@property float impulseFactor;
@property float maxJump;

@property float runSpeed;
@property float runMaxSpeed;

//action methods
-(void)playing;
-(void)drawing;
-(void)jump;
-(void)runWithDirection:(CGPoint)direction;

@end
