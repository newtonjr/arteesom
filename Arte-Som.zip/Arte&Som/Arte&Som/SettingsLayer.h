//
//  ConfigurationLayer.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface SettingsLayer : CCLayer {
    
}

// returns a CCScene that contains the ConfigurationLayer as the only child
+(CCScene *) scene;

@end
