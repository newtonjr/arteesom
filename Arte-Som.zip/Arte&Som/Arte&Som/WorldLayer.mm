//
//  WorldLayer.m
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/22/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "Manager.h"

#import "WorldLayer.h"
#import "MenuLayer.h"
#import "LevelLayer.h"


@implementation WorldLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	WorldLayer *layer = [WorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super init])) {
		
		// enable events
		self.isTouchEnabled = YES;
		self.isAccelerometerEnabled = NO;
        isFirstplayer = [Manager sharedInstance].conf.isFirstplayer;
        isMultiplayer = [Manager sharedInstance].conf.isMultiplayer;
        
		CGSize s = [CCDirector sharedDirector].winSize;
        
        CCSprite *background;
        
        background = [CCSprite spriteWithFile:@"mapa.jpg"];
        
        background.position = ccp(s.width/2, s.height/2);
        
        // add the label as a child to this Layer
        [self addChild: background z:0];
		
		// create reset button
		[self createMenu];
		
//		CCLabelTTF *label = [CCLabelTTF labelWithString:@"World" fontName:@"Marker Felt" fontSize:32];
//		[self addChild:label z:0];
//		[label setColor:ccc3(0,0,255)];
//		label.position = ccp(s.width/2, s.height-50);
	}
	return self;
}

-(void) createMenu
{
    itemModoOne = [CCMenuItemImage itemWithNormalImage:@"btn-one-player-off.jpg" selectedImage:@"btn-one-player-on.jpg"];
    
    itemModoTwo = [CCMenuItemImage itemWithNormalImage:@"btn-two-player-off.jpg" selectedImage:@"btn-two-player-on.jpg"];
    
    CCMenuItemToggle * itemModo;
    if (isMultiplayer == YES) {
        itemModo = [CCMenuItemToggle itemWithTarget:self selector:@selector(toggleGameMode:) items:itemModoTwo, itemModoOne, nil];
    } else {
        itemModo = [CCMenuItemToggle itemWithTarget:self selector:@selector(toggleGameMode:) items:itemModoOne, itemModoTwo, nil];
    }
    
    itemTipoSound = [CCMenuItemImage itemWithNormalImage:@"btn-piano-player-off.jpg" selectedImage:@"btn-piano-player-on.jpg"];
    
    itemTipoArt = [CCMenuItemImage itemWithNormalImage:@"btn-pencil-player-off.jpg" selectedImage:@"btn-pencil-player-on.jpg"];

    if (isFirstplayer == YES) {
        itemTipo = [CCMenuItemToggle itemWithTarget:self selector:@selector(toggleTypePlayer:) items:itemTipoSound, itemTipoArt, nil];
    } else {
        itemTipo = [CCMenuItemToggle itemWithTarget:self selector:@selector(toggleTypePlayer:) items:itemTipoArt, itemTipoSound,nil];
    }

    itemTipo.visible = isMultiplayer;
	
	CCMenuItem *itemMenu = [CCMenuItemImage itemWithNormalImage:@"btn-back-player-off.jpg" selectedImage:@"btn-back-player-on.jpg" block:^(id sender) {
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[MenuLayer scene] withColor:ccWHITE]];
	}];
	
	CCMenu *menu = [CCMenu menuWithItems:itemModo, itemTipo, itemMenu, nil];
	
	[menu alignItemsVertically];
	
	[menu setPosition:ccp( 40, 140)];
	
	[self addChild: menu z:1];
    
    //
    // MAPA
    //
    NSArray * steps = [Manager sharedInstance].conf.steps;
    
    CCMenuItem *itemLevel1 = [CCMenuItemImage itemWithNormalImage:@"btn-level-1-off.png" selectedImage:@"btn-level-1-on.png" block:^(id sender) {
        [Manager sharedInstance].conf.levelActual = 1;
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[LevelLayer scene] withColor:ccBLACK]];
	}];

    CCMenu *menuLevel = [CCMenu menuWithItems:itemLevel1, nil];
    [menuLevel setPosition:ccp( 879, 190)];
    [self addChild: menuLevel z:1];
    
    Step * step = [steps objectAtIndex:0];
    NSLog(@"%i",step.star);
    for (int i = 0; i < 3; i++) {
        CCSprite* star;
        if(i < step.star){
            star = [CCSprite spriteWithFile:@"icon-star-on.png"];
        }else{
            star = [CCSprite spriteWithFile:@"icon-star-off.png"];
        }
        switch (i) {
            case 0:
                star.position = ccp(-5,-10);
                break;
            case 1:
                star.position = ccp(22,-10);
                break;
            case 2:
                star.position = ccp(50,-10);
                break;
        }
        [itemLevel1 addChild:star z:1];
    }
}

-(void)toggleGameMode:(id)sender {
    //CCMenuItemToggle *toggleItem = (CCMenuItemToggle *)sender;
    if (isMultiplayer == NO) {
        //[itemModo setNormalImage:[CCSprite spriteWithFile:@"btn-two-player-off.jpg"]];
        //[itemModo setString:@"2 jogadores"];
        [Manager sharedInstance].conf.isMultiplayer = isMultiplayer = YES;
    } else {
        //[itemModo setNormalImage:[CCSprite spriteWithFile:@"btn-on-player-off.jpg"]];
        //[itemModo setString:@"1 jogador"];
        [Manager sharedInstance].conf.isMultiplayer = isMultiplayer = NO;
        isFirstplayer = NO;
        [self toggleTypePlayer:NULL];
    }
    itemTipo.visible = isMultiplayer;
}

-(void)toggleTypePlayer:(id)sender {
    //CCMenuItemToggle *toggleItem = (CCMenuItemToggle *)sender;
    if (isFirstplayer == NO) {
        //[itemTipo setString:@"Personagem: Sarah (principal)"];
        [Manager sharedInstance].conf.isFirstplayer = isFirstplayer = YES;
    } else {
        //[itemTipo setString:@"Personagem: Thomas (ajudante)"];
        [Manager sharedInstance].conf.isFirstplayer = isFirstplayer = NO;
    }
}

@end
