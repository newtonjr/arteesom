//
//  MusicScore.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/29/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ActionMusic.h"
#import "MusicSymbol.h"

@interface MusicScore : CCLayer {
    float time;
    float step;
    float score;
    float maxScore;
    int missing;
    int maxNotes;
    
    BOOL allRunning;
    
    CCArray* songs;
    CCArray* currentSong;
    
    
    CCArray * elements;
    CCArray * sprites;
    CCArray * symbols;
    
    CCLabelTTF *label;
    CCLabelTTF *labelShadow;
}

@property int indexSong;
@property int max;
@property int count;
@property BOOL running;
@property BOOL getScore;
@property float score;
@property float maxScore;

-(void)start:(BOOL)hasBar andIndexSong:(int)song;
-(void)finish;
-(BOOL)addElement:(ActionMusic *) el;
-(void)keyTouch:(NSString *) key;

@end
