//
//  MusicScore.h
//  Arte&Som
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/29/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Element.h"
#import "MusicSymbol.h"

@interface MusicScore : CCLayer {
    float time;
    float step;
    float score;
    int missing;
    
    BOOL allRunning;
    
    CCArray* songs;
    CCArray* currentSong;
    
    
    CCArray * elements;
    CCArray * sprites;
    CCArray * symbols;
}

@property int max;
@property int count;
@property BOOL running;

-(void)start;
-(void)finish;
-(void)addElement:(Element *) el;
-(void)keyTouch:(NSString *) key;

@end
