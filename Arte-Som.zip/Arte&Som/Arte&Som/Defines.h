//
//  Defines.h
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//
//

#ifndef game_plataforma_teste_Defines_h
#define game_plataforma_teste_Defines_h

// 1 - convenience measurements
#define SCREEN [[CCDirector sharedDirector] winSize]
#define CENTER ccp(SCREEN.width/2, SCREEN.height/2)
#define CURTIME CACurrentMediaTime()
#define MUSIC_VALUE_TIME 3.33

//Pixel to metres ratio. Box2D uses metres as the unit for measurement.
//This ratio defines how many pixels correspond to 1 Box2D "metre"
//Box2D is optimized for objects of 1x1 metre therefore it makes sense
//to define the ratio so that your most common object type is 1x1 metre.
#define PTM_RATIO 32

// 2 - convenience functions
#define random_range(low,high) (arc4random()%(high-low+1))+low
#define frandom (float)arc4random()/UINT64_C(0x100000000)
#define frandom_range(low,high) ((high-low)*frandom)+low
//#define distance(x1,y1,x2,y2) sqrt(pow(x1-x2,2.0) + pow(y1-y2,2.0))

// 3 - enumerations
typedef enum _ActionState {
    kActionStateNone = 0,
    kActionStateIdle,
    kActionStateAttack,
    kActionStateWalk,
    kActionStateRun,
    kActionStateJump,
    kActionStatePlay,
    kActionStateDraw,
    kActionStateHurt,
    kActionStateKnockedOut
} ActionState;

typedef enum _FixtureIdentify {
    kFixtureIdentifyGroung = 0,
    kFixtureIdentifyEnemy,
    kFixtureIdentifyElement,
    kFixtureIdentifyFirstPlayer,
    kFixtureIdentifySecondPlayer,
    kFixtureIdentifyEnd
} FixtureIdentify;

typedef enum _ButtonType {
    kButtonTypeJumping = 0,
    kButtonTypeRunning,
    kButtonTypeDrawing
} ButtonType;

// 4 - structures
typedef struct _BoundingBox {
    CGRect actual;
    CGRect original;
} BoundingBox;

#endif
