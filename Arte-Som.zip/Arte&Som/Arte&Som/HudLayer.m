//
//  HudLayer.m
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//
#import "Manager.h"
#import "HudLayer.h"

@implementation HudLayer

@synthesize isRunning,isDrawing,itemdraw;

-(id)init {
    if ((self = [super init])) {
        _dPad = [SimpleDPad dPadWithFile:@"mn_dpad.png" radius:64];
        _dPad.position = ccp(64.0, 64.0);
        _dPad.opacity = 160;
        [self addChild:_dPad];
        
        //
        // title
        //
		labelScore = [CCLabelTTF labelWithString:@"0" fontName:@"Marker Felt" fontSize:32];
		[self addChild:labelScore z:0];
		[labelScore setColor:ccc3(0,0,0)];
		labelScore.position = ccp(SCREEN.width/2, SCREEN.height-50);
        
        //
        // actions player
        //
        
        CCMenuItem *jumpButtonItem = [CCMenuItemImage
                                    itemWithNormalImage:@"btn-jump-off.png" selectedImage:@"btn-jump-on.png"
                                    target:self selector:@selector(jumpButtonTapped:)];
        jumpButtonItem.position = CGPointZero;
        jumpButtonItem.tag = kButtonTypeJumping;
        
        
        CCMenuItemImage *drawButtonItemDisabled = [CCMenuItemImage
                                    itemWithNormalImage:@"btn-paint-disabled-off.png" selectedImage:@"btn-paint-disabled-on.png"];
        
        CCMenuItemImage *drawButtonItemEnabled = [CCMenuItemImage
                                                   itemWithNormalImage:@"btn-paint-enable-off.png" selectedImage:@"btn-paint-enable-on.png"];
        
        itemdraw = [CCMenuItemToggle itemWithTarget:self selector:@selector(drawButtonTapped:) items:drawButtonItemDisabled, drawButtonItemEnabled, nil];
        
        itemdraw.position = CGPointZero;
        itemdraw.tag = kButtonTypeDrawing;
        
        CCMenuItemImage *runButtonItemWalk = [CCMenuItemImage itemWithNormalImage:@"btn-walk-off.png" selectedImage:@"btn-walk-on.png"];
        CCMenuItemImage *runButtonItemRun = [CCMenuItemImage itemWithNormalImage:@"btn-run-off.png" selectedImage:@"btn-run-on.png"];
        
        CCMenuItemToggle * itemRun = [CCMenuItemToggle itemWithTarget:self selector:@selector(runButtonTapped:) items:runButtonItemWalk, runButtonItemRun, nil];
        
        itemRun.position = CGPointZero;
        itemRun.tag = kButtonTypeRunning;

        
        CCMenu *starMenu = [CCMenu menuWithItems:itemdraw, itemRun, jumpButtonItem, nil];
        [starMenu alignItemsVertically];
        starMenu.position = ccp(SCREEN.width - jumpButtonItem.boundingBox.size.width / 2, ((jumpButtonItem.boundingBox.size.height * 3) / 2) + 5);
        starMenu.opacity = 160;
        [self addChild:starMenu];
        
        //
        // actions scene
        //
        CCMenuItemImage *itemLevel = [CCMenuItemImage itemWithNormalImage:@"btn-replay-off.png" selectedImage:@"btn-replay-on.png" block:^(id sender) {
            //
            [_delegate HudLayer:self pressedButton:kButtonTypeRestar];
        }];
        
        CCMenuItemImage *itemWorld = [CCMenuItemImage itemWithNormalImage:@"btn-back-player-off.jpg" selectedImage:@"btn-back-player-on.jpg" block:^(id sender) {
            //
            [_delegate HudLayer:self pressedButton:kButtonTypeSelectedLevel];
        }];
        
        CCMenu *menu = [CCMenu menuWithItems:itemLevel, itemWorld, nil];
        
        [menu alignItemsVertically];
        
        [menu setPosition:ccp(40, SCREEN.height-100)];
        
        [self addChild: menu];
        
        //
        // keyboard
        //
        _keyboard = [KeyboardLayer node];
        _keyboard.position = CGPointMake(SCREEN.width - ((58*6) + 105), 80.0);
        [self addChild:_keyboard];
        
        if ([Manager sharedInstance].conf.isMultiplayer == YES) {
            if ([Manager sharedInstance].conf.isFirstplayer == NO) {
                _keyboard.visible = false;
                _keyboard.active = NO;
            } else {
                itemdraw.visible = false;
            }
        }
        
        
        //
        // default
        //
        isDrawing = isRunning = false;
    }
    return self;
}

-(void)updateScore:(int)score {
    [labelScore setString:[NSString stringWithFormat:@"%i",score]];
}

- (void)jumpButtonTapped:(id)sender {
    [_delegate HudLayer:self pressedButton:((CCMenuItem*)sender).tag];
}
- (void)drawButtonTapped:(id)sender {
    isDrawing = !isDrawing;
    _dPad.isActive = isDrawing ? NO : YES;
    CCMenuItemToggle *toggleItem = (CCMenuItemToggle *)sender;
    [_delegate HudLayer:self pressedButton:toggleItem.tag];
}
- (void)runButtonTapped:(id)sender {
    isRunning = !isRunning;
    CCMenuItemToggle *toggleItem = (CCMenuItemToggle *)sender;
    [_delegate HudLayer:self pressedButton:toggleItem.tag];
}

@end
