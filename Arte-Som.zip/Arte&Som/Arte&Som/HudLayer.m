//
//  HudLayer.m
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "HudLayer.h"

@implementation HudLayer

@synthesize isRunning,isDrawing,drawButtonItem;

-(id)init {
    if ((self = [super init])) {
        _dPad = [SimpleDPad dPadWithFile:@"mn_dpad.png" radius:64];
        _dPad.position = ccp(64.0, 64.0);
        _dPad.opacity = 100;
        [self addChild:_dPad];
        
        CCMenuItem *jumpButtonItem = [CCMenuItemImage
                                    itemWithNormalImage:@"mn_button.png" selectedImage:@"mn_button_sel.png"
                                    target:self selector:@selector(jumpButtonTapped:)];
        jumpButtonItem.position = CGPointZero;
        jumpButtonItem.tag = kButtonTypeJumping;
        
        drawButtonItem = [CCMenuItemImage
                                    itemWithNormalImage:@"mn_button.png" selectedImage:@"mn_button_sel.png"
                                    target:self selector:@selector(drawButtonTapped:)];
        drawButtonItem.position = CGPointZero;
        drawButtonItem.tag = kButtonTypeDrawing;
        
        CCMenuItem *runButtonItem = [CCMenuItemImage
                                      itemWithNormalImage:@"mn_button.png" selectedImage:@"mn_button_sel.png"
                                      target:self selector:@selector(runButtonTapped:)];
        runButtonItem.position = CGPointZero;
        runButtonItem.tag = kButtonTypeRunning;

        
        CCMenu *starMenu = [CCMenu menuWithItems:drawButtonItem, runButtonItem, jumpButtonItem, nil];
        [starMenu alignItemsVertically];
        starMenu.position = ccp(SCREEN.width - jumpButtonItem.boundingBox.size.width / 2, ((jumpButtonItem.boundingBox.size.height * 3) / 2) + 5);
        starMenu.opacity = 100;
        [self addChild:starMenu];
        
        //
        // keyboard
        //
        _keyboard = [KeyboardLayer node];
        _keyboard.position = CGPointMake(SCREEN.width - ((58*6) + 105), 80.0);
        [self addChild:_keyboard];
        
        
        //
        // default
        //
        isDrawing = isRunning = false;
    }
    return self;
}

- (void)jumpButtonTapped:(id)sender {
    [_delegate HudLayer:self pressedButton:((CCMenuItem*)sender).tag];
}
- (void)drawButtonTapped:(id)sender {
    isDrawing = !isDrawing;
    _dPad.isActive = isDrawing ? NO : YES;
    [_delegate HudLayer:self pressedButton:((CCMenuItem*)sender).tag];
}
- (void)runButtonTapped:(id)sender {
    isRunning = !isRunning;
    [_delegate HudLayer:self pressedButton:((CCMenuItem*)sender).tag];
}

@end
