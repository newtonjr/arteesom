//
//  GCHelper.h
//  Cat Race
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 10/9/13.
//
//

#import <Foundation/Foundation.h>
#import <GameKit/GameKit.h>

@class GCHelperDelegate;

@protocol GCHelperDelegate
- (void)inviteReceived;
- (void)matchStarted;
- (void)matchEnded;
- (void)match:(GKMatch *)match didReceiveData:(NSData *)data fromPlayer:(NSString *)playerID;
@end

@interface GCHelper : NSObject <GKMatchmakerViewControllerDelegate, GKMatchDelegate, GKGameCenterControllerDelegate> {
    BOOL gameCenterAvailable;
    BOOL userAuthenticated;
    BOOL matchStarted;
    
    int goToAfterAuthenticated;
    int playerGroup;
    uint32_t playerAttributes;
    
    UIViewController *presentingViewController;
    GKMatch *match;
    
    id <GCHelperDelegate> delegate;
    
    NSMutableDictionary *playersDict;
    
    GKInvite *pendingInvite;
    NSArray *pendingPlayersToInvite;
}
//
// @property
//
@property (assign) id <GCHelperDelegate> delegate;

@property (assign, readonly) BOOL userAuthenticated;
@property (assign, readonly) BOOL gameCenterAvailable;

@property (retain) UIViewController *presentingViewController;
@property (retain) GKMatch *match;

@property (retain) NSMutableDictionary *playersDict;

//
// actions
//
+ (GCHelper *)sharedInstance;

- (void)defineView:(UIViewController *)view;

- (void)authenticateLocalUser;

- (void)gamecenter;

- (void)findMatch:(uint32_t)attributes playerGroup:(int)group delegate:(id<GCHelperDelegate>)theDelegate;

@end