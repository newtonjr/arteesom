//
//  GameLayer.m
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "SimpleAudioEngine.h"
#import "GameScene.h"
#import "GameLayer.h"

// Needed to read map .tmx
//#import "CCTMXMapInfo+TMXParserExt.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"

#import "Robot.h"


@implementation GameLayer

-(id)init {
    if ((self = [super init])) {
        self.isTouchEnabled = YES;
        
        [self initTileMap];
        [self scheduleUpdate];
        
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"pd_sprites.plist"];
        _actors = [CCSpriteBatchNode batchNodeWithFile:@"pd_sprites.pvr.ccz"];
        [_actors.texture setAliasTexParameters];
        [self addChild:_actors z:-5];
        [self initHero];
        [self initRobots];
        
        // Load audio
        [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:@"latin_industries.aifc"];
        [[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"latin_industries.aifc"];
        [[SimpleAudioEngine sharedEngine] preloadEffect:@"pd_hit0.caf"];
        [[SimpleAudioEngine sharedEngine] preloadEffect:@"pd_hit1.caf"];
        [[SimpleAudioEngine sharedEngine] preloadEffect:@"pd_herodeath.caf"];
        [[SimpleAudioEngine sharedEngine] preloadEffect:@"pd_botdeath.caf"];
    }
    return self;
}

-(void)initHero {
    _hero = [Hero node];
    [_actors addChild:_hero];
    _hero.position = ccp(_hero.centerToSides, 80);
    _hero.desiredPosition = _hero.position;
    [_hero idle];
}

-(void)initRobots {
    int robotCount = 50;
    self.robots = [[CCArray alloc] initWithCapacity:robotCount];
    
    for (int i = 0; i < robotCount; i++) {
        Robot *robot = [Robot node];
        [_actors addChild:robot];
        [_robots addObject:robot];
        
        int minX = SCREEN.width + robot.centerToSides;
        int maxX = _tileMap.mapSize.width * _tileMap.tileSize.width - robot.centerToSides;
        int minY = robot.centerToBottom;
        int maxY = 3 * _tileMap.tileSize.height + robot.centerToBottom;
        robot.scaleX = -1;
        robot.position = ccp(random_range(minX, maxX), random_range(minY, maxY));
        robot.desiredPosition = robot.position;
        [robot idle];
    }
}

-(void)reorderActors {
    ActionSprite *sprite;
    CCARRAY_FOREACH(_actors.children, sprite) {
        [_actors reorderChild:sprite z:(_tileMap.mapSize.height * _tileMap.tileSize.height) - sprite.position.y];
    }
}

// retorna negativo se for CCW
-(float) areaPoligono: (b2PolygonShape) shape {
    
    float area = 0.0;
    int n = shape.m_vertexCount;
    for (int i = 0; i < n; ++i) {
        int k = (i + 1) % n;
        area += (shape.m_vertices[k].x * shape.m_vertices[i].y) - (shape.m_vertices[i].x * shape.m_vertices[k].y);
    }
    return area;
}

-(b2PolygonShape) invertePoligono: (b2PolygonShape) shape {
    
    b2PolygonShape reverseShape;
    reverseShape.m_vertexCount = shape.m_vertexCount;
    int n = shape.m_vertexCount;
    int i,k;
    for (i = n - 1, k = 0; i > -1; --i, ++k) {
        reverseShape.m_vertices[i].Set(shape.m_vertices[k].x, shape.m_vertices[k].y);
    }
    return reverseShape;
}

-(void) adicionaPoligonoBox2D: (NSArray*) polyArray noPonto:(CGPoint) posicao
{
    if([polyArray count] > b2_maxPolygonVertices) return;
    
    b2PolygonShape polygon;
    polygon.m_vertexCount = [polyArray count];
    
    int i = 0;
    for(NSValue* pt in polyArray) {
        CGPoint point = [pt CGPointValue];
        polygon.m_vertices[i].Set(point.x/PTM_RATIO, point.y/PTM_RATIO);
        i++;
    }
    
    if([self areaPoligono:polygon] > 0) {
        NSLog(@"CW: invertendo para CCW");
        polygon = [self invertePoligono:polygon];
    }
    
    polygon.Set(polygon.m_vertices, polygon.m_vertexCount);
    
    b2BodyDef polyBodyDef;
    polyBodyDef.position.Set(posicao.x/PTM_RATIO,posicao.y/PTM_RATIO);
    b2Body *polyBody = world->CreateBody(&polyBodyDef);
    
    b2FixtureDef polyShapeDef;
    polyShapeDef.shape = &polygon;
    polyBody->CreateFixture(&polyShapeDef);
}

-(void) processaObjetosBox2D {
    
    CCTMXObjectGroup* grupo = [_tileMap objectGroupNamed:@"interaction"];
    NSMutableArray* poligonos = [grupo objects];
    for(NSDictionary* obj in poligonos) {
        float px = [[obj objectForKey:@"x"] floatValue];
        float py = [[obj objectForKey:@"y"] floatValue];
        NSString* pontos = [obj objectForKey:@"polygonPoints"];
        
        NSArray* comVirgula = [pontos componentsSeparatedByString:@" "];
        NSMutableArray* polyArray = [[NSMutableArray new] autorelease];
        for(NSString* pt in comVirgula) {
            NSArray* xy = [pt componentsSeparatedByString:@","];
            
            CGPoint xyPT;
            xyPT.x = [[xy objectAtIndex:0] floatValue];
            xyPT.y = -[[xy objectAtIndex:1] floatValue];
            NSValue* valuePT = [NSValue valueWithCGPoint:xyPT];
            [polyArray addObject:valuePT];
        }
        NSLog(@"Processando: %f , %f",px,py);
        [self adicionaPoligonoBox2D:polyArray noPonto:CGPointMake(px,py)];
    }
}

-(void)initTileMap {
    
    _tileMap = [CCTMXTiledMap tiledMapWithTMXFile:@"pd_tilemap.tmx"];
    for (CCTMXLayer *child in [_tileMap children]) {
        [[child texture] setAliasTexParameters];
    }
    [self addChild:_tileMap z:-6];
}

-(void)setViewpointCenter:(CGPoint) position {
    
    CGSize winSize = [[CCDirector sharedDirector] winSize];
    
    int x = MAX(position.x, winSize.width / 2);
    int y = MAX(position.y, winSize.height / 2);
    x = MIN(x, (_tileMap.mapSize.width * _tileMap.tileSize.width)
            - winSize.width / 2);
    y = MIN(y, (_tileMap.mapSize.height * _tileMap.tileSize.height)
            - winSize.height/2);
    CGPoint actualPosition = ccp(x, y);
    
    CGPoint centerOfView = ccp(winSize.width/2, winSize.height/2);
    CGPoint viewPoint = ccpSub(centerOfView, actualPosition);
    self.position = viewPoint;
}

//
// Update
//

-(void)dealloc {
    [super dealloc];
    [self unscheduleUpdate];
}

-(void)update:(ccTime)dt {
    [_hero update:dt];
    [self updatePositions];
    [self reorderActors];
    [self updateRobots:dt];
    [self setViewpointCenter:_hero.position];
}

-(void)updatePositions {
    float posX = MIN(_tileMap.mapSize.width * _tileMap.tileSize.width - _hero.centerToSides, MAX(_hero.centerToSides, _hero.desiredPosition.x));
    float posY = MIN(3 * _tileMap.tileSize.height + _hero.centerToBottom, MAX(_hero.centerToBottom, _hero.desiredPosition.y));
    _hero.position = ccp(posX, posY);
    
    // Update robots
    Robot *robot;
    CCARRAY_FOREACH(_robots, robot) {
        posX = MIN(_tileMap.mapSize.width * _tileMap.tileSize.width - robot.centerToSides, MAX(robot.centerToSides, robot.desiredPosition.x));
        posY = MIN(3 * _tileMap.tileSize.height + robot.centerToBottom, MAX(robot.centerToBottom, robot.desiredPosition.y));
        robot.position = ccp(posX, posY);
    }
}

-(void)updateRobots:(ccTime)dt {
    int alive = 0;
    Robot *robot;
    float distanceSQ;
    int randomChoice = 0;
    CCARRAY_FOREACH(_robots, robot) {
        [robot update:dt];
        if (robot.actionState != kActionStateKnockedOut) {
            //1
            alive++;
            
            //2
            if (CURTIME > robot.nextDecisionTime) {
                distanceSQ = ccpDistanceSQ(robot.position, _hero.position);
                
                //3
                if (distanceSQ <= 50 * 50) {
                    robot.nextDecisionTime = CURTIME + frandom_range(0.1, 0.5);
                    randomChoice = random_range(0, 1);
                    
                    if (randomChoice == 0) {
                        if (_hero.position.x > robot.position.x) {
                            robot.scaleX = 1.0;
                        } else {
                            robot.scaleX = -1.0;
                        }
                        
                        //4
                        [robot attack];
                        if (robot.actionState == kActionStateAttack) {
                            if (fabsf(_hero.position.y - robot.position.y) < 10) {
                                if (CGRectIntersectsRect(_hero.hitBox.actual, robot.attackBox.actual)) {
                                    [_hero hurtWithDamage:robot.damage];
                                    
                                    //end game checker here
                                    if (_hero.actionState == kActionStateKnockedOut && [_hud getChildByTag:5] == nil) {
                                        [self endGame];
                                    }
                                }
                            }
                        }
                    } else {
                        [robot idle];
                    }
                } else if (distanceSQ <= SCREEN.width * SCREEN.width) {
                    //5
                    robot.nextDecisionTime = CURTIME + frandom_range(0.5, 1.0);
                    randomChoice = random_range(0, 2);
                    if (randomChoice == 0) {
                        CGPoint moveDirection = ccpNormalize(ccpSub(_hero.position, robot.position));
                        [robot walkWithDirection:moveDirection];
                    } else {
                        [robot idle];
                    }
                }
            }
        }
    }
    
    //end game checker here
    if (alive == 0 && [_hud getChildByTag:5] == nil) {
        [self endGame];
    }
}

//
// Action touches
//
-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [_hero attack];
    
    if (_hero.actionState == kActionStateAttack) {
        Robot *robot;
        CCARRAY_FOREACH(_robots, robot) {
            if (robot.actionState != kActionStateKnockedOut) {
                if (fabsf(_hero.position.y - robot.position.y) < 10) {
                    if (CGRectIntersectsRect(_hero.attackBox.actual, robot.hitBox.actual)) {
                        [robot hurtWithDamage:_hero.damage];
                    }
                }
            }
        }
    }
}

-(void)simpleDPad:(SimpleDPad *)simpleDPad didChangeDirectionTo:(CGPoint)direction {
    [_hero walkWithDirection:direction];
}

-(void)simpleDPadTouchEnded:(SimpleDPad *)simpleDPad {
    if (_hero.actionState == kActionStateWalk) {
        [_hero idle];
    }
}

-(void)simpleDPad:(SimpleDPad *)simpleDPad isHoldingDirection:(CGPoint)direction {
    [_hero walkWithDirection:direction];
}

//
// end
//

-(void)endGame {
    CCLabelTTF *restartLabel = [CCLabelTTF labelWithString:@"RESTART" fontName:@"Arial" fontSize:30];
    CCMenuItemLabel *restartItem = [CCMenuItemLabel itemWithLabel:restartLabel target:self selector:@selector(restartGame)];
    CCMenu *menu = [CCMenu menuWithItems:restartItem, nil];
    menu.position = CENTER;
    menu.tag = 5;
    [_hud addChild:menu z:5];
}

-(void)restartGame {
    [[CCDirector sharedDirector] replaceScene:[GameScene node]];
}

@end
