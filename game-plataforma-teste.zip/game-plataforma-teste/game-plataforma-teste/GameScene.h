//
//  GameScene.h
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <GameKit/GameKit.h>

// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"
#import "Box2D.h"
#import "GLES-Render.h"

// base
#import "GameLayer.h"
#import "HudLayer.h"

@interface GameScene : CCScene {
    
}

@property(nonatomic,retain)GameLayer *gameLayer;
@property(nonatomic,retain)HudLayer *hudLayer;

@end
