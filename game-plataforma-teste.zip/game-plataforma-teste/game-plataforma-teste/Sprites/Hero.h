//
//  Hero.h
//  game-plataforma-teste
//
//  Created by Newton Carlos Ouriques Brandalize Junior on 9/14/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ActionSprite.h"

@interface Hero : ActionSprite {
    
}

@end
